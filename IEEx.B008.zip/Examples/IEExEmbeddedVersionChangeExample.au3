#include <GUIConstantsEx.au3>
#include "IEEx.au3"
#include <WindowsConstants.au3>

_Example()

Func _Example()

	Local Static $sHKCR = ((@AutoItX64) ? "HKCR64" : "HKCR")
	Local Static $szCOMIE = StringReplace(FileGetShortName(RegRead($sHKCR & _
			"\CLSID\{0002DF01-0000-0000-C000-000000000046}\LocalServer32", "")), '"', "")
	Local Const $iMajorWanted = Int(FileGetVersion($szCOMIE))

	#Region standard code
	Local $oIE = _IECreateEmbedded()
	GUICreate("Embedded Web control Test", 640, 580, _
			(@DesktopWidth - 640) / 2, (@DesktopHeight - 580) / 2, _
			$WS_OVERLAPPEDWINDOW + $WS_CLIPSIBLINGS + $WS_CLIPCHILDREN)
	GUICtrlCreateObj($oIE, 10, 40, 600, 360)
	_IENavigate($oIE, "http://www.autoitscript.com")
	_IELoadWait($oIE)
	#EndRegion standard code

	; what version are we running?
	ConsoleWrite("Embedded is running version: " & _IEEx_GetAppMajorVersion($oIE) & @CRLF)

	; I want my embedded version to be the same as I run from _IECreate()
	; So I'll do a check
	Local $nEmbedded = _IEEx_EmbeddedGetVersion()
	ConsoleWrite("Embedded version:	" & $nEmbedded & @CRLF & "Major version:	" & $iMajorWanted & @CRLF)

	If Int($nEmbedded) <> $iMajorWanted Then
		; set version to current IE used if called by _IECreate()
		_IEEx_EmbeddedSetVersion($iMajorWanted) ; or just _IEEx_EmbeddedSetVersion()
		; keep in mind, that the current session doesn't work when setting it initially if it didn't already exist
		; so for that reason, you'll need to restart your app
		MsgBox(64 + 262144, "Warning", "You will now need to restart your app." & @CRLF & _
			"Since this is more than likely an .au3, and I don't feel like writing the restart code, " & _
			"this will now exit and you can run the example again.")
		Exit
	EndIf

	GUISetState(@SW_SHOW) ;Show GUI
	Sleep(2000)

	GUIDelete()
EndFunc   ;==>_Example