#include "IEEx.au3"

; disregard _IEAttach console error if instance doesn't exist yet
Global $goIE = _IECreate("https://www.google.com/?gws_rd=ssl", 1)

Global $goTab = _ExampleTabCreate($goIE)
ConsoleWrite(@error & ":" & @extended & ": IsObj = " & IsObj($goTab) & @CRLF)

;_IEQuit($goIE)

Func _ExampleTabCreate(ByRef $oObj)

    If Not IsObj($oObj) Then
        Return SetError(1, 0, 0)
    EndIf

    Local $oTab = _IEEx_TabCreate($oObj, "http://autoitscript.com/forum")
    If Not IsObj($oTab) Then
        Return SetError(2, 0, 0)
    EndIf

    ; return tabs browser object
    Return $oTab
EndFunc