#include-once
#AutoIt3Wrapper_AU3Check_Parameters=-q -d -w 1 -w 2 -w 3 -w- 4 -w 5 -w 6 -w- 7

#include <IE.au3>
#include <WinAPI.au3>
#include <WindowsConstants.au3>

; #INDEX# =======================================================================================================================
; Title .........: Internet Explorer Automation UDF Extension Library with Javascript injection or data retrieval options
; AutoIt Version : 3.3.12.0
; Language ......: English
; Author(s) .....: SmOke_N (Ron Nielsen) Ron.SMACKThatApp@gmail.com
; Comment(s) ....: Not all the functions utilize Javascript, some are just helper functions
;                   Some just simplify longer method/property calls
; Resources .....: IE.au3 (By Dale Hohm)
;                  Unique Javascript code accredited within code
; ===============================================================================================================================

; #CHANGES# =====================================================================================================================
; 2014-12-30    B0.0.6    Added:    _IEEx_EmbeddedGetVersion(); Get the embedded version used from something like
;                                                              _IECreateEmbedded
; 2014-12-30    B0.0.6    Added:    _IEEx_EmbeddedSetVersion(); Set the embedded version used from something like
;                                                              _IECreateEmbedded (see example)
; 2014-12-30    B0.0.6    Added:    _IEEx_TabAttach(); Similar to _IEAttach(), but browser specific and different string cases
; 2014-12-30    B0.0.6    Added:    _IEEx_TabCount(); Get a count of the tabs open in a specific browser session
; 2014-12-30    B0.0.6    Added:    _IEEx_TabGetInstance(); Get the tab instance number from the specific browser session
; 2014-12-30    B0.0.6    Added:    _IEEx_WinGetBrowserObjArray(); Get all the browser objects (tabs) from a specific browser
;                                                                 window handle/title
; 2015-01-13    B0.0.7    Changed:  _IEJS format to _IEEx - Script breaking
; 2015-01-20    B0.0.7    Fixed     _IEEx_CreateWithParams(); Issue with tryattach, wait, and focus.
;                                                              Added return object/pid feature
; 2015-01-22    B0.0.7    Fixed:    _IEEx_CallObjExecScript(); Recursion issue when IE version is 11 or higher and no exeScript
; 2015-01-26    B0.0.7    Added:    _IEEx_ClassNameGetArray(); Retrieve an array of objects based on class
; 2015-01-26    B0.0.7    Added:    _IEEx_GetObjByClassName(); Retrieve an object based on class
; 2015-01-26    B0.0.7    Added:    _IEEx_GetObjByString(); Retrieve an object by its innerText or value
; 2015-01-26    B0.0.7    Added:    _IEEx_ObjCheckBoxRadioSelect(); (Un)Check/(De)Select radio or checkbox, has dispatchevent
;                                                                    option as well as fireevent
; 2015-01-26    B0.0.7    Added:    _IEEx_ObjDispatchEvent(); similar to fireEvent
; 2015-01-26    B0.0.7    Added:    _IEEx_WhileIsObj(); waits until an object is no longer an object (could come in handy for
;                                                        waiting on page loads rather than hoping you have the right about of
;                                                        Sleep(n) allocated)
; 2015-01-26    B0.0.7    Added:    _IEEx_WhileNotIsObj(); waits until a variable is an object (could come in handy for
;                                                        waiting on page loads rather than hoping you have the right about of
;                                                        Sleep(n) allocated)
; 2015-01-26    B0.0.8    Fixed:    _IEEx_GetAppMajorVersion(); Was being passed regular objects but only checking for browser
;                                                                Thank you mLipok for reporting and testing for me
; ===============================================================================================================================

; #Function Names#===============================================================================================================
;    _IEEx_CallObjEval()
;    _IEEx_CallObjExecScript() - Fixed
;    _IEEx_CheckAppVersionAlways()
;    _IEEx_ClassNameGetArray() - New
;    _IEEx_ClickObjByPoint()
;    _IEEx_CreateWithParams() - Fixed
;    _IEEx_EmbeddedGetVersion()
;    _IEEx_EmbeddedSetVersion()
;    _IEEx_GetAppMajorVersion()
;    _IEEx_GetObjByClassName() - New
;    _IEEx_GetObjByString() - New
;    _IEEx_GetObjEval()
;    _IEEx_GetObjParentWindow()
;    _IEEx_GetObjPos()
;    _IEEx_GetObjType()
;    _IEEx_GetScroll()
;    _IEEx_GetScrollPoint()
;    _IEEx_GetWindowSize()
;    _IEEx_ObjCheckBoxRadioSelect() - New
;    _IEEx_ObjDispatchEvent() - New
;    _IEEx_MouseEventExec()
;    _IEEx_JSClassNameGetArray()
;    _IEEx_JSClassNameGetCollection()
;    _IEEx_JSClickObj()
;    _IEEx_JSClickObjById()
;    _IEEx_JSClickObjByName()
;    _IEEx_JSClickObjByPoint()
;    _IEEx_JSDragEventObj()
;    _IEEx_JSEnable()
;    _IEEx_JSGetObjByClassName()
;    _IEEx_JSGetObjPos()
;    _IEEx_JSIsEnabled()
;    _IEEx_JSMouseEventObj()
;    _IEEx_JSMouseEventObjById()
;    _IEEx_JSMouseEventObjByName()
;    _IEEx_JSObjQuerySelector()
;    _IEEx_JSObjQuerySelectorAll()
;    _IEEx_JSTypeOf()
;    _IEEx_TabAttach()
;    _IEEx_TabCount()
;    _IEEx_TabCreate()
;    _IEEx_TabGetInstance()
;    _IEEx_VersionInfo()
;    _IEEx_WhileIsObj() - New
;    _IEEx_WhileNotIsObj() - New
;    _IEEx_WinGetBrowserObjArray()
; ===============================================================================================================================

; #INTERNAL_USE_ONLY#============================================================================================================
;    __IEEx_CreateJScript()
;    __IEEx_GetContainerObj()
;    __IEEx_GetInsertScript()
;    __IEEx_MouseGetButtonDown()
;    __IEEx_JSDragEventObjBy()
;    __IEEx_JSMouseEventObjBy()
;    __IEEx_ScriptToBinary()
; ===============================================================================================================================

; #Container Globals# ===========================================================================================================
Global Const $__ga_IEExAU3VersionInfo[] = ["B", 0, 0, 8, "20150126"]
Global $__gb_IEExAppMajorVersion = False
Global $__gn_IEExAppMajorVersion = 0
Global $__gb_IEExEvalCheckRecursion = False
; ===============================================================================================================================

;================================================================================================================================
;
; Function Name....:    _IEEx_CallObjEval(ByRef $oObj, $sEval)
; Description......:    Call Eval function like: obj.document.parentWindow.eval, ensures that the
;                        eval function is found, if not found inserts itself into the document
;                        especially useful for IE browsers that fight with use of eval (IE9)
; Parameter(s).....:
;                       $oObj:  The IE object you're working with
;                       $sEval: The string you want to process within the IE object
; Return Value(s)..:
;                       Success...:  The value returned from the object eval call
;                       Failure...:  0 with error type and extended info
;                       Error.....:  0 = Success, error returns taken from IE.au3
;                                    1 = General Error, 2 = COM Error, 3 = Invalid Data Type
;                                    4 = Invalid Object Type, 5 = Invalid Value
;                                    6 = Load Wait Timeout, 7 = No Match, 8 = Access Denied
;                       Extended..:  the number returned is for debugging only, there is data
;                                     returned for both success and failures, it marks the part
;                                     of the code for easier debugging
; Requirement(s)...:
; Author(s)........:    SmOke_N (Ron Nielsen) Ron.SMACKThatApp@gmail.com
; Modified.........:
; Comment(s).......:    I understand IE11 will have some options that won't work now (execScript)
;                       I will attempt to add code to help minimize later issues
; Example(s).......:    $goEvalVal = _IEEx_CallObjEval($goIE, "alert('Hi There!');")
;
;================================================================================================================================

Func _IEEx_CallObjEval(ByRef $oObj, $sEval)

	Local $oEval = _IEEx_GetObjEval($oObj)
	If @error Then
		Return SetError(@error, 1, $oEval)
	EndIf

	Return $oEval($sEval)
EndFunc   ;==>_IEEx_CallObjEval

;================================================================================================================================
;
; Function Name....:    _IEEx_CallObjExecScript(ByRef $oObj, $sScript)
; Description......:    Call the execScript function like: obj.document.parentWindow.execScript
; Parameter(s).....:
;                       $oObj:    The IE object you're working with
;                       $sScript: The string you want to process within the IE object
; Return Value(s)..:
;                       Success...:  (execScript does not have a return value)
;                       Failure...:  0 with error type and extended info
;                       Error.....:  0 = Success, error returns taken from IE.au3
;                                    1 = General Error, 2 = COM Error, 3 = Invalid Data Type
;                                    4 = Invalid Object Type, 5 = Invalid Value
;                                    6 = Load Wait Timeout, 7 = No Match, 8 = Access Denied
;                       Extended..:  the number returned is for debugging only, there is data
;                                     returned for both success and failures, it marks the part
;                                     of the code for easier debugging
; Requirement(s)...:
; Author(s)........:    SmOke_N (Ron Nielsen) Ron.SMACKThatApp@gmail.com
; Modified.........:
; Comment(s).......:    This is deprecated in IE11, it will revert to eval
;                        I've attempted to add safeguards but no means to test with tha version atm
; Example(s).......:    _IEEx_CallObjExecScript($goIE, "alert('Hi There!');")
;
;================================================================================================================================

Func _IEEx_CallObjExecScript(ByRef $oObj, $sScript)

	; this function just executes the call to _IEEx_GetObjParentWindow

	Local $oExec = _IEEx_GetObjParentWindow($oObj)
	If @error Then
		Return SetError(@error, 1, $oExec)
	EndIf

	; execScript is deprecated in IE 11+
	Local $iVersion = _IEEx_GetAppMajorVersion($oExec)
	If $iVersion > 0 And $iVersion < 11 Then
		Return $oExec.execScript($sScript)
	EndIf

	; if eval fails... ohhh boy
	$__gb_IEExEvalCheckRecursion = True
	Local $oEval = _IEEx_GetObjEval($oExec)
	If @error Then
		Return SetError(@error, @extended, 0)
	EndIf
	$__gb_IEExEvalCheckRecursion = False

	Return $oEval($sScript)
EndFunc   ;==>_IEEx_CallObjExecScript

;================================================================================================================================
;
; Function Name....:    _IEEx_CheckAppVersionAlways($fCheck)
; Description......:    A way to speed up IE app version checking, false it will only check once
;                        Why would you use True?  Only if you're going to use multi-versions of IE in the
;                        same session you're currently running
; Parameter(s).....:
;                       $fCheck:  [Optional: Default = False
;                                    True = Will check _IEEx_GetAppMajorVersion() every time, this will
;                                     slow your processing request quite a bit versus False
;                                    False = Will check the versioning once and store the value in a variable,
;                                     this is much faster than checking everytime
; Return Value(s)..:
;                       Success...: Returns the previous set value
; Requirement(s)...:
; Author(s)........:    SmOke_N (Ron Nielsen) Ron.SMACKThatApp@gmail.com
; Modified.........:
; Comment(s).......:    If you're using 1 version of IE per application, keep it false, _IEEx_CallObjExecScript uses this
;                        on every call, so the global variable comes in handy this way
; Example(s).......:
;
;================================================================================================================================

Func _IEEx_CheckAppVersionAlways($fCheck = False)
	Local $fLastValue = $__gb_IEExAppMajorVersion
	$__gb_IEExAppMajorVersion = $fCheck
	Return $fLastValue
EndFunc   ;==>_IEEx_CheckAppVersionAlways

;================================================================================================================================
;
; Function Name....:    _IEEx_ClassNameGetArray(ByRef $oObj, $sClass, $sTag = Default, $iIndex = Default)
; Description......:
; Parameter(s).....:
;                       $oObj:   The document/form/browser/window object you're working with
;                       $sClass: The class string you want to find
;                       $sTag:   [Optional: Default = Empty String], the tag name type you want to search in
;                       $iIndex: [Optional: Default = -1 (All Found)]; The index number you want to return
; Return Value(s)..:
;                       Success...: An array of objects found by class name
;                       Failure...: 0
;                       Error.....: 0 = Success, error returns taken from IE.au3
;                                   1 = General Error, 2 = COM Error, 3 = Invalid Data Type
;                                   4 = Invalid Object Type, 5 = Invalid Value
;                                   6 = Load Wait Timeout, 7 = No Match, 8 = Access Denied
;                       Extended..: the number returned is for debugging only, there is data
;                                    returned for both success and failures, it marks the part
;                                    of the code for easier debugging
; Requirement(s)...:
; Author(s)........:    SmOke_N (Ron Nielsen) Ron.SMACKThatApp@gmail.com
; Modified.........:
; Comment(s).......:
; Example(s).......:
;
;================================================================================================================================

Func _IEEx_ClassNameGetArray(ByRef $oObj, $sClass, $sTag = Default, $iIndex = Default)
	; returns an array of objects

	If Not IsObj($oObj) Then
		Return SetError($_IESTATUS_InvalidDataType, 1, 0)
	EndIf

	$iIndex = (IsKeyword($iIndex) Or $iIndex < 0) ? -1 : $iIndex
	$sTag = (IsKeyword($sTag) Or Not StringLen($sTag)) ? "" : $sTag

	Local $oTags = (StringLen($sTag)) ? _IETagNameGetCollection($oObj, $sTag, $iIndex) : _
		_IETagNameAllGetCollection($oObj, $iIndex)
	Local $iExtended = @extended
	If Not IsObj($oTags) Then
		Return SetError($_IESTATUS_NoMatch, 2, 0)
	EndIf

	Local $aORet[$iExtended], $iCount
	If $iIndex = -1 Then
		For $oTag In $oTags
			If String($oTag.classname) = $sClass Then
				$aORet[$iCount] = $oTag
				$iCount += 1
			EndIf
		Next
	Else
		$aORet[$iCount] = $oTags.index($iIndex)
		If Not IsObj($aORet[$iCount]) Then
			Return SetError($_IESTATUS_InvalidValue, 3, 0)
		EndIf
		$iCount += 1
	EndIf

	If Not $iCount Then
		Return SetError($_IESTATUS_NoMatch, 4, 0)
	EndIf

	ReDim $aORet[$iCount]

	Return SetError($_IESTATUS_Success, 1, $aORet)
EndFunc   ;==>_IEEx_ClassNameGetArray

;================================================================================================================================
;
; Function Name....:    _IEEx_ClickObjByPoint(ByRef $oObj [, $nX = Default [, $nY = Default ]])
; Description......:    Click the x & y coordinates passed, default click if both x and y are
;                        default, is center object
; Parameter(s).....:
;                       $oObj: Object to click
;                       $nX:   [Optional: Default = Center width;
;                               (Left position from 0 to width of object) to click object]
;                       $nY:   [Optional: Default = Center height;
;                               Top position (from 0 to height of object) to click object]
; Return Value(s)..:
;                       Success...: True : Click() "should" return S_OK (0)
;                       Failure...: False : Check @error
;                       Error.....: 0 = Success, error returns taken from IE.au3
;                                   1 = General Error, 2 = COM Error, 3 = Invalid Data Type
;                                   4 = Invalid Object Type, 5 = Invalid Value
;                                   6 = Load Wait Timeout, 7 = No Match, 8 = Access Denied
;                       Extended..: the number returned is for debugging only, there is data
;                                    returned for both success and failures, it marks the part
;                                    of the code for easier debugging
; Requirement(s)...:
; Author(s)........:    SmOke_N (Ron Nielsen) Ron.SMACKThatApp@gmail.com
; Modified.........:
; Comment(s).......:    This has not been thoroughly tested, may be deprecated or changed
;                        If changed, almost assured to be script breaking
; Example(s).......:    _IEEx_ClickObjByPoint($goDiv, 12, 18)
;
;================================================================================================================================

Func _IEEx_ClickObjByPoint(ByRef $oObj, $nX = Default, $nY = Default)

	If Not IsObj($oObj) Then
		Return SetError($_IESTATUS_InvalidDataType, 1, False)
	EndIf

	Local $oElmRect = Execute("$oObj.getBoundingClientRect()")
	If Not IsObj($oElmRect) Then
		Return SetError($_IESTATUS_InvalidDataType, 2, False)
	EndIf

	Local $aElmRect[4] = [ _
		Number($oElmRect.left), _ ; xpos
		Number($oElmRect.top), _ ; ypos
		Number($oElmRect.right) - Number($oElmRect.left), _ ; width
		Number($oElmRect.bottom) - Number($oElmRect.top)] ; height

	; we'll make default center
	$nX = (($nX = Default) ? $aElmRect[0] + Int($aElmRect[2] / 2) : $nX + $aElmRect[0])
	$nY = (($nY = Default) ? $aElmRect[1] + Int($aElmRect[3] / 2) : $nY + $aElmRect[1])

	Local $iRet = Execute("$oObj.document.elementFromPoint($nX, $nY).click()")
	Return SetError($_IESTATUS_Success, 1, Int($iRet) = 0)
EndFunc   ;==>_IEEx_ClickObjByPoint

;================================================================================================================================
;
; Function Name....:    _IEEx_CreateWithParams($sURL [, $sParams = "" [, $iTryAttach = 0 [, $iVisible = 1 [, _
;                                                  $iWait = 1 [, $iTakeFocus = 1 [, $bReturnObj = True]]]]]])
; Description......:
; Parameter(s).....:
;                       $sURL:       URL to navigate to
;                       $sParams:    Parameters/Switches for iexplore.exe
;                       $iTryAttach: [Optional: Default 0, Try to attach to previous running IE instance]
;                       $iVisible:   [Optional: Default 1, Make IE instance visible]
;                       $iWait:      [Optional: Default 1, Wait for instance to load]
;                       $iTakeFocus: [Optional: Default 1, take focus]
;                       $bReturnObj: [Optional: Default True]; False = Returns PID
; Return Value(s)..:
;                       Success...: New IE Browser Object/Or PID to process
;                       Failure...: 0
;                       Error.....: 0 = Success, error returns taken from IE.au3
;                                   1 = General Error, 2 = COM Error, 3 = Invalid Data Type
;                                   4 = Invalid Object Type, 5 = Invalid Value
;                                   6 = Load Wait Timeout, 7 = No Match, 8 = Access Denied
;                       Extended..: the number returned is for debugging only, there is data
;                                    returned for both success and failures, it marks the part
;                                    of the code for easier debugging
; Requirement(s)...:
; Author(s)........:    SmOke_N (Ron Nielsen) Ron.SMACKThatApp@gmail.com
; Modified.........:
; Comment(s).......:    Created out of need in this post:
;                        http://www.autoitscript.com/forum/topic/166257-execute-iecreate-with-nomerge-parameter/
; Example(s).......:    _IEEx_CreateWithParams("http://autoitscript.com/forum", "-noframemerging")
;
;================================================================================================================================

Func _IEEx_CreateWithParams($sURL, $sParams = "", $iTryAttach = 0, $iVisible = 1, $iWait = 1, $iTakeFocus = 1, $bReturnObj = True)

	Local Const $sHKCR = ((@AutoItX64) ? "HKCR64" : "HKCR")
	Local Static $szCOMIE = FileGetShortName(RegRead($sHKCR & _
		"\CLSID\{0002DF01-0000-0000-C000-000000000046}\LocalServer32",""))
	If Not FileExists(StringReplace($szCOMIE, '"', "")) Then
		$szCOMIE = FileGetShortName(RegRead($sHKCR & _
		"\CLSID\{D5E8041D-920F-45e9-B8FB-B1DEB82C6E5E}\LocalServer32",""))
		If Not FileExists(StringReplace($szCOMIE, '"', "")) Then
			Return SetError($_IESTATUS_NoMatch, 1, 0)
		EndIf
	EndIf

	$bReturnObj = ((($bReturnObj = Default) Or ($bReturnObj)) ? True : False)

	Local $oRet
	If $iTryAttach Then
		$oRet = _IEEx_TabAttach($sURL, "URL")
		If IsObj($oRet) Then
			$oRet.visible = $iVisible
			If $iVisible And $iTakeFocus Then
				WinActivate($oRet.hwnd)
			EndIf
			Return SetError($_IEStatus_Success, 1, (($bReturnObj) _
				? $oRet : WinGetProcess($oRet.hwnd)))
		EndIf
	EndIf

	; get current shell windows open and their count
	Local $oShell = ObjCreate("Shell.Application")
	Local $oWin, $nCount = $oShell.windows.count()

	$sParams = (StringLen($sParams) > 0) ? " " & $sParams : ""

	Local $iTimer = TimerInit() ; set a 5 minute timeout
	Local $iPID = Run($szCOMIE & $sParams & ' "' & $sURL & '"')
	While 1
		$oWin = $oShell.windows()
		If $oWin.count() <> $nCount Then
			$nCount = $oWin.count()
			$oRet = $oWin($nCount - 1)
			If $oRet.TopLevelContainer Then ExitLoop
		EndIf
		If (TimerDiff($iTimer) / 1000) >= 300 Then
			; timed out waiting, close IE instance
			ProcessClose($iPID)
			Return SetError($_IESTATUS_LoadWaitTimeout, 2, 0)
		EndIf
		Sleep(10)
	WEnd

	If Not $iVisible Then
		$iTakeFocus = 0
		$oRet.visible = False
	EndIf

	If $iTakeFocus Then
		WinActivate($oRet.hwnd)
	EndIf

	If $iWait Then
		_IELoadWait($oRet)
		If @error Then
			Return SetError(@error, 3, $oRet)
		EndIf
	EndIf

	Return SetError($_IEStatus_Success, 2, (($bReturnObj) _
		? $oRet : WinGetProcess($oRet.hwnd)))
EndFunc   ;==>_IEEx_CreateWithParams

;================================================================================================================================
;
; Function Name....:    _IEEx_EmbeddedGetVersion()
; Description......:    Return what embedded version you run when you use something like _IECreateEmbedded
; Parameter(s).....:    none
; Return Value(s)..:
;                       Success...:  The "numbered" version
;                                    x.0 = Default
;                                    x.1 = Standard or Edge
;                       Failure...:  Default 7.0 version number returned
; Requirement(s)...:
; Author(s)........:    SmOke_N (Ron Nielsen) Ron.SMACKThatApp@gmail.com
; Modified.........:
; Comment(s).......:    This is only used for the app you're working in
; Example(s).......:
;
;================================================================================================================================

Func _IEEx_EmbeddedGetVersion()

	Local Const $sHKCU = ((@AutoItX64) ? "HKCU64" : "HKCU")
	Local Const $sFBE = $sHKCU & "\Software\Microsoft\Internet Explorer\Main\" & _
			"FeatureControl\FEATURE_BROWSER_EMULATION"

	Local Static $sExe = StringRegExpReplace(@AutoItExe, "(.+?[/\\]+)*(.+?)\z", "$2")

	Local $sCurr = RegRead($sFBE, $sExe)
	If @error Then $sCurr = 7000

	;n.0 = default; n.1 = standard or edge

	Local  $nRet = 0.0
	Switch Int($sCurr)
		Case 7000
			$nRet = 7.0
		Case 8000
			$nRet = 8.0
		Case 8888
			$nRet = 8.1
		Case 9000
			$nRet = 9.0
		Case 9999
			$nRet = 9.1
		Case 10000
			$nRet = 10.0
		Case 10001
			$nRet = 10.1
		Case 11000
			$nRet = 11.0
		Case 11001
			$nRet = 11.1
		Case Else
			$nRet = Number(StringTrimRight($sCurr, 3))
	EndSwitch

	Return SetError($_IESTATUS_Success, 1, $nRet)
EndFunc   ;==>_IEEx_EmbeddedGetVersion

;================================================================================================================================
;
; Function Name....:    _IEEx_EmbeddedSetVersion([$iVersion = Default [, $bDefaultMode = Default]])
; Description......:    Set or Delete the exe's IE version to use on embedded objects
; Parameter(s).....:
;                       $iVersion:     (Optional: Default = Major version of IE from _IECreate())
;                                       Can be 7-11 (currently 11 is max)
;                                       Empty String = Delete exe name from registry entry, revert back to basic (eg. 7.0)
;                       $bDefaultMode: (Optional: Default = True: Non Standard or Edge mode) True or False
; Return Value(s)..:
;                       Success...: The version registry number value that it was changed to
;                       Failure...: 0
;                       Error.....: 0 = Success, error returns taken from IE.au3
;                                   1 = General Error, 2 = COM Error, 3 = Invalid Data Type
;                                   4 = Invalid Object Type, 5 = Invalid Value
;                                   6 = Load Wait Timeout, 7 = No Match, 8 = Access Denied
;                       Extended..: the number returned is for debugging only, there is data
;                                    returned for both success and failures, it marks the part
;                                    of the code for easier debugging
; Requirement(s)...:
; Author(s)........:    SmOke_N (Ron Nielsen) Ron.SMACKThatApp@gmail.com
; Modified.........:
; Comment(s).......:    If you change the version, you must restart your script/exe in order for the changes to take place
; Example(s).......:    _IEEx_EmbeddedSetVersion() ; set embedded to major version used by _IECreate()
;
;================================================================================================================================

Func _IEEx_EmbeddedSetVersion($iVersion = Default, $bDefaultMode = Default)

	Local Const $sHKCR = ((@AutoItX64) ? "HKCR64" : "HKCR")
	Local Static $szCOMIE = StringReplace(FileGetShortName(RegRead($sHKCR & _
			"\CLSID\{0002DF01-0000-0000-C000-000000000046}\LocalServer32", "")), '"', "")

	$iVersion = (($iVersion = Default) ? Int(FileGetVersion($szCOMIE)) : $iVersion)

	Local $bDelete = (Not StringLen($iVersion))

	Local $nRegVers

	; http://msdn.microsoft.com/en-us/library/ie/ee330730%28v=vs.85%29.aspx
	Switch $iVersion
		Case 7
			$nRegVers = 0x1B58
		Case 8
			$nRegVers = (($bDefaultMode = Default Or $bDefaultMode) ? 0x1F40 : 0x22B8)
		Case 9
			$nRegVers = (($bDefaultMode = Default Or $bDefaultMode) ? 0x2328 : 0x270F)
		Case 10
			$nRegVers = (($bDefaultMode = Default Or $bDefaultMode) ? 0x2710 : 0x2711)
		Case 11
			$nRegVers = (($bDefaultMode = Default Or $bDefaultMode) ? 0x2AF8 : 0x2AF9)
	EndSwitch

	Local Const $sHKCU = ((@AutoItX64) ? "HKCU64" : "HKCU")
	Local Const $sFBE = $sHKCU & "\Software\Microsoft\Internet Explorer\Main\" & _
			"FeatureControl\FEATURE_BROWSER_EMULATION"

	Local Static $sExe = StringRegExpReplace(@AutoItExe, "(.+?[/\\]+)*(.+?)\z", "$2")

	; is key already set?
	Local $sCurr = RegRead($sFBE, $sExe)

	If $bDelete Then
		RegDelete($sFBE, $sExe)
		$sCurr = ((Int($sCurr)) ? Int($sCurr) : 1)
		Return SetError($_IESTATUS_Success, 1, $sCurr)
	EndIf

	If Not $nRegVers Then
		Return SetError($_IESTATUS_NoMatch, 1, 0)
	EndIf

	; is key already set?
	$sCurr = RegRead($sFBE, $sExe)
	If Int($sCurr) = $nRegVers Then
		Return SetError($_IESTATUS_Success, 2, $nRegVers)
	EndIf

	RegWrite($sFBE, $sExe, "REG_DWORD", $nRegVers)
	If @error Then
		Return SetError($_IESTATUS_GeneralError, 2, 0)
	EndIf

	Return SetError($_IESTATUS_Success, 3, $nRegVers)
EndFunc   ;==>_IEEx_EmbeddedSetVersion

;================================================================================================================================
;
; Function Name....:    _IEEx_GetAppMajorVersion(ByRef $oObj)
; Description......:    Retrieves the Major version of the IE instance you're running
; Parameter(s).....:
;                       $oObj:  The browser object you're working with
; Return Value(s)..:
;                       Success...: Application version integer
;                       Failure...: 0
;                       Error.....: 0 = Success, error returns taken from IE.au3
;                                   1 = General Error, 2 = COM Error, 3 = Invalid Data Type
;                                   4 = Invalid Object Type, 5 = Invalid Value
;                                   6 = Load Wait Timeout, 7 = No Match, 8 = Access Denied
;                       Extended..: the number returned is for debugging only, there is data
;                                    returned for both success and failures, it marks the part
;                                    of the code for easier debugging
; Requirement(s)...:
; Author(s)........:    SmOke_N (Ron Nielsen) Ron.SMACKThatApp@gmail.com
; Modified.........:
; Comment(s).......:
; Example(s).......:    _IEEx_GetAppMajorVersion($goIE)
;
;================================================================================================================================

Func _IEEx_GetAppMajorVersion(ByRef $oObj)

	If $__gn_IEExAppMajorVersion Then
		If Not _IEEx_CheckAppVersionAlways() Then
			Return SetError($_IEStatus_Success, 1, $__gn_IEExAppMajorVersion)
		EndIf
	EndIf

	If Not IsObj($oObj) Then
		$__gn_IEExAppMajorVersion = 0
		Return SetError($_IESTATUS_InvalidDataType, 1, 0)
	EndIf

	Local $sExePath = String(Execute("$oObj.fullName"))
	Local $sExe = StringRegExpReplace($sExePath, "((?:.+?[\\/]+)+)(.+?\.\w+)\z", "$2")
	Local $iVersion = 0

	Switch $sExe
		Case "iexplore.exe"
			$iVersion = Int(FileGetVersion($oObj.fullName()))
		Case Else
			Switch StringLower(_IEEx_GetObjType($oObj))
				Case "document"
					$iVersion = $oObj.parentWindow.top.navigator.userAgent
				Case "window"
					$iVersion = $oObj.top.navigator.userAgent
				Case Else
					$iVersion = $oObj.document.parentWindow.top.navigator.userAgent
			EndSwitch
			$iVersion = Int(StringRegExpReplace($iVersion, "(?i)(.*?msie\s*)(\d+)(.*?)", "$2"))
	EndSwitch

	If Not $iVersion Then
		$__gn_IEExAppMajorVersion = 0
		Return SetError($_IEStatus_NoMatch, 6, 0)
	EndIf

	$__gn_IEExAppMajorVersion = $iVersion

	Return SetError($_IEStatus_Success, 2, $iVersion)
EndFunc   ;==>_IEEx_GetAppMajorVersion

;================================================================================================================================
;
; Function Name....:    _IEEx_GetObjByClassName(ByRef $oObj, $sClass [, $sTag = Default [, $iIndex = Default]])
; Description......:    Get the class name object
; Parameter(s).....:
;                       $oObj:   The document/form/browser/window object you're working with
;                       $sClass: The class string you want to find
;                       $sTag:   [Optional: Default = Empty String], the tag name type you want to search in
;                       $iIndex: [Optional: Default = 0 (first found)]; The index number you want to return
; Return Value(s)..:
;                       Success...: The class object
;                       Failure...: 0
;                       Error.....: 0 = Success, error returns taken from IE.au3
;                                   1 = General Error, 2 = COM Error, 3 = Invalid Data Type
;                                   4 = Invalid Object Type, 5 = Invalid Value
;                                   6 = Load Wait Timeout, 7 = No Match, 8 = Access Denied
;                       Extended..: the number returned is for debugging only, there is data
;                                    returned for both success and failures, it marks the part
;                                    of the code for easier debugging
; Requirement(s)...:
; Author(s)........:    SmOke_N (Ron Nielsen) Ron.SMACKThatApp@gmail.com
; Modified.........:
; Comment(s).......:
; Example(s).......:
;
;================================================================================================================================

Func _IEEx_GetObjByClassName(ByRef $oObj, $sClass, $sTag = Default, $iIndex = Default)

	Local $aOClass = _IEEx_ClassNameGetArray($oObj, $sClass, $sTag)
	If @error Then
		Return SetError(@error, @extended, 0)
	EndIf

	$iIndex = ((IsKeyword($iIndex) Or $iIndex < 0) ? 0 : $iIndex)

	Local $nUbound = UBound($aOClass) - 1
	If $iIndex > $nUbound Then
		Return SetError($_IESTATUS_InvalidValue, 6, 0)
	EndIf

	Return SetError($_IEStatus_Success, 1, $aOClass[$iIndex])
EndFunc   ;==>_IEEx_GetObjByClassName

;================================================================================================================================
;
; Function Name....:    _IEEx_GetObjByString(ByRef $oObj, $sFind [, $sTag = "" [, $iIndex = -1 [, _
;                                            $sByType = "byText" [, $bInStr = False)]]]]
; Description......:    Retrieve an Array of objects that match the text you are searching for with innerText or value
; Parameter(s).....:
;                       $oObj:    The object you are working with
;                       $sFind:   The string you want to search
;                       $sTag:    [Optional: Default = Empty String]; The tag type you want to search
;                       $iIndex:  [Optional: Default = -1 (All)]; The index number (starting with 0) that you want to return
;                       $sByType: [Optional: Default = "ByText"]; A string that represents the type of search you want to do
;                                  "ByText" or "Text" = innerText
;                                  "ByValue" or "Value" = value
;                       $bInStr:  [Optional: Default = False]; Boolean to search for with StringInStr or not
; Return Value(s)..:
;                       Success...: An array of objects that match the search string
;                       Failure...: 0
;                       Error.....: 0 = Success, error returns taken from IE.au3
;                                   1 = General Error, 2 = COM Error, 3 = Invalid Data Type
;                                   4 = Invalid Object Type, 5 = Invalid Value
;                                   6 = Load Wait Timeout, 7 = No Match, 8 = Access Denied
;                       Extended..: the number returned is for debugging only, there is data
;                                    returned for both success and failures, it marks the part
;                                    of the code for easier debugging
; Requirement(s)...:
; Author(s)........:    SmOke_N (Ron Nielsen) Ron.SMACKThatApp@gmail.com
; Modified.........:
; Comment(s).......:
; Example(s).......:
;
;================================================================================================================================

Func _IEEx_GetObjByString(ByRef $oObj, $sFind, $sTag = "", $iIndex = -1, _
		$sByType = "byText", $bInStr = False)

	If Not IsObj($oObj) Then
		Return SetError($_IESTATUS_InvalidDataType, 1, 0)
	EndIf

	$sTag = (IsKeyword($sTag) Or Not StringLen($sTag)) ? "" : $sTag
	$iIndex = (IsKeyword($iIndex) Or $iIndex < 0) ? -1 : $iIndex
	$sByType = (IsKeyword($iIndex)) ? "byText" : $sByType
	$bInStr = ($bInStr = Default) ? False : $bInStr
	$sByType = StringLower($sByType)

	; validate good type passed
	Switch $sByType
		Case "bytext", "text", "byvalue", "value"
		Case Else
			Return SetError($_IESTATUS_InvalidValue, 2, 0)
	EndSwitch

	Local $oTags = (StringLen($sTag)) ? _IETagNameGetCollection($oObj, $sTag, $iIndex) : _
		_IETagNameAllGetCollection($oObj, $iIndex)
	Local $iExtended = @extended
	If Not IsObj($oTags) Then
		Return SetError($_IESTATUS_NoMatch, 3, 0)
	EndIf

	Local $aRet[$iExtended], $iCount, $sVal
	If $iIndex = -1 Then
		For $oTag In $oTags
			$sVal = ""
			Switch $sByType
				Case "bytext", "text"
					$sVal = String(Execute("$oTag.innerText()"))
				Case "byvalue", "value"
					$sVal = String(Execute("$oTag.value()"))
			EndSwitch
			If $bInStr Then
				If StringInStr($sVal, $sFind) Then
					$aRet[$iCount] = $oTag
					$iCount += 1
				EndIf
			Else
				If $sVal = $sFind Then
					$aRet[$iCount] = $oTag
					$iCount += 1
				EndIf
			EndIf
		Next
	Else
		Switch $sByType
			Case "bytext", "text"
				$sVal = String(Execute("$oTags.innerText()"))
			Case "byvalue", "value"
				$sVal = String(Execute("$oTags.value()"))
		EndSwitch
		If $bInStr Then
			If StringInStr($sVal, $sFind) Then
				$aRet[$iCount] = $oTags.index($iIndex)
				If Not IsObj($aRet[$iCount]) Then
					Return SetError($_IESTATUS_InvalidValue, 4, 0)
				EndIf
				$iCount += 1
			EndIf
		Else
			If $sVal = $sFind Then
				$aRet[$iCount] = $oTags.index($iIndex)
				If Not IsObj($aRet[$iCount]) Then
					Return SetError($_IESTATUS_InvalidValue, 5, 0)
				EndIf
				$iCount += 1
			EndIf
		EndIf
	EndIf

	If Not $iCount Then
		Return SetError($_IESTATUS_NoMatch, 6, 0)
	EndIf

	ReDim $aRet[$iCount]
	Return SetError($_IESTATUS_Success, 2, 1)
EndFunc

;================================================================================================================================
;
; Function Name....:    _IEEx_GetObjEval(ByRef $oObj)
; Description......:    Return the eval object, like: obj.document.parentWindow.eval <- this fails in some IE versions
;                        this is an attempt to help it work with all versions
; Parameter(s).....:
;                       $oObj: The object you are working with
; Return Value(s)..:
;                       Success...: Eval object
;                       Failure...: 0
;                       Error.....: 0 = Success, error returns taken from IE.au3
;                                   1 = General Error, 2 = COM Error, 3 = Invalid Data Type
;                                   4 = Invalid Object Type, 5 = Invalid Value
;                                   6 = Load Wait Timeout, 7 = No Match, 8 = Access Denied
;                       Extended..: the number returned is for debugging only, there is data
;                                    returned for both success and failures, it marks the part
;                                    of the code for easier debugging
; Requirement(s)...:
; Author(s)........:    SmOke_N (Ron Nielsen) Ron.SMACKThatApp@gmail.com
; Modified.........:
; Comment(s).......:
; Example(s).......:    $goEval = _IEEx_GetObjEval($goIE)
;                       MsgBox(64, "Info", $goEval('4+4;'))
;
;================================================================================================================================

Func _IEEx_GetObjEval(ByRef $oObj)
	; return the same thing as obj.document.parentwindow.eval object

	If Not IsObj($oObj) Then
		Return SetError($_IESTATUS_InvalidDataType, 1, 0)
	EndIf

	; our insert object, if the page is still on the same load
	;  we will try to get the eval object from the div
	Local $oDPWE = Execute('$oObj.document.getElementById("IEExAutEvalObjId")')

	If IsObj($oDPWE) Then
		$oDPWE = $oDPWE.IEExAutEvalObj
		If IsObj($oDPWE) Then
			Return SetError($_IESTATUS_Success, 1, $oDPWE)
		EndIf
	EndIf

	; I'm tempted to just make this a straight JS func
	;  but I'll leave it as is for now

	; is this a browser object?
	$oDPWE = Execute("$oObj.document.parentWindow.eval")
	If IsObj($oDPWE) Then
		Return SetError($_IESTATUS_Success, 2, $oDPWE)
	EndIf

	; is this an obj.document object?
	$oDPWE = Execute("$oObj.parentWindow.eval")
	If IsObj($oDPWE) Then
		Return SetError($_IESTATUS_Success, 3, $oDPWE)
	EndIf

	; is this an obj.document.parentwindow object?
	$oDPWE = Execute("$oObj.eval")
	If IsObj($oDPWE) Then
		Return SetError($_IESTATUS_Success, 4, $oDPWE)
	EndIf

	; If the version is higher than IE10, execScript is no more
	;  so we will only check if we can get a valid standard eval
	; There is a recursion issue when wanting to execute a javascript
	;  script otherwise unfortunately because of constant calls for exeScript
	;  where execScript function here checks for eval option if the version
	;   is too high
	If $__gb_IEExEvalCheckRecursion Then
		$__gb_IEExEvalCheckRecursion = False
		Return SetError($_IESTATUS_NoMatch, 2, 0)
	EndIf

	; prevent execScript crash
	; if this proves to fail miserably, something else will have to
	;  be thought of to accomplish execScript without the use of eval
	;  in IE 9 and sometimes IE 10
;~ 	If _IEEx_GetAppMajorVersion($oObj) < 11 Then
		; at this point, we've failed, I've experienced this on IE9
		;  I'm fairly certain it's a compatibility mode issue, I remember
		;  some time ago reading that the JS parser for IE9 was broke for
		;  some items
		; so now we are going to use a custom insert js function to get the
		;  eval object, hopefully this works, and we really only want to
		;  use it as a last resort

		; some might not know, but JS global variables are stored in windows
		;  object array
		$oDPWE = __IEEx_GetContainerObj($oObj, "EvalObj")
		If Not @error Then
			Return SetError($_IESTATUS_Success, 5, $oDPWE.IEExAutEvalObj)
		EndIf
;~ 	EndIf

	; at this point, we've tried to inject JS and we have still failed
	;  let's check if JS is enabled, that way the programmer can
	;  choose to enable/disable whatever from the error + extended info
	If Not _IEEx_JSIsEnabled() Then
		Return SetError($_IESTATUS_AccessIsDenied, 3, 0)
	EndIf

	Return SetError($_IESTATUS_InvalidObjectType, 4, 0)
EndFunc   ;==>_IEEx_GetObjEval

;================================================================================================================================
;
; Function Name....:    _IEEx_GetObjParentWindow(ByRef $oObj)
; Description......:    Returns the parent window of the object, like: object.document.parentWindow
; Parameter(s).....:
;                       $oObj: The object you are working on
; Return Value(s)..:
;                       Success...: The parentWindow object to the object passed
;                       Failure...: 0
;                       Error.....: 0 = Success, error returns taken from IE.au3
;                                   1 = General Error, 2 = COM Error, 3 = Invalid Data Type
;                                   4 = Invalid Object Type, 5 = Invalid Value
;                                   6 = Load Wait Timeout, 7 = No Match, 8 = Access Denied
;                       Extended..: the number returned is for debugging only, there is data
;                                    returned for both success and failures, it marks the part
;                                    of the code for easier debugging
; Requirement(s)...:
; Author(s)........:    SmOke_N (Ron Nielsen) Ron.SMACKThatApp@gmail.com
; Modified.........:
; Comment(s).......:    This doesn't do a traditional step back/forward process, there were only a few
;                         conditions I was testing for, saw no need for it, but this may change.
; Example(s).......:
;
;================================================================================================================================

Func _IEEx_GetObjParentWindow(ByRef $oObj)
	; return the same thing as obj.document.parentwindow object

	If Not IsObj($oObj) Then
		Return SetError($_IESTATUS_InvalidDataType, 1, 0)
	EndIf

	; if it's just obj
	Local $oDPWE = Execute("$oObj.document.parentWindow")
	If IsObj($oDPWE) Then
		Return SetError($_IESTATUS_Success, 1, $oDPWE)
	EndIf

	; is it already obj.document?
	$oDPWE = Execute("$oObj.parentWindow")
	If IsObj($oDPWE) Then
		Return SetError($_IESTATUS_Success, 2, $oDPWE)
	EndIf

	$oDPWE = _IEEx_CallObjEval($oObj, "document.parentWindow")
	If IsObj($oDPWE) Then
		Return SetError($_IESTATUS_Success, 3, $oDPWE)
	EndIf

	Return SetError($_IESTATUS_InvalidObjectType, 2, 0)
EndFunc   ;==>_IEEx_GetObjParentWindow

;================================================================================================================================
;
; Function Name....:    _IEEx_GetObjPos(ByRef $oObj)
; Description......:    Returns an rect array of the Left, Top, Width, Height of the element object relative to the body object
; Parameter(s).....:
;                       $oObj: The object you are working on
; Return Value(s)..:
;                       Success...: A 1-dimensional array
;                                   [0] = Left (x) position
;                                   [1] = Top (y) position
;                                   [2] = Width
;                                   [3] = Height
;                       Failure...: 0
;                       Error.....: 0 = Success, error returns taken from IE.au3
;                                   1 = General Error, 2 = COM Error, 3 = Invalid Data Type
;                                   4 = Invalid Object Type, 5 = Invalid Value
;                                   6 = Load Wait Timeout, 7 = No Match, 8 = Access Denied
;                       Extended..: the number returned is for debugging only, there is data
;                                    returned for both success and failures, it marks the part
;                                    of the code for easier debugging
; Requirement(s)...:
; Author(s)........:    SmOke_N (Ron Nielsen) Ron.SMACKThatApp@gmail.com
; Modified.........:
; Comment(s).......:    The size/position/point functions are works in progress, some of these functions
;                        are only good for "visible" area
; Example(s).......:
;
;================================================================================================================================

Func _IEEx_GetObjPos(ByRef $oObj)

	If Not IsObj($oObj) Then
		Return SetError($_IESTATUS_InvalidDataType, 1, 0)
	EndIf

	Local $nX = 0
	Local $nY = 0
	Local $nOffsetLeft, $nOffsetTop
	Local $oTmp = $oObj

	While IsObj($oTmp)
		$nOffsetLeft = Execute("$oTmp.offsetLeft")
		$nOffsetTop = Execute("$oTmp.offsetTop")
		If Not IsNumber($nOffsetLeft) Or Not IsNumber($nOffsetTop) Then
			ExitLoop
		EndIf

		$nX += (Number($nOffsetLeft) - Number(Execute("$oTmp.scrollLeft")))
		$nY += (Number($nOffsetTop) - Number(Execute("$oTmp.scrollTop")))
		$oTmp = Execute("$oTmp.offsetParent")
	WEnd

	Local $oRect = Execute("$oObj.getBoundingClientRect()")
	If Not IsObj($oRect) Then
		Return SetError($_IESTATUS_InvalidDataType, 2, 0)
	EndIf

	Local $aORet[] = [$nX, $nY, $oRect.right - $oRect.left, $oRect.bottom - $oRect.top]
	Return SetError($_IESTATUS_Success, 1, $aORet)
EndFunc   ;==>_IEEx_GetObjPos

;================================================================================================================================
;
; Function Name....:    _IEEx_GetObjType(ByRef $oObj)
; Description......:    An attempt to return the type of object passed, similar to IE.au3's
;                       __IEIsObjType (in reverse)
; Parameter(s).....:
;                       $oObj: Object you are working with
; Return Value(s)..:
;                       Success...: String value of the object type
;                       Failure...: Empty String
;                       Error.....: 0 = Success, error returns taken from IE.au3
;                                   1 = General Error, 2 = COM Error, 3 = Invalid Data Type
;                                   4 = Invalid Object Type, 5 = Invalid Value
;                                   6 = Load Wait Timeout, 7 = No Match, 8 = Access Denied
;                       Extended..: the number returned is for debugging only, there is data
;                                    returned for both success and failures, it marks the part
;                                    of the code for easier debugging
; Requirement(s)...:
; Author(s)........:    SmOke_N (Ron Nielsen) Ron.SMACKThatApp@gmail.com
; Modified.........:
; Comment(s).......:    This is not technical, I simply reversed the __IEIsObjType() function to suit my needs
;                        for what I was doing at the time, I think I was working with form objects when the need
;                        arose for it
; Example(s).......:
;
;================================================================================================================================

Func _IEEx_GetObjType(ByRef $oObj)

	; this function could use some work, but for now it was
	;  serving my purposes

	If Not IsObj($oObj) Then
		Return SetError($_IESTATUS_InvalidDataType, 1, "")
	EndIf

	Local $sObjName = String(ObjName($oObj))
	Local $sType = String(Execute("$oObj.type"))

	Switch $sObjName
		Case "IWebBrowser2", "IWebBrowser", "WebBrowser"
			Return SetError($_IESTATUS_Success, 1, "browser")
		Case "DispHTMLWindow2", "DispHTMLWindow", "HTMLWindow", "HTMLWindow2"
			Return SetError($_IESTATUS_Success, 2, "window")
		Case "DispHTMLDocument", "HTMLDocument"
			Return SetError($_IESTATUS_Success, 3, "document")
		Case "DispHTMLTable", "HTMLTable"
			Return SetError($_IESTATUS_Success, 4, "table")
		Case "DispHTMLFormElement", "HTMLFormElement"
			Return SetError($_IESTATUS_Success, 5, "form")
		Case "DispHTMLInputElement", "HTMLInputElement"
			Return ((StringLen($sType) > 0) ? _
				SetError($_IESTATUS_Success, 6, $sType) : _
				SetError($_IESTATUS_Success, 8, "input"))
		Case "DispHTMLSelectElement", "HTMLSelectElement"
			Return ((StringLen($sType) > 0) ? _
				SetError($_IESTATUS_Success, 9, $sType) : _
				SetError($_IESTATUS_Success, 10, "drop-down"))
		Case "DispHTMLTextAreaElement", "HTMLTextAreaElement"
			Return ((StringLen($sType) > 0) ? _
				SetError($_IESTATUS_Success, 11, $sType) : _
				SetError($_IESTATUS_Success, 12, "edit"))
		Case "DispHTMLElementCollection", "HTMLElementCollection"
			Return "elementCollection"
	EndSwitch

	$sType = StringLower(Execute("$oObj.NodeName"))
	Return ((StringLen($sType) > 0) ? _
		SetError($_IESTATUS_Success, 13, $sType) : _
		SetError($_IESTATUS_NoMatch, 2, ""))
EndFunc   ;==>_IEEx_GetObjType

;================================================================================================================================
;
; Function Name....:    _IEEx_GetScroll(ByRef $oObj [, $sPos = Default])
; Description......:    Returns the position of the scrollbar, Left or Top
; Parameter(s).....:
;                       $oObj:  The browser object you're working with
;                       $sPos:  [Optional:  Default = Top, other = Left]
; Return Value(s)..:
;                       Success...: The scroll position number
;                       Failure...: 0
;                       Error.....: 0 = Success, error returns taken from IE.au3
;                                   1 = General Error, 2 = COM Error, 3 = Invalid Data Type
;                                   4 = Invalid Object Type, 5 = Invalid Value
;                                   6 = Load Wait Timeout, 7 = No Match, 8 = Access Denied
;                       Extended..: the number returned is for debugging only, there is data
;                                    returned for both success and failures, it marks the part
;                                    of the code for easier debugging
; Requirement(s)...:
; Author(s)........:    SmOke_N (Ron Nielsen) Ron.SMACKThatApp@gmail.com
; Modified.........:
; Comment(s).......:    Currently untested (at all!)
; Example(s).......:    _IEEx_GetScroll($goIE) or _IEEx_GetScroll($goIE, "Left")
;
;================================================================================================================================

Func _IEEx_GetScroll(ByRef $oObj, $sPos = Default)
	; default = Top, so Top or Left only choices
	; see: http://www.softcomplex.com/docs/get_window_size_and_scrollbar_position.html
	; Thanks Kevin D.
	If Not IsObj($oObj) Then
		Return SetError($_IESTATUS_InvalidDataType, 1, 0)
	EndIf

	Local $oEval = _IEEx_GetObjEval($oObj)
	If Not IsObj($oEval) Then
		Return SetError($_IESTATUS_InvalidDataType, 2, 0)
	EndIf

	Local Const $aTypes[2][2] = [ _
		["pageYOffset","scrollTop"], ["pageXOffset","scrollLeft"]]
	Local $nPos = ($sPos = Default Or $sPos = "Top") ? 0 : 1
	Local $nScroll = 0

	If $oEval("(typeof(window." & $aTypes[$nPos][0] & ") == 'number')") Then
		; DOM compliant, IE9+
		$nScroll = $oEval("window." & $aTypes[$nPos][0] & ";")
	Else
		; IE6-8 workaround
		If $oEval("(document.body && document.body." & _
			$aTypes[$nPos][1] & ")") Then
			; IE quirks mode
			$nScroll = $oEval("document.body." & $aTypes[$nPos][1] & ";")
		ElseIf $oEval("(document.documentElement && document.documentElement." & _
			$aTypes[$nPos][1] & ")") Then
			; IE6+ standards compliant mode
            $nScroll = $oEval("document.documentElement." & $aTypes[$nPos][1] & ";")
		EndIf
	EndIf

	Return Number($nScroll)
EndFunc   ;==>_IEEx_GetScroll

;================================================================================================================================
;
; Function Name....:    _IEEx_GetScrollPoint(ByRef $oObj)
; Description......:    Return the Top and Left scroll positions
; Parameter(s).....:
;                       $oObj:  The browser object you're working with
; Return Value(s)..:
;                       Success...: An array:
;                                    [0] = Top/Y Pos
;                                    [1] = Left/Y Pos
;                       Failure...: 0
;                       Error.....: 0 = Success, error returns taken from IE.au3
;                                   1 = General Error, 2 = COM Error, 3 = Invalid Data Type
;                                   4 = Invalid Object Type, 5 = Invalid Value
;                                   6 = Load Wait Timeout, 7 = No Match, 8 = Access Denied
;                       Extended..: the number returned is for debugging only, there is data
;                                    returned for both success and failures, it marks the part
;                                    of the code for easier debugging
; Requirement(s)...:
; Author(s)........:    SmOke_N (Ron Nielsen) Ron.SMACKThatApp@gmail.com
; Modified.........:
; Comment(s).......:    Currently untested (at all!)
; Example(s).......:    _IEEx_GetScrollPoint($goIE)
;
;================================================================================================================================

Func _IEEx_GetScrollPoint(ByRef $oObj)
	; [0] = Top/Y; [1] = Left/X
	; see: http://www.softcomplex.com/docs/get_window_size_and_scrollbar_position.html
	; Thanks Kevin D.
	If Not IsObj($oObj) Then
		Return SetError($_IESTATUS_InvalidDataType, 1, 0)
	EndIf

	Local $oEval = _IEEx_GetObjEval($oObj)
	If Not IsObj($oEval) Then
		Return SetError($_IESTATUS_InvalidDataType, 2, 0)
	EndIf

	Local Const $aTypes[2][2] = [ _
		["pageXOffset","scrollLeft"], ["pageYOffset","scrollTop"]]
	Local $aRet[] = [0,0]
	Local $nScroll = 0

	For $nPos = 0 To UBound($aRet) - 1
		If $oEval("(typeof(window." & $aTypes[$nPos][0] & ") == 'number')") Then
			; DOM compliant, IE9+
			$nScroll = $oEval("window." & $aTypes[$nPos][0] & ";")
		Else
			; IE6-8 workaround
			If $oEval("(document.body && document.body." & _
				$aTypes[$nPos][1] & ")") Then
				; IE quirks mode
				$nScroll = $oEval("document.body." & $aTypes[$nPos][1] & ";")
			ElseIf $oEval("(document.documentElement && document.documentElement." & _
				$aTypes[$nPos][1] & ")") Then
				; IE6+ standards compliant mode
				$nScroll = $oEval("document.documentElement." & $aTypes[$nPos][1] & ";")
			EndIf
		EndIf
		$aRet[$nPos] = Number($nScroll)
		$nScroll = 0
	Next

	Return $aRet
EndFunc   ;==>_IEEx_GetScrollPoint

;================================================================================================================================
;
; Function Name....:    _IEEx_GetWindowSize()
; Description......:    Return the width and height of the current document
; Parameter(s).....:
;                       $oObj:  The browser or document object
; Return Value(s)..:
;                       Success...: An array:
;                                    [0] = width
;                                    [1] = height
;                       Failure...: 0
;                       Error.....: 0 = Success, error returns taken from IE.au3
;                                   1 = General Error, 2 = COM Error, 3 = Invalid Data Type
;                                   4 = Invalid Object Type, 5 = Invalid Value
;                                   6 = Load Wait Timeout, 7 = No Match, 8 = Access Denied
;                       Extended..: the number returned is for debugging only, there is data
;                                    returned for both success and failures, it marks the part
;                                    of the code for easier debugging
; Requirement(s)...:
; Author(s)........:    SmOke_N (Ron Nielsen) Ron.SMACKThatApp@gmail.com
; Modified.........:
; Comment(s).......:    Currently untested (at all!)
; Example(s).......:    _IEEx_GetWindowSize($goIE)
;
;================================================================================================================================

Func _IEEx_GetWindowSize(ByRef $oObj)
	; [0] = Width; [1] = Height
	; see: http://www.softcomplex.com/docs/get_window_size_and_scrollbar_position.html
	; Thanks Kevin D.
	If Not IsObj($oObj) Then
		Return SetError($_IESTATUS_InvalidDataType, 1, 0)
	EndIf

	Local $oEval = _IEEx_GetObjEval($oObj)
	If Not IsObj($oEval) Then
		Return SetError($_IESTATUS_InvalidDataType, 2, 0)
	EndIf

	Local Const $aTypes[2][2] = [ _
		["innerWidth","clientWidth"], ["innerHeight","clientHeight"]]
	Local $aRet[] = [0,0]
	Local $nWindow = 0
	Local $nIEStrict = 0
	Local $nIEQuirks = 0

	For $nPos = 0 To 1
		If $oEval("(typeof(window." & $aTypes[$nPos][0] & ") == 'number')") Then
			; DOM compliant, IE9+
			$nWindow = $oEval("window." & $aTypes[$nPos][0] & ";")
		Else
			; IE6-8 workaround, Note: document can be smaller than window
			$nIEStrict = $oEval("document.documentElement." & $aTypes[$nPos][1] & ";"); w/out DTD gives 0
			$nIEQuirks = $oEval("document.body." & $aTypes[$nPos][1] & ";"); w/DTD gives document height
			$nWindow = ($nIEStrict > 0) ? $nIEStrict : $nIEQuirks
		EndIf
		$aRet[$nPos] = Number($nWindow)
		$nWindow = 0
	Next

	Return $aRet
EndFunc   ;==>_IEEx_GetWindowSize

;================================================================================================================================
;
; Function Name....:    _IEEx_ObjCheckBoxRadioSelect(ByRef $oObj [, $bSelect = True [, $sEvents = "onchange|onclick" [, _
;                                          $sEventType = "fireEvent"]]])
; Description......:    Check or Uncheck a checkbox/radio control, use fireEvent or dispatchEvent for events
; Parameter(s).....:
;                       $oObj:       Element object to check/uncheck
;                       $bSelect:    [Optional: Default = True]
;                                     True = Check
;                                     False = Uncheck
;                       $sEvents:    [Optional: Default = "onchange|onclick"]; a non-char delimited string of events to do
;                       $sEventType: [optional: Default = "fireEvent"]; a string of the event action method
;                                     "fireEvent" or "fire" = fireEvent method
;                                     "dispatchEvent" or "dispatch" = dispatchEvent method
; Return Value(s)..:
;                       Success...: True
;                       Failure...: False
;                       Error.....: 0 = Success, error returns taken from IE.au3
;                                   1 = General Error, 2 = COM Error, 3 = Invalid Data Type
;                                   4 = Invalid Object Type, 5 = Invalid Value
;                                   6 = Load Wait Timeout, 7 = No Match, 8 = Access Denied
;                       Extended..: the number returned is for debugging only, there is data
;                                    returned for both success and failures, it marks the part
;                                    of the code for easier debugging
; Requirement(s)...:
; Author(s)........:    SmOke_N (Ron Nielsen) Ron.SMACKThatApp@gmail.com
; Modified.........:
; Comment(s).......:
; Example(s).......:
;
;================================================================================================================================

Func _IEEx_ObjCheckBoxRadioSelect(ByRef $oObj, $bSelect = True, $sEvents = Default, $sEventType = Default)

	If Not IsObj($oObj) Then
		Return SetError($_IESTATUS_InvalidDataType, 1, 0)
	EndIf

	; validate radio or checkbox
	If Not StringInStr("|checkbox|radio|", "|" & String($oObj.type) & "|") Then
		Return SetError($_IESTATUS_InvalidDataType, 2, 0)
	EndIf

	; do we need to check or uncheck (if already done return)
	If $bSelect Then
		If $oObj.checked Then
			Return SetError($_IESTATUS_Success, 1, 0)
		EndIf
	Else
		If Not $oObj.checked Then
			Return SetError($_IESTATUS_Success, 2, 0)
		EndIf
	EndIf

	$sEvents = ((IsKeyword($sEvents) Or Not StringLen($sEvents)) ? _
		"onchange|onclick" : $sEvents)

	$sEventType = ((IsKeyword($sEventType) Or Not StringLen($sEvents)) ? _
		"fireEvent" : $sEventType)

	Local $aEvents = StringRegExp($sEvents, "(\w+)", 3)
	If @error Then
		Return SetError($_IESTATUS_InvalidValue, 2, 0)
	EndIf

	Local $iErr = 0
	Switch StringLower($sEventType)
		Case "fireevent", "fire"
			If $bSelect Then
				$oObj.checked = True
			Else
				$oObj.checked = False
			EndIf
			For $i = 0 To UBound($aEvents) - 1
				$oObj.fireEvent($aEvents[$i])
				If @error Then
					; invert
					If $bSelect Then
						$oObj.checked = False
					Else
						$oObj.checked = True
					EndIf
					_IEEx_ObjDispatchEvent($oObj, $aEvents[$i])
					If @error Then
						$iErr += 1
						ExitLoop
					EndIf
				EndIf
			Next
		Case Else
			; invert
			If $bSelect Then
				$oObj.checked = False
			Else
				$oObj.checked = True
			EndIf
			For $i = 0 To UBound($aEvents) - 1
				_IEEx_ObjDispatchEvent($oObj, $aEvents[$i])
				If @error Then
					; invert
					If $bSelect Then
						$oObj.checked = True
					Else
						$oObj.checked = False
					EndIf
					$oObj.fireEvent($aEvents[$i])
					If @error Then
						$iErr += 1
						ExitLoop
					EndIf
				EndIf
			Next
	EndSwitch

	If $iErr Then
		Return SetError($_IESTATUS_GeneralError, 3, 0)
	EndIf

	Return SetError($_IESTATUS_Success, 3, 0)
EndFunc   ;==>_IEEx_ObjCheckBoxRadioSelect

;================================================================================================================================
;
; Function Name....:    _IEEx_ObjDispatchEvent(ByRef $oObj, $sEventType [, $sEventName = Default])
; Description......:    fire an event with dispatchEvent
; Parameter(s).....:
;                       $oObj:       The element object to fire event on
;                       $sEventType: The type of event (do not preceed with "on")
;                       $sEventName: [Optional: Default = "MouseEvents"]; The name of the event to create
; Return Value(s)..:
;                       Success...: True
;                       Failure...: False
;                       Error.....: 0 = Success, error returns taken from IE.au3
;                                   1 = General Error, 2 = COM Error, 3 = Invalid Data Type
;                                   4 = Invalid Object Type, 5 = Invalid Value
;                                   6 = Load Wait Timeout, 7 = No Match, 8 = Access Denied
;                       Extended..: the number returned is for debugging only, there is data
;                                    returned for both success and failures, it marks the part
;                                    of the code for easier debugging
; Requirement(s)...:
; Author(s)........:    SmOke_N (Ron Nielsen) Ron.SMACKThatApp@gmail.com
; Modified.........:
; Comment(s).......:
; Example(s).......:
;
;================================================================================================================================

Func _IEEx_ObjDispatchEvent(ByRef $oObj, $sEventType, $sEventName = Default)

	If Not IsObj($oObj) Then
		Return SetError($_IESTATUS_InvalidDataType, 1, 0)
	EndIf

	$sEventType = StringRegExpReplace($sEventType, "(?i)^on", "")

	$sEventName = ((IsKeyword($sEventName)) ? "MouseEvents" : $sEventName)

	Local $oEvent = $oObj.document.createEvent($sEventName)
	$oEvent.initEvent($sEventType, True, True)

	$oObj.dispatchEvent($oEvent)
	If @error Then
		Return SetError($_IESTATUS_GeneralError, 2, 0)
	EndIf

	Return SetError($_IESTATUS_Success, 1, 1)
EndFunc   ;==>_IEEx_ObjDispatchEvent

;================================================================================================================================
;
; Function Name....:    _IEEx_MouseEventExec($hWnd, $sEvent [, $nX = Default [, $nY = Default [, $vBtnDown = Default]]])
; Description......:    Send a MouseEvent to a control's handle without physically moving the mouse
; Parameter(s).....:
;                       $hWnd:     Handle to the client area control
;                       $sEvent:   Mouse event type:
;                                   - "LeftClick" or "LClick" = Left Mouse Click
;                                   - "LeftDblClick" or "LDblClick" = Left Mouse Double Click
;                                   - "LeftDown" or "LDown" = Left Mouse Button Down
;                                   - "LeftUp" or "LUp" = Left Mouse Button Up
;                                   - "MiddleClick" or "MClick" = Middle Mouse Click
;                                   - "MiddleDblClick" or "MDblClick" = Middle Mouse Double Click
;                                  	- "MiddleDown" or "MDown" = Middle Mouse Button Down
;                                   - "MiddleUp" or "MUp" = Middle Mouse Button Up
;                                   - "Hover" = Hover Mouse Over
;                                   - "HWheel" = Mouse Horizontal Wheel Rotated
;                                   - "Leave" = Mouse Leave
;                                   - "Move" = Mouse Move
;                                   - "Wheel" = Mouse Wheel Rotated
;                                   - "RightClick" or "RClick" = Right Mouse Click
;                                   - "RightDblClick" or "RDblClick" = Right Mouse Double Click
;                                   - "RightDown" or "RDown" = Right Mouse Button Down
;                                   - "RightUp" or "RUp" = Right Mouse Button Up
;                                   - "XClick" = X Mouse Click
;                                   - "XDblClick" = X Mouse Button Double Click
;                                   - "XDown" = X Button Down
;                                   - "XUp" = X Button Up
;                       $nX:       [Optional: Default = 0:  Left or X position of the hwnd to perform the event on]
;                       $nY:       [Optional: Default = 0:  Top or Y position of the hwnd to perform the event on]
;                       $vBtnDown: [Optional: Default = 0 (No button down): Can be any combination of the below]
;                                   - "Ctrl" or "Control" or 0x0008 (MK_CONTROL) = Control button is down
;                                   - "Left" or 0x0001 (MK_LBUTTON) = Left mouse button down
;                                   - "Middle" or 0x0010 (MK_MBUTTON) = Middle mouse button down
;                                   - "Right" or 0x0002 (MK_RBUTTON) = Right mouse button down
;                                   - "Shift" or 0x0004 (MK_SHIFT) = Shift key down
;                                   - "X1" or 0x0020 (MK_XBUTTON1) = X1 mouse button down
;                                   - "X2" or 0x0040 (MK_XBUTTON2) = X2 mouse button down
; Return Value(s)..:
;                       Success...: True
;                       Failure...: False
;                       Error.....: 1 = PostMessage failed
;                       Extended..: Data from GetLastError()
; Requirement(s)...:
; Author(s)........:    SmOke_N (Ron Nielsen) Ron.SMACKThatApp@gmail.com
; Modified.........:
; Comment(s).......:    Remember, you need your object to be in visual site more than likely for this to work
;                        This is sort of a last ditch effort
; Example(s).......:    _IEEx_MouseEventExec(ControlGetHandle($goIE.hwnd, "", [Class:etc; Instance:1]), "lclick", 0, 0)
;
;================================================================================================================================

Func _IEEx_MouseEventExec($hWnd, $sEvent, $nX = Default, $nY = Default, $vBtnDown = Default)

	Local $bRet

	$vBtnDown = ($vBtnDown = 0 Or IsKeyword($vBtnDown) Or $vBtnDown = -1) ? 0 : $vBtnDown
	$vBtnDown = __IEEx_MouseGetButtonDown($vBtnDown)

	Switch StringLower($sEvent)
		Case "leftclick", "lclick"
			_IEEx_MouseEventExec($hWnd, "move", $nX, $nY, $vBtnDown)
			_IEEx_MouseEventExec($hWnd, "hover", $nX, $nY, $vBtnDown)
			_IEEx_MouseEventExec($hWnd, "ldown", $nX, $nY, $vBtnDown)
			_IEEx_MouseEventExec($hWnd, "lup", $nX, $nY, $vBtnDown)
		Case "leftdblclick", "ldblclick"
			$bRet = _WinAPI_PostMessage($hWnd, $WM_LBUTTONDBLCLK, $vBtnDown, _WinAPI_MakeLong($nX, $nY))
		Case "leftdown", "ldown"
			$bRet = _WinAPI_PostMessage($hWnd, $WM_LBUTTONDOWN , $vBtnDown, _WinAPI_MakeLong($nX, $nY))
		Case "leftup", "lup"
			$bRet = _WinAPI_PostMessage($hWnd, $WM_LBUTTONUP, $vBtnDown, _WinAPI_MakeLong($nX, $nY))
		Case "middleclick", "mclick"
			_IEEx_MouseEventExec($hWnd, "move", $nX, $nY, $vBtnDown)
			_IEEx_MouseEventExec($hWnd, "hover", $nX, $nY, $vBtnDown)
			_IEEx_MouseEventExec($hWnd, "mdown", $nX, $nY, $vBtnDown)
			_IEEx_MouseEventExec($hWnd, "mup", $nX, $nY, $vBtnDown)
		Case "middledblclick", "mdblclick"
			$bRet = _WinAPI_PostMessage($hWnd, $WM_MBUTTONDBLCLK, $vBtnDown, _WinAPI_MakeLong($nX, $nY))
		Case "middledown", "mdown"
			$bRet = _WinAPI_PostMessage($hWnd, $WM_MBUTTONDOWN, $vBtnDown, _WinAPI_MakeLong($nX, $nY))
		Case "middleup", "mup"
			$bRet = _WinAPI_PostMessage($hWnd, $WM_MBUTTONUP, $vBtnDown, _WinAPI_MakeLong($nX, $nY))
		Case "hover"
			$bRet = _WinAPI_PostMessage($hWnd, $WM_MOUSEHOVER, $vBtnDown, _WinAPI_MakeLong($nX, $nY))
		Case "hwheel"
			$bRet = _WinAPI_PostMessage($hWnd, $WM_MOUSEHWHEEL, $vBtnDown, _WinAPI_MakeLong($nX, $nY))
		Case "leave"
			$bRet = _WinAPI_PostMessage($hWnd, $WM_MOUSELEAVE, $vBtnDown, _WinAPI_MakeLong($nX, $nY))
		Case "move"
			$bRet = _WinAPI_PostMessage($hWnd, $WM_MOUSEMOVE, $vBtnDown, _WinAPI_MakeLong($nX, $nY))
		Case "wheel"
			$bRet = _WinAPI_PostMessage($hWnd, $WM_MOUSEWHEEL, $vBtnDown, _WinAPI_MakeLong($nX, $nY))
		Case "rightclick", "rclick"
			_IEEx_MouseEventExec($hWnd, "move", $nX, $nY, $vBtnDown)
			_IEEx_MouseEventExec($hWnd, "hover", $nX, $nY, $vBtnDown)
			_IEEx_MouseEventExec($hWnd, "rdown", $nX, $nY, $vBtnDown)
			_IEEx_MouseEventExec($hWnd, "rup", $nX, $nY, $vBtnDown)
		Case "rightdblclick", "rdblclick"
			$bRet = _WinAPI_PostMessage($hWnd, $WM_RBUTTONDBLCLK, $vBtnDown, _WinAPI_MakeLong($nX, $nY))
		Case "rightdown", "rdown"
			$bRet = _WinAPI_PostMessage($hWnd, $WM_RBUTTONDOWN, $vBtnDown, _WinAPI_MakeLong($nX, $nY))
		Case "rightup", "rup"
			$bRet = _WinAPI_PostMessage($hWnd, $WM_RBUTTONUP, $vBtnDown, _WinAPI_MakeLong($nX, $nY))
		Case "xclick"
			_IEEx_MouseEventExec($hWnd, "move", $nX, $nY, $vBtnDown)
			_IEEx_MouseEventExec($hWnd, "hover", $nX, $nY, $vBtnDown)
			_IEEx_MouseEventExec($hWnd, "xdown", $nX, $nY, $vBtnDown)
			_IEEx_MouseEventExec($hWnd, "xup", $nX, $nY, $vBtnDown)
		Case "xdblclick"
			$bRet = _WinAPI_PostMessage($hWnd, $WM_XBUTTONDBLCLK, $vBtnDown, _WinAPI_MakeLong($nX, $nY))
		Case "xdown"
			$bRet = _WinAPI_PostMessage($hWnd, $WM_XBUTTONDOWN, $vBtnDown, _WinAPI_MakeLong($nX, $nY))
		Case "xup"
			$bRet = _WinAPI_PostMessage($hWnd, $WM_XBUTTONUP, $vBtnDown, _WinAPI_MakeLong($nX, $nY))
	EndSwitch

	Local $nLastError = _WinAPI_GetLastError()

	If Not $bRet Then
		Return SetError(1, $nLastError, False)
	EndIf

	Return True
EndFunc   ;==>_IEEx_MouseEventExec

;================================================================================================================================
;
; Function Name....:    _IEEx_JSClassNameGetArray(ByRef $oObj, $sClass [, $sTag = Default])
; Description......:    Returns an array of all the objects found matching the above criteria you sent
; Parameter(s).....:
;                       $oObj:   The object you're working with
;                       $sClass: The classname you want to find, multiple class names with space separator
;                       $sTag:   [Optional: Default = "" (empty string) The tag type you want to search]
; Return Value(s)..:
;                       Success...: A 1 dimension array containing all objects found
;                       Failure...: 0 with error type and extended info
;                       Error.....: 0 = Success, error returns taken from IE.au3
;                                   1 = General Error, 2 = COM Error, 3 = Invalid Data Type
;                                   4 = Invalid Object Type, 5 = Invalid Value
;                                   6 = Load Wait Timeout, 7 = No Match, 8 = Access Denied
;                       Extended..: the number returned is for debugging only, there is data
;                                    returned for both success and failures, it marks the part
;                                    of the code for easier debugging
; Requirement(s)...:
; Author(s)........:    SmOke_N (Ron Nielsen) Ron.SMACKThatApp@gmail.com
; Modified.........:
; Comment(s).......:
; Example(s).......:    $gaClassArray = _IEEx_JSClassNameGetArray($goIE, "class", "DIV")
;
;================================================================================================================================

Func _IEEx_JSClassNameGetArray(ByRef $oObj, $sClass, $sTag = Default)

	Local $oItems = _IEEx_JSClassNameGetCollection($oObj, $sClass)
	If @error Then
		Return SetError(@error, @extended, 0)
	EndIf

	$sTag = ((StringLen($sTag) And Not IsKeyword($sTag)) ? StringLower($sTag) : "")

	Local $iLen = $oItems.length

	Local $aORet[$iLen]
	Local $iCount = 0
	For $oItem In $oItems
		If StringLen($sTag) Then
			If $sTag <> StringLower($oItem.tagName) Then ContinueLoop
		EndIf
		$aORet[$iCount] = $oItem
		$iCount += 1
	Next

	ReDim $aORet[$iCount]
	Return SetError($_IESTATUS_Success, 1, $aORet)
EndFunc   ;==>_IEEx_JSClassNameGetArray

;================================================================================================================================
;
; Function Name....:    _IEEx_JSClassNameGetCollection(ByRef $oObj, $sClass)
; Description......:    Returns a collection of all the objects found matching the classname
; Parameter(s).....:
;                       $oObj:   The object you're working with
;                       $sClass: The classname you want to find, multiple class names with space separator
; Return Value(s)..:
;                       Success...: An object list of the matches
;                       Failure...: 0 with error type and extended info
;                       Error.....: 0 = Success, error returns taken from IE.au3
;                                   1 = General Error, 2 = COM Error, 3 = Invalid Data Type
;                                   4 = Invalid Object Type, 5 = Invalid Value
;                                   6 = Load Wait Timeout, 7 = No Match, 8 = Access Denied
;                       Extended..: the number returned is for debugging only, there is data
;                                    returned for both success and failures, it marks the part
;                                    of the code for easier debugging
; Requirement(s)...:
; Author(s)........:    SmOke_N (Ron Nielsen) Ron.SMACKThatApp@gmail.com
; Modified.........:
; Comment(s).......:
; Example(s).......:    $gaClassArray = _IEEx_JSClassNameGetCollection($goIE, "class")
;
;================================================================================================================================

Func _IEEx_JSClassNameGetCollection(ByRef $oObj, $sClass)

	If Not IsObj($oObj) Then
		Return SetError($_IESTATUS_InvalidDataType, 1, 0)
	EndIf

	Local $oTObj = $oObj
	If _IEEx_GetObjType($oTObj) = "browser" Then
		$oTObj = $oObj.document
	EndIf

	Local $oDoc = _IEEx_GetObjParentWindow($oTObj); Doc wasn't working
	If Not IsObj($oDoc) Then
		Return SetError($_IESTATUS_InvalidObjectType, 2, 0)
	EndIf

	Local $oDPW = __IEEx_GetContainerObj($oDoc, "ClassGetCollection")
	If @error Then
		Return SetError(@error, @extended, 0)
	EndIf

	Local $vRet = $oDPW.IEExAutClassGetCollection($oTObj, $sClass)
	If $vRet Then
		Return SetError($_IESTATUS_InvalidObjectType, 5 + $vRet, 0)
	EndIf

	;return the object list
	Return SetError($_IESTATUS_Success, 1, $vRet)
EndFunc   ;==>_IEEx_JSClassNameGetCollection

;================================================================================================================================
;
; Function Name....:    _IEEx_JSClickObj(ByRef $oObj)
; Description......:    An insert script to click the element object
; Parameter(s).....:
;                       $oObj: Object to click
; Return Value(s)..:
;                       Success...: True : Click() "should" return S_OK (0)
;                       Failure...: False : Check @error
;                       Error.....: 0 = Success, error returns taken from IE.au3
;                                   1 = General Error, 2 = COM Error, 3 = Invalid Data Type
;                                   4 = Invalid Object Type, 5 = Invalid Value
;                                   6 = Load Wait Timeout, 7 = No Match, 8 = Access Denied
;                       Extended..: the number returned is for debugging only, there is data
;                                    returned for both success and failures, it marks the part
;                                    of the code for easier debugging
; Requirement(s)...:
; Author(s)........:    SmOke_N (Ron Nielsen) Ron.SMACKThatApp@gmail.com
; Modified.........:
; Comment(s).......:    Think of this like ControlClick without coords
; Example(s).......:    _IEEx_JSClickObj($goDiv)
;
;================================================================================================================================

Func _IEEx_JSClickObj(ByRef $oObj)

	If Not IsObj($oObj) Then
		Return SetError($_IESTATUS_InvalidDataType, 1, False)
	EndIf

	Local $oTObj = $oObj
	If _IEEx_GetObjType($oTObj) = "browser" Then
		$oTObj = $oObj.document
	EndIf

	Local $oDPW = __IEEx_GetContainerObj($oTObj, "ClickObj")
	If @error Then
		Return SetError(@error, @extended, False)
	EndIf

	; we have our click object
	Local $iRet = $oDPW.IEExAutClickObj($oObj)
	If $iRet Then
		Return SetError($_IESTATUS_InvalidObjectType, 5 + $iRet, False)
	EndIf

	Return SetError($_IESTATUS_Success, 1, True)
EndFunc   ;==>_IEEx_JSClickObj

;===================================================================================================
;
; Function Name....:    _IEEx_JSClickObjById(ByRef $oObj, $vID)
; Description......:    An insert script to click the object by obj.id
; Parameter(s).....:
;                       $oObj: The object variable of an InternetExplorer.Application,
;                               Window or Frame object
;                       $vID:  The element object or the string id of the object to click
; Return Value(s)..:
;                       Success...: True : Click() "should" return S_OK (0)
;                       Failure...: False : Check @error
;                       Error.....: 0 = Success, error returns taken from IE.au3
;                                   1 = General Error, 2 = COM Error, 3 = Invalid Data Type
;                                   4 = Invalid Object Type, 5 = Invalid Value
;                                   6 = Load Wait Timeout, 7 = No Match, 8 = Access Denied
;                       Extended..: the number returned is for debugging only, there is data
;                                    returned for both success and failures, it marks the part
;                                    of the code for easier debugging
; Requirement(s)...:
; Author(s)........:    SmOke_N (Ron Nielsen) Ron.SMACKThatApp@gmail.com
; Modified.........:
; Comment(s).......:
; Example(s).......:    _IEEx_JSClickById($goDiv, "id")
;
;===================================================================================================

Func _IEEx_JSClickObjById(ByRef $oObj, $vID)

	If Not IsObj($oObj) Then
		Return SetError($_IESTATUS_InvalidDataType, 1, False)
	EndIf

	Local $oEventObj = (IsObj($vID)) ? $vID : _IEGetObjById($oObj, $vID)
	If Not IsObj($oEventObj) Then
		; no sense to go any further
		Return SetError($_IESTATUS_InvalidDataType, 2, False)
	EndIf

	Local $oDPW = __IEEx_GetContainerObj($oObj, "ClickObjById")
	If @error Then
		Return SetError(@error, @extended, False)
	EndIf

	; we have our click object
	Local $iRet = $oDPW.IEExAutClickObjById($oEventObj)
	If $iRet Then
		Return SetError($_IESTATUS_GeneralError, 5 + $iRet, False)
	EndIf

	Return SetError($_IESTATUS_Success, 1, True)
EndFunc   ;==>_IEEx_JSClickObjById

;================================================================================================================================
;
; Function Name....:    _IEEx_JSClickObjByName(ByRef $oObj, $vName [, $nIndex])
; Description......:    An insert script to click the object by obj.id
; Parameter(s).....:
;                       $oObj:   The object variable of an InternetExplorer.Application,
;                                 Window or Frame object
;                       $sName:  The name object or the string name of the object to click
;                       $nIndex: [Optional: Default = 0 (index 0)]; see _IEGetObjByName() IE.au3
; Return Value(s)..:
;                       Success...: True : Click() "should" return S_OK (0)
;                       Failure...: False : Check @error
;                       Error.....: 0 = Success, error returns taken from IE.au3
;                                   1 = General Error, 2 = COM Error, 3 = Invalid Data Type
;                                   4 = Invalid Object Type, 5 = Invalid Value
;                                   6 = Load Wait Timeout, 7 = No Match, 8 = Access Denied
;                       Extended..: the number returned is for debugging only, there is data
;                                    returned for both success and failures, it marks the part
;                                    of the code for easier debugging
; Requirement(s)...:
; Author(s)........:    SmOke_N (Ron Nielsen) Ron.SMACKThatApp@gmail.com
; Modified.........:
; Comment(s).......:    getElementsByName is being deprecated in IE11, not sure I'll keep this function
; Example(s).......:    _IEEx_JSClickByName($goDiv, "name")
;
;================================================================================================================================

Func _IEEx_JSClickObjByName(ByRef $oObj, $vName, $nIndex = Default)

	If Not IsObj($oObj) Then
		Return SetError($_IESTATUS_InvalidDataType, 1, False)
	EndIf

	$nIndex = (($nIndex = Default Or $nIndex < 0) ? 0 : $nIndex)

	Local $oEventObj = ((IsObj($vName)) ? $vName : _IEGetObjByName($oObj, $vName, $nIndex))
	If Not IsObj($oEventObj) Then
		; no sense to go any further
		Return SetError($_IESTATUS_InvalidDataType, 2, False)
	EndIf

	Local $fRet = _IEEx_JSClickObj($oEventObj)
	If @error Then
		Return SetError(@error, @extended, $fRet)
	EndIf

	Return SetError($_IESTATUS_Success, 1, True)
EndFunc   ;==>_IEEx_JSClickObjByName

;================================================================================================================================
;
; Function Name....:    _IEEx_JSClickObjByPoint(ByRef $oObj [, $nX = Default [, $nY = Default ]])
; Description......:    An insert script to click the x & y coordinates passed, default click
;                        if both x and y are default, is center object
; Parameter(s).....:
;                       $oObj: Object to click
;                       $nX:   [Optional: Default = Center width;
;                               (Left position from 0 to width of object) to click object]
;                       $nY:   [Optional: Default = Center height;
;                               Top position (from 0 to height of object) to click object]
; Return Value(s)..:
;                       Success...: True : Click() "should" return S_OK (0)
;                       Failure...: False : Check @error
;                       Error.....: 0 = Success, error returns taken from IE.au3
;                                   1 = General Error, 2 = COM Error, 3 = Invalid Data Type
;                                   4 = Invalid Object Type, 5 = Invalid Value
;                                   6 = Load Wait Timeout, 7 = No Match, 8 = Access Denied
;                       Extended..: the number returned is for debugging only, there is data
;                                    returned for both success and failures, it marks the part
;                                    of the code for easier debugging
; Requirement(s)...:
; Author(s)........:    SmOke_N (Ron Nielsen) Ron.SMACKThatApp@gmail.com
; Modified.........:
; Comment(s).......:    Think of this like ControlClick, using client coords of the object itself
; Example(s).......:    _IEEx_JSClickObjByPoint($goDiv, 12, 18)
;
;================================================================================================================================

Func _IEEx_JSClickObjByPoint(ByRef $oObj, $nX = Default, $nY = Default)

	If Not IsObj($oObj) Then
		Return SetError($_IESTATUS_InvalidDataType, 1, False)
	EndIf

	Local $oDPW = __IEEx_GetContainerObj($oObj, "ClickObjXY")
	If @error Then
		Return SetError(@error, @extended, False)
	EndIf

	If $nX = Default Then $nX = 0
	If $nY = Default Then $nY = 0

	; we have our click object
	Local $iRet = $oDPW.IEExAutClickObjXY($oObj, $nX, $nY)
	If $iRet Then
		Return SetError($_IESTATUS_GeneralError, 5 + $iRet, False)
	EndIf

	Return SetError($_IESTATUS_Success, 1, True)
EndFunc   ;==>_IEEx_JSClickObjByPoint

;===================================================================================================
;
; Function Name....:    _IEEx_JSDragEventObjByName(ByRef $oObj, $oEvent, $sEvent [, $nX [, $nY]])
;
; Description......:    An insert script to use various Drag actions on the object by obj
; Parameter(s).....:
;                       $oObj:   The object variable of an InternetExplorer.Application,
;                                 Window or Frame object
;                       $oEvent: The object to enter the drag event on
;                       $sEvent: The string event to use:
;                                "Drag": ............. Fires a drag event on the object
;                                "Dragend": .......... Fires a drag end event on the object
;                                "Dragenter": ........ Fires a drag enter event on the object
;                                "Dragleave": ........ Fires a drag leave event on the object
;                                "Dragover": ......... Fires a drag over event on the object
;                                "Dragstart":......... Fires a drag start event on the object
;                                "Drop": ............. Fires a drag drop event on the object
; Return Value(s)..:
;                       Success...: True
;                       Failure...: False : Check @error
;                       Error.....: 0 = Success, error returns taken from IE.au3
;                                   1 = General Error, 2 = COM Error, 3 = Invalid Data Type
;                                   4 = Invalid Object Type, 5 = Invalid Value
;                                   6 = Load Wait Timeout, 7 = No Match, 8 = Access Denied
;                       Extended..: the number returned is for debugging only, there is data
;                                    returned for both success and failures, it marks the part
;                                    of the code for easier debugging
; Requirement(s)...:
; Author(s)........:    SmOke_N (Ron Nielsen) Ron.SMACKThatApp@gmail.com
; Modified.........:
; Comment(s).......:    see: http://msdn.microsoft.com/en-us/library/windows/apps/hh465951.aspx
;                        x and y coordinates are of no use at the moment, but I may impliment
;                        something the more I understand this event and how it can be utilized
;                        to achieve more things.
; Example(s).......:    _IEEx_JSDragEventObj($goDiv, $goElm, "dragstart")
;
;===================================================================================================

Func _IEEx_JSDragEventObj(ByRef $oObj, $oEvent, $sEvent, $nX = Default, $nY = Default)

	If Not IsObj($oObj) Then
		Return SetError($_IESTATUS_InvalidDataType, 1, False)
	EndIf

	If Not IsObj($oObj) Then
		Return SetError($_IESTATUS_InvalidDataType, 2, False)
	EndIf

	Local $vRet = __IEEx_JSDragEventObjBy($oObj, $oEvent, $sEvent, $nX, $nY)
	Return SetError(@error, @extended, $vRet)
EndFunc   ;==>_IEEx_JSDragEventObj

;================================================================================================================================
;
; Function Name....:    _IEEx_JSEnable([$fEnable = True])
; Description......:    An attempt to enable or disable IE javascript
; Parameter(s).....:
;                       $fEnable: [Optional: True to enable, False to disable]
; Return Value(s)..:
;                       Success...: The status before the attempted change
;
; Requirement(s)...:
; Author(s)........:    SmOke_N (Ron Nielsen) Ron.SMACKThatApp@gmail.com
; Modified.........:
; Comment(s).......:
; Example(s).......:
;
;================================================================================================================================

Func _IEEx_JSEnable($fEnable = True)

	Local $fIsEnabled = _IEEx_JSIsEnabled()

	; return state before change
	If ($fIsEnabled And $fEnable) Then
		Return $fIsEnabled
	EndIf

	Local Const $sHKCU = ((@AutoItX64) ? "HKCU64" : "HKCU")

	; zone 0 = local files
	; zone 1 = my computer
	; zone 3 = internet/ie
	Local Const $sZone = $sHKCU & "\Software\Microsoft\Windows\" & _
		"CurrentVersion\Internet Settings\Zones\3"

	If $fEnable Then
		RegWrite($sZone, "1400", "REG_DWORD", 0)
	Else
		RegWrite($sZone, "1400", "REG_DWORD", 3)
	EndIf

	Return $fIsEnabled
EndFunc   ;==>_IEEx_JSEnable

;================================================================================================================================
;
; Function Name....:    _IEEx_JSGetObjByClassName(ByRef $oObj, $sClass [, $sTag = Default [, nIndex = Default]])
; Description......:    Returns an object for the classname found at the index provided
; Parameter(s).....:
;                       $oObj:   The object you're working with
;                       $sClass: The classname you want to find, multiple class names with space separator
;                       $sTag:   [Optional: Default = "" (empty string) The tag type you want to search]
;                       $nIndex: [Optional: Default = 0]
; Return Value(s)..:
;                       Success...: The object for the classname found at the index provided
;                       Failure...: 0 with error type and extended info
;                       Error.....: 0 = Success, error returns taken from IE.au3
;                                   1 = General Error, 2 = COM Error, 3 = Invalid Data Type
;                                   4 = Invalid Object Type, 5 = Invalid Value
;                                   6 = Load Wait Timeout, 7 = No Match, 8 = Access Denied
;                       Extended..: the number returned is for debugging only, there is data
;                                    returned for both success and failures, it marks the part
;                                    of the code for easier debugging
; Requirement(s)...:
; Author(s)........:    SmOke_N (Ron Nielsen) Ron.SMACKThatApp@gmail.com
; Modified.........:
; Comment(s).......:
; Example(s).......:    _IEEx_JSGetObjByClassName($goIE, "class", "DIV")
;
;================================================================================================================================

Func _IEEx_JSGetObjByClassName(ByRef $oObj, $sClass, $sTag = Default, $nIndex = Default)

	Local $aOClass = _IEEx_JSClassNameGetArray($oObj, $sClass, $sTag)
	If @error Then
		Return SetError(@error, @extended, 0)
	EndIf

	$nIndex = (($nIndex = Default Or $nIndex < 0) ? 0 : $nIndex)

	Local $nUbound = UBound($aOClass) - 1
	If $nIndex > $nUbound Then
		Return SetError($_IESTATUS_InvalidValue, 6, 0)
	EndIf

	Return SetError($_IEStatus_Success, 1, $aOClass[$nIndex])
EndFunc   ;==>_IEEx_JSGetObjByClassName

;================================================================================================================================
;
; Function Name....:    _IEEx_JSGetObjPos(ByRef $oObj, $oEventObj)
; Description......:    Injects JS and returns an rect array of the Left, Top, Width, Height of the element
;                        object relative to the body object
; Parameter(s).....:
;                       $oObj:      The browser/document object
;                       $oEventObj: The event object to get position of
; Return Value(s)..:
;                       Success...: A 1-dimensional array
;                                   [0] = Left (x) position
;                                   [1] = Top (y) position
;                                   [2] = Width
;                                   [3] = Height
;                       Failure...: 0
;                       Error.....: 0 = Success, error returns taken from IE.au3
;                                   1 = General Error, 2 = COM Error, 3 = Invalid Data Type
;                                   4 = Invalid Object Type, 5 = Invalid Value
;                                   6 = Load Wait Timeout, 7 = No Match, 8 = Access Denied
;                       Extended..: the number returned is for debugging only, there is data
;                                    returned for both success and failures, it marks the part
;                                    of the code for easier debugging
; Requirement(s)...:
; Author(s)........:    SmOke_N (Ron Nielsen) Ron.SMACKThatApp@gmail.com
; Modified.........:
; Comment(s).......:    I'm not sure this is working out how I want it yet
; Example(s).......:    _IEEx_JSGetObjPos($goIE, $goelement)
;
;================================================================================================================================

Func _IEEx_JSGetObjPos(ByRef $oObj, $oEventObj)

	If Not IsObj($oObj) Then
		Return SetError($_IESTATUS_InvalidDataType, 1, 0)
	EndIf

	If Not IsObj($oEventObj) Then
		Return SetError($_IESTATUS_InvalidDataType, 2, 0)
	EndIf

	Local $oRet = __IEEx_GetContainerObj($oObj, "GetObjPos")
	If @error Then
		Return SetError(@error, @extended, 0)
	EndIf

	Local $oRect = $oRet.IEExAutGetObjPos($oEventObj)
	If Not IsObj($oRect) Then
		Return SetError($_IESTATUS_InvalidDataType, 6, 0)
	EndIf

	Local $nX = $oRect.left
	Local $nY = Execute("$oRect.top")
	Local $nWidth = Execute("$oRect.width")
	Local $nHeight = Execute("$oRect.height")

	Local $aORet[] = [$nX, $nY, $nWidth, $nHeight]
	Return SetError($_IESTATUS_Success, 1, $aORet)
EndFunc   ;==>_IEEx_JSGetObjPos

;================================================================================================================================
;
; Function Name....:    _IEEx_JSIsEnabled()
; Description......:    An attempt to determine if IE javascript is enabled or disabled
; Parameter(s).....:    none
; Return Value(s)..:
;                       Success...: True: Javascript is enabled
;                                   False: Javascript is disabled
;
; Author(s)........:    SmOke_N (Ron Nielsen) Ron.SMACKThatApp@gmail.com
; Modified.........:
; Comment(s).......:
; Example(s).......:
;
;================================================================================================================================

Func _IEEx_JSIsEnabled()

	Local Const $sHKCU = ((@AutoItX64) ? "HKCU" : "HKCU64")

	; zone 0 = local files
	; zone 1 = my computer
	; zone 3 = internet/ie
	Local Const $sZone = $sHKCU & "\Software\Microsoft\Windows\" & _
		"CurrentVersion\Internet Settings\Zones\3"

	Return ((Int(RegRead($sZone, "1400")) = 0) ? True : False)
EndFunc   ;==>_IEEx_JSIsEnabled

;===================================================================================================
;
; Function Name....:    _IEEx_JSMouseEventObj(ByRef $oObj, $oEvent, _
;                                                               $sEvent [, $nX [, $nY [, nIndex ]]])
;
; Description......:    An insert script to use various mouse actions on the object
;                        by obj.name.item(n)
; Parameter(s).....:
;                       $oObj:   The object variable of an InternetExplorer.Application,
;                                 Window or Frame object
;                       $oEvent: The object to click
;                       $sEvent: The string event to use:
;                                "Click": ............ Fires a click event on the object
;                                "ClickPoint": ....... Fires a click by point event on the object,
;                                                       for x & y position
;                                "ContextMenu": ...... Fires a contextmenu event on the object
;                                "ContextMenuPoint": . Fires a contextmenu by point event on the
;                                                       object for x & y position
;                                "DblClick": ......... Fires a double click event on the object
;                                "DblClickPoint": .... Fires a double click by point event on the
;                                                       object for x & y position
;                                "MouseClick":........ Custom hover, down, up event to simulate
;                                                       a mouse click
;                                "MouseClickPoint": .. Uses MouseClick method above with
;                                                       ClickPoint x & y position option
;                                "MouseDblClick": .... Fires a double mouse click event with
;                                                       a custom hover, down, up event
;                                "MouseDblClickPoint": Fires a double mouse click by point event
;                                                       with a custom hover, down, up event
;                                "MouseDown": ........ Fires a mousedown event on the object
;                                "MouseEnter": ....... Fires a mouseenter event on the object
;                                "MouseLeave": ....... Fires a mouseleave event on the object
;                                "MouseMove": ........ Fires a mousemove event on the object
;                                "MouseMoveToPoint": . Fires a mousemove event by point event on
;                                                       the object for x & y position
;                                "MouseOut": ......... Fires a mouseout event on the object
;                                "MouseOver": ........ Fires a mouseover event on the object
;                                "MouseUp": .......... Fires a mouseup event on the object
;                       $nX:     [Optional: Default = Center width;
;                                 (Left position from 0 to width of object) to access object]
;                       $nX:     [Optional: Default = Center height;
;                                 (Left position from 0 to height of object) to access object]
;                       $nIndex  [Optional: -1 or Default = 0, positive integer only to a name
;                                 object you wish to interact with
; Return Value(s)..:
;                       Success...: True
;                       Failure...: False : Check @error
;                       Error.....: 0 = Success, error returns taken from IE.au3
;                                   1 = General Error, 2 = COM Error, 3 = Invalid Data Type
;                                   4 = Invalid Object Type, 5 = Invalid Value
;                                   6 = Load Wait Timeout, 7 = No Match, 8 = Access Denied
;                       Extended..: the number returned is for debugging only, there is data
;                                    returned for both success and failures, it marks the part
;                                    of the code for easier debugging
; Requirement(s)...:
; Author(s)........:    SmOke_N (Ron Nielsen) Ron.SMACKThatApp@gmail.com
; Modified.........:
; Comment(s).......:    see: http://msdn.microsoft.com/en-us/library/ie/ms536945(v=vs.85).aspx
;                        Warning:  If the object is not within the visible bounds of the document
;                         The by point options will not find the correct locations on the object probably
;                        You may need to scroll into view
; Example(s).......:    _IEEx_JSMouseEventObj($goIE, $goEvent, "clickpoint", 4, 8, 1)
;
;===================================================================================================

Func _IEEx_JSMouseEventObj(ByRef $oObj, $oEvent, $sEvent, $nX = Default, $nY = Default)

	If Not IsObj($oObj) Then
		Return SetError($_IESTATUS_InvalidDataType, 1, False)
	EndIf

	If Not IsObj($oEvent) Then
		Return SetError($_IESTATUS_InvalidDataType, 2, False)
	EndIf

	Local $vRet = __IEEx_JSMouseEventObjBy($oObj, $oEvent, $sEvent, $nX, $nY)
	Return SetError(@error, @extended, $vRet)
EndFunc   ;==>_IEEx_JSMouseEventObj

;===================================================================================================
;
; Function Name....:    _IEEx_JSMouseEventObjById(ByRef $oObj, $vID, $sEvent [, $nX [, $nY ]])
; Description......:    An insert script to use various mouse actions on the object by obj.id
; Parameter(s).....:
;                       $oObj:   The object variable of an InternetExplorer.Application,
;                                 Window or Frame object or parent element object
;                       $vID:    The object to click or the string id of the object to click
;                       $sEvent: The string event to use:
;                                "Click": ............ Fires a click event on the object
;                                "ClickPoint": ....... Fires a click by point event on the object,
;                                                       for x & y position
;                                "ContextMenu": ...... Fires a contextmenu event on the object
;                                "ContextMenuPoint": . Fires a contextmenu by point event on the
;                                                       object for x & y position
;                                "DblClick": ......... Fires a double click event on the object
;                                "DblClickPoint": .... Fires a double click by point event on the
;                                                       object for x & y position
;                                "MouseClick":........ Custom hover, down, up event to simulate
;                                                       a mouse click
;                                "MouseClickPoint": .. Uses MouseClick method above with
;                                                       ClickPoint x & y position option
;                                "MouseDblClick": .... Fires a double mouse click event with
;                                                       a custom hover, down, up event
;                                "MouseDblClickPoint": Fires a double mouse click by point event
;                                                       with a custom hover, down, up event
;                                "MouseDown": ........ Fires a mousedown event on the object
;                                "MouseEnter": ....... Fires a mouseenter event on the object
;                                "MouseLeave": ....... Fires a mouseleave event on the object
;                                "MouseMove": ........ Fires a mousemove event on the object
;                                "MouseMoveToPoint": . Fires a mousemove event by point event on
;                                                       the object for x & y position
;                                "MouseOut": ......... Fires a mouseout event on the object
;                                "MouseOver": ........ Fires a mouseover event on the object
;                                "MouseUp": .......... Fires a mouseup event on the object
;                       $nX:     [Optional: Default = Center width;
;                                 (Left position from 0 to width of object) to access object]
;                       $nX:     [Optional: Default = Center height;
;                                 (Left position from 0 to height of object) to access object]
; Return Value(s)..:
;                       Success...: True
;                       Failure...: False : Check @error
;                       Error.....: 0 = Success, error returns taken from IE.au3
;                                   1 = General Error, 2 = COM Error, 3 = Invalid Data Type
;                                   4 = Invalid Object Type, 5 = Invalid Value
;                                   6 = Load Wait Timeout, 7 = No Match, 8 = Access Denied
;                       Extended..: the number returned is for debugging only, there is data
;                                    returned for both success and failures, it marks the part
;                                    of the code for easier debugging
; Requirement(s)...:
; Author(s)........:    SmOke_N (Ron Nielsen) Ron.SMACKThatApp@gmail.com
; Modified.........:
; Comment(s).......:    see: http://msdn.microsoft.com/en-us/library/ie/ms536945(v=vs.85).aspx
;                       MouseClick and the such will not always work, they are intended to be used
;                        on objects that do not have an "onClick" event
;                        Warning:  If the object is not within the visible bounds of the document
;                         The by point options will not find the correct locations on the object probably
;                        You may need to scroll into view
; Example(s).......:    _IEEx_JSMouseEventObjById($goDiv, "id", "clickpoint", 4, 8)
;
;===================================================================================================

Func _IEEx_JSMouseEventObjById(ByRef $oObj, $vID, $sEvent, $nX = Default, $nY = Default)

	If Not IsObj($oObj) Then
		Return SetError($_IESTATUS_InvalidDataType, 1, False)
	EndIf

	Local $oEventObj = ((IsObj($vID)) ? $vID : _IEGetObjById($oObj, $vID))
	If Not IsObj($oEventObj) Then
		; no sense to go any further
		Return SetError($_IESTATUS_InvalidDataType, 2, False)
	EndIf

	Local $vRet = __IEEx_JSMouseEventObjBy($oObj, $oEventObj, $sEvent, $nX, $nY)
	Return SetError(@error, @extended, $vRet)
EndFunc   ;==>_IEEx_JSMouseEventObjById

;===================================================================================================
;
; Function Name....:    _IEEx_JSMouseEventObjByName(ByRef $oObj, $vID, _
;                                                               $sEvent [, $nX [, $nY [, nIndex ]]])
;
; Description......:    An insert script to use various mouse actions on the object
;                        by obj.name.item(n)
; Parameter(s).....:
;                       $oObj:   The object variable of an InternetExplorer.Application,
;                                 Window or Frame object or parent element object
;                       $vID:    The object to click or the string id of the object to click
;                       $sEvent: The string event to use:
;                                "Click": ............ Fires a click event on the object
;                                "ClickPoint": ....... Fires a click by point event on the object,
;                                                       for x & y position
;                                "ContextMenu": ...... Fires a contextmenu event on the object
;                                "ContextMenuPoint": . Fires a contextmenu by point event on the
;                                                       object for x & y position
;                                "DblClick": ......... Fires a double click event on the object
;                                "DblClickPoint": .... Fires a double click by point event on the
;                                                       object for x & y position
;                                "MouseClick":........ Custom hover, down, up event to simulate
;                                                       a mouse click
;                                "MouseClickPoint": .. Uses MouseClick method above with
;                                                       ClickPoint x & y position option
;                                "MouseDblClick": .... Fires a double mouse click event with
;                                                       a custom hover, down, up event
;                                "MouseDblClickPoint": Fires a double mouse click by point event
;                                                       with a custom hover, down, up event
;                                "MouseDown": ........ Fires a mousedown event on the object
;                                "MouseEnter": ....... Fires a mouseenter event on the object
;                                "MouseLeave": ....... Fires a mouseleave event on the object
;                                "MouseMove": ........ Fires a mousemove event on the object
;                                "MouseMoveToPoint": . Fires a mousemove event by point event on
;                                                       the object for x & y position
;                                "MouseOut": ......... Fires a mouseout event on the object
;                                "MouseOver": ........ Fires a mouseover event on the object
;                                "MouseUp": .......... Fires a mouseup event on the object
;                       $nX:     [Optional: Default = Center width;
;                                 (Left position from 0 to width of object) to access object]
;                       $nX:     [Optional: Default = Center height;
;                                 (Left position from 0 to height of object) to access object]
;                       $nIndex  [Optional: -1 or Default = 0, positive integer only to a name
;                                 object you wish to interact with
; Return Value(s)..:
;                       Success...: True
;                       Failure...: False : Check @error
;                       Error.....: 0 = Success, error returns taken from IE.au3
;                                   1 = General Error, 2 = COM Error, 3 = Invalid Data Type
;                                   4 = Invalid Object Type, 5 = Invalid Value
;                                   6 = Load Wait Timeout, 7 = No Match, 8 = Access Denied
;                       Extended..: the number returned is for debugging only, there is data
;                                    returned for both success and failures, it marks the part
;                                    of the code for easier debugging
; Requirement(s)...:
; Author(s)........:    SmOke_N (Ron Nielsen) Ron.SMACKThatApp@gmail.com
; Modified.........:
; Comment(s).......:    see: http://msdn.microsoft.com/en-us/library/ie/ms536945(v=vs.85).aspx
;                        Warning:  If the object is not within the visible bounds of the document
;                         The by point options will not find the correct locations on the object probably
;                        You may need to scroll into view
; Example(s).......:    _IEEx_JSMouseEventObjByName($goDiv, "name", "clickpoint", 4, 8, 1)
;
;===================================================================================================

Func _IEEx_JSMouseEventObjByName(ByRef $oObj, $vName, $sEvent, $nX = Default, $nY = Default, $nIndex = Default)

	If Not IsObj($oObj) Then
		Return SetError($_IESTATUS_InvalidDataType, 1, False)
	EndIf

	$nIndex = (($nIndex < 0 Or IsKeyword($nIndex)) ? 0 : $nIndex)

	Local $oEventObj = ((IsObj($vName)) ? $vName : _IEGetObjByName($oObj, $vName, $nIndex))
	If Not IsObj($oEventObj) Then
		; no sense to go any further
		Return SetError($_IESTATUS_InvalidDataType, 2, False)
	EndIf

	Local $vRet = __IEEx_JSMouseEventObjBy($oObj, $oEventObj, $sEvent, $nX, $nY)
	Return SetError(@error, @extended, $vRet)
EndFunc   ;==>_IEEx_JSMouseEventObjByName

;================================================================================================================================
;
; Function Name....:    _IEEx_JSObjQuerySelector(ByRef $oObj, $sQuery[, $fQuirksMode = Default])
; Description......:    Method to retrieve data that combines options like getObjById, getObjByClass, getObjByName into one
; Parameter(s).....:
;                       $oObj:        The object you wish to search in
;                       $sQuery:      The query string
;                       $fQuirksMode: [Optional: Default = No Quirk
;                                      If IE8 or lower, it defaults to Quirk mode internally, IE9 forces IE8 non-standard, so
;                                      You may wish to use quirk mode anyway
; Return Value(s)..:
;                       Success...:   The first object found matching query
;                       Failure...:   0
;                       Error.....:   0 = Success, error returns taken from IE.au3
;                                     1 = General Error, 2 = COM Error, 3 = Invalid Data Type
;                                     4 = Invalid Object Type, 5 = Invalid Value
;                                     6 = Load Wait Timeout, 7 = No Match, 8 = Access Denied
;                       Extended..:   the number returned is for debugging only, there is data
;                                      returned for both success and failures, it marks the part
;                                      of the code for easier debugging
; Requirement(s)...:
; Author(s)........:    SmOke_N (Ron Nielsen) Ron.SMACKThatApp@gmail.com
; Modified.........:
; Comment(s).......:
; Example(s).......:    _IEEx_JSObjQuerySelector($oIE.document, 'div[class="gbs ova orp"]')
;
;================================================================================================================================

Func _IEEx_JSObjQuerySelector(ByRef $oObj, $sQuery, $fQuirksMode = Default)

	If Not IsObj($oObj) Then
		Return SetError($_IESTATUS_InvalidDataType, 1, 0)
	EndIf

	Local $oTObj = $oObj
	If _IEEx_GetObjType($oTObj) = "browser" Then
		$oTObj = $oObj.document
	EndIf

	Local $oDPW = _IEEx_GetObjParentWindow($oTObj)
	If Not IsObj($oDPW) Then
		Return SetError($_IESTATUS_InvalidObjectType, 2, 0)
	EndIf

	$oDPW = __IEEx_GetContainerObj($oDPW, "QuerySelector")
	If @error Then
		Return SetError(@error, @extended, 0)
	EndIf

	$fQuirksMode = ($fQuirksMode = Default Or $fQuirksMode < 1) ? 0 : 1

	Local $vRet = $oDPW.IEExAutQuerySelector($oTObj, $sQuery, $fQuirksMode)
	If $vRet Then
		Return SetError($_IESTATUS_InvalidObjectType, 5 + $vRet, 0)
	EndIf

	;return the object list
	Return SetError($_IESTATUS_Success, 1, $vRet)
EndFunc   ;==>_IEEx_JSObjQuerySelector

;================================================================================================================================
;
; Function Name....:    _IEEx_JSObjQuerySelectorAll(ByRef $oObj, $sQuery[, $fQuirksMode = Default[, $nIndex = Default]])
; Description......:    Method to retrieve data that combines options like getObjById, getObjByClass, getObjByName into one
; Parameter(s).....:
;                       $oObj:        The object you wish to search in
;                       $sQuery:      The query string
;                       $fQuirksMode: [Optional: Default = No Quirk
;                                      If IE8 or lower, it defaults to Quirk mode internally, IE9 forces IE8 non-standard, so
;                                      You may wish to use quirk mode anyway]
;                       $nIndex:       [Optional:  Default = All the objects, above 0 = index of objects collected you want]
; Return Value(s)..:
;                       Success...:   All the objects found matching query or the index chosen
;                       Failure...:   0
;                       Error.....:   0 = Success, error returns taken from IE.au3
;                                     1 = General Error, 2 = COM Error, 3 = Invalid Data Type
;                                     4 = Invalid Object Type, 5 = Invalid Value
;                                     6 = Load Wait Timeout, 7 = No Match, 8 = Access Denied
;                       Extended..:   the number returned is for debugging only, there is data
;                                      returned for both success and failures, it marks the part
;                                      of the code for easier debugging
; Requirement(s)...:
; Author(s)........:    SmOke_N (Ron Nielsen) Ron.SMACKThatApp@gmail.com
; Modified.........:
; Comment(s).......:
; Example(s).......:    _IEEx_JSObjQuerySelectorAll($oIE.document, 'div[class="gbs ova orp"]')
;
;================================================================================================================================

Func _IEEx_JSObjQuerySelectorAll(ByRef $oObj, $sQuery, $fQuirksMode = Default, $nIndex = Default)

	If Not IsObj($oObj) Then
		Return SetError($_IESTATUS_InvalidDataType, 1, 0)
	EndIf

	Local $oTObj = $oObj
	If _IEEx_GetObjType($oTObj) = "browser" Then
		$oTObj = $oObj.document
	EndIf

	Local $oDPW = _IEEx_GetObjParentWindow($oTObj)
	If Not IsObj($oDPW) Then
		Return SetError($_IESTATUS_InvalidObjectType, 2, 0)
	EndIf

	$oDPW = __IEEx_GetContainerObj($oDPW, "QuerySelectorAll")
	If @error Then
		Return SetError(@error, @extended, 0)
	EndIf

	$fQuirksMode = ($fQuirksMode = Default Or $fQuirksMode < 1) ? 0 : 1

	Local $vRet = $oDPW.IEExAutQuerySelectorAll($oTObj, $sQuery, $fQuirksMode)
	If $vRet Then
		Return SetError($_IESTATUS_InvalidObjectType, 5 + $vRet, 0)
	EndIf

	If Not IsObj($vRet) Then
		Return SetError($_IESTATUS_InvalidObjectType, 16, 0)
	EndIf

	$nIndex = ($nIndex = Default Or $nIndex < 0) ? -1 : $nIndex
	If ($nIndex > -1) And ($nIndex < $vRet.length) Then
		Return SetError($_IESTATUS_Success, 1, $vRet.item($nIndex))
	EndIf

	;return the object list
	Return SetError($_IESTATUS_Success, 2, $vRet)
EndFunc   ;==>_IEEx_JSObjQuerySelectorAll

;================================================================================================================================
;
; Function Name....:    _IEEx_JSTypeOf(ByRef $oObj, $vType)
; Description......:    Returns the JS "typeof" value for an object
; Parameter(s).....:
;                       $oObj:  The browser object
;                       $vType: The object you want the type of
; Return Value(s)..:
;                       Success...:  True
;                       Failure...:  False
;                       Error.....: 0 = Success, error returns taken from IE.au3
;                                   1 = General Error, 2 = COM Error, 3 = Invalid Data Type
;                                   4 = Invalid Object Type, 5 = Invalid Value
;                                   6 = Load Wait Timeout, 7 = No Match, 8 = Access Denied
;                       Extended..: the number returned is for debugging only, there is data
;                                    returned for both success and failures, it marks the part
;                                    of the code for easier debugging
; Requirement(s)...:
; Author(s)........:    SmOke_N (Ron Nielsen) Ron.SMACKThatApp@gmail.com
; Modified.........:
; Comment(s).......:
; Example(s).......:    _IEEx_JSTypeOf($goIE, $goButton)
;
;================================================================================================================================

Func _IEEx_JSTypeOf(ByRef $oObj, $vType)

	Local $oContainer = __IEEx_GetContainerObj($oObj, "TypeOf")
	If @error Then
		Return SetError(@error, @extended, "")
	EndIf

	Local $sRet = $oContainer.IEExAutTypeOf($vType)
	; success is based on the call being successful is all
	;  not the return value itself
	Return SetError($_IESTATUS_Success, 1, $sRet)
EndFunc   ;==>_IEEx_JSTypeOf

;================================================================================================================================
;
; Function Name....:    _IEEx_TabAttach($vObj, $sString [, $sMode = Default [, $iInstance = Default]])
; Description......:    An attempt to return the tabbed browser object
; Parameter(s).....:
;                       $vObj:      A browser object or the browser window handle/title
;                       $sString:   The string to search for
;                       $sMode:     The type of string to find:
;                                    "Title"      = the objects document.title value (exact match)
;                                    "InStrTitle" = Search $sString within the objects document.title value
;                                    "Instance"   = the tab instance only, not counting the original browser object
;                                    "URL"        = the objects url (.LocationURL) from $sString to find (exact match)
;                                    "InStrURL"   = Search $sString within the objects .LocationURL value
;                                    "Text"       = the objects document.body.innerHTML value (exact match)
;                                    "InStrText"  = Search $sString within the objects document.body.innerHTML value
;                                    "HTML"       = the objects .document.body.html value (exact match)
;                                    "InStrHTML"  = Search the $sString within the .document.body.html value
;                       $iInstance: The instance of a match in $sMode to return the object from
; Return Value(s)..:
;                       Success...: The tab object
;                       Failure...: 0
;                       Error.....: 0 = Success, error returns taken from IE.au3
;                                   1 = General Error, 2 = COM Error, 3 = Invalid Data Type
;                                   4 = Invalid Object Type, 5 = Invalid Value
;                                   6 = Load Wait Timeout, 7 = No Match, 8 = Access Denied
;                       Extended..: the number returned is for debugging only, there is data
;                                    returned for both success and failures, it marks the part
;                                    of the code for easier debugging
; Requirement(s)...:
; Author(s)........:    SmOke_N (Ron Nielsen) Ron.SMACKThatApp@gmail.com
; Modified.........:
; Comment(s).......:    All searches are done with case insensitivity
; Example(s).......:
;
;================================================================================================================================

Func _IEEx_TabAttach($vObj, $sString, $sMode = Default, $iInstance = Default)

	If IsObj($vObj) And Not _
		_IEEx_GetObjType($vObj) = "browser" Then
		Return SetError($_IESTATUS_InvalidDataType, 1, 0)
	EndIf

	Local $hWnd = $vObj
	If IsObj($vObj) And Not IsHWnd($hWnd) Then
		$hWnd = HWnd($vObj.hwnd)
	EndIf

	Local $aOWin = _IEEx_WinGetBrowserObjArray($hWnd)
	If @error Then
		Return SetError(@error, @extended + 1, 0)
	EndIf

	$sMode = (IsKeyword($sMode) Or $sMode = -1) ? "Title" : $sMode
	$iInstance = (IsKeyword($iInstance) Or $iInstance < 1) ? 1 : $iInstance

	Local $iInc = 1
	For $i = 0 To UBound($aOWin) - 1

		Switch StringLower($sMode)
			; hwnd cannot be an option, the main browser also has the same hwnd
			Case "title"
				If String($aOWin[$i].document.title) = $sString Then
					If $iInstance = $iInc Then
						Return SetError($_IESTATUS_Success, 1, $aOWin[$i])
					EndIf
					$iInc += 1
				EndIf
			Case "instrtitle"
				If StringInStr($aOWin[$i].document.title, $sString) Then
					If $iInstance = $iInc Then
						Return SetError($_IESTATUS_Success, 2, $aOWin[$i])
					EndIf
					$iInc += 1
				EndIf
			Case "instance"
				If $iInstance = $iInc Then
					Return SetError($_IESTATUS_Success, 3, $aOWin[$i])
				EndIf
				$iInc += 1
			Case "url"
				If String($aOWin[$i].LocationURL) = $sString Then
					If $iInstance = $iInc Then
						Return SetError($_IESTATUS_Success, 4, $aOWin[$i])
					EndIf
					$iInc += 1
				EndIf
			Case "instrurl"
				If StringInStr($aOWin[$i].LocationURL, $sString) Then
					If $iInstance = $iInc Then
						Return SetError($_IESTATUS_Success, 5, $aOWin[$i])
					EndIf
					$iInc += 1
				EndIf
			Case "text"
				If String($aOWin[$i].document.body.innerText) = $sString Then
					If $iInstance = $iInc Then
						Return SetError($_IESTATUS_Success, 6, $aOWin[$i])
					EndIf
					$iInc += 1
				EndIf
			Case "instrtext"
				If StringInStr($aOWin[$i].document.body.innerText, $sString) Then
					If $iInstance = $iInc Then
						Return SetError($_IESTATUS_Success, 7, $aOWin[$i])
					EndIf
					$iInc += 1
				EndIf
			Case "html"
				If String($aOWin[$i].document.body.innerHTML) = $sString Then
					If $iInstance = $iInc Then
						Return SetError($_IESTATUS_Success, 8, $aOWin[$i])
					EndIf
					$iInc += 1
				EndIf
			Case "instrhtml"
				If StringInStr($aOWin[$i].document.body.innerHTML, $sString) Then
					If $iInstance = $iInc Then
						Return SetError($_IESTATUS_Success, 8, $aOWin[$i])
					EndIf
					$iInc += 1
				EndIf
			Case Else
				Return SetError($_IESTATUS_InvalidValue, 4, 0)
		EndSwitch
	Next

	Return SetError($_IESTATUS_NoMatch, 5, 0)
EndFunc   ;==>_IEEx_TabAttach

;================================================================================================================================
;
; Function Name....:    _IEEx_TabCount($vObj)
; Description......:    Get the number of open tabs in your browser session, not counting the original browser object
; Parameter(s).....:
;                       $vObj:      A browser object or the browser window handle/title
; Return Value(s)..:
;                       Success...: The number of open tabs
;                       Failure...: 0
;                       Error.....: 0 = Success, error returns taken from IE.au3
;                                   1 = General Error, 2 = COM Error, 3 = Invalid Data Type
;                                   4 = Invalid Object Type, 5 = Invalid Value
;                                   6 = Load Wait Timeout, 7 = No Match, 8 = Access Denied
;                       Extended..: the number returned is for debugging only, there is data
;                                    returned for both success and failures, it marks the part
;                                    of the code for easier debugging
; Requirement(s)...:
; Author(s)........:    SmOke_N (Ron Nielsen) Ron.SMACKThatApp@gmail.com
; Modified.........:
; Comment(s).......:
; Example(s).......:
;
;================================================================================================================================

Func _IEEx_TabCount($vObj)

	If IsObj($vObj) And Not _
		_IEEx_GetObjType($vObj) = "browser" Then
		Return SetError($_IESTATUS_InvalidDataType, 1, 0)
	EndIf

	Local $hWnd = $vObj
	If IsObj($vObj) And Not IsHWnd($hWnd) Then
		$hWnd = HWnd($vObj.hwnd)
	EndIf

	Local $aOWin = _IEEx_WinGetBrowserObjArray($hWnd)
	If @error Then
		Return SetError(@error, @extended + 1, 0)
	EndIf

	Return SetError($_IESTATUS_Success, 1, UBound($aOWin))
EndFunc   ;==>_IEEx_TabCount

;================================================================================================================================
;
; Function Name....:    _IEEx_TabCreate(ByRef $oObj, $sURL [, $iWait = Default [, $iFlags = Default [, $sTarget = Default _
;                                                                      [, $sPostdata = Default [, $sHeaders = Default]]]]])
; Description......:    Create a new tab in an existing browser object and return that tabs browser object
; Parameter(s).....:
;                       $oObj:       The object to the IE browser
;                       $sURL:       The string URL you wish to navigate to
;                       $iWait:      [Optional: Default = True: Wait for window to load before returning]
;                       $iFlags:     [Optional: Default = 0x0800 (navOpenInNewTab)] Values accepted:
;                                      0x0800  (navOpenInNewTab)
;                                      0x10000 (navOpenNewForegroundTab)
;                       $sTarget:    [Optional: Default = "" (blank string)
;                                     Case-sensitive string expression that evaluates to the name of the frame in which
;                                      to display the resource. The possible values for this parameter are.
;                                     - "_blank" : Load the link into a new unnamed window.
;                                     - "_parent" : Load the link into the immediate parent of the document the link is in.
;                                     - "_self" : Load the link into the same window the link was clicked in.
;                                     - "_top" : Load the link into the full body of the current window.
;                                     - WindowName, A named HTML frame. If no frame or window exists that matches the _
;                                        specified target name, a new window is opened for the specified link.
;                       $sPostdata:  String data that is sent to the server as part of a HTTP POST transaction
;                       $sHeaders:   A String that contains additional HTTP headers to send to the server
; Return Value(s)..:
;                       Success...:  The new tab browser object
;                       Failure...:  0
;                       Error.....:  0 = Success, error returns taken from IE.au3
;                                    1 = General Error, 2 = COM Error, 3 = Invalid Data Type
;                                    4 = Invalid Object Type, 5 = Invalid Value
;                                    6 = Load Wait Timeout, 7 = No Match, 8 = Access Denied
;                       Extended..:  the number returned is for debugging only, there is data
;                                     returned for both success and failures, it marks the part
;                                     of the code for easier debugging
; Requirement(s)...:
; Author(s)........:    SmOke_N (Ron Nielsen) Ron.SMACKThatApp@gmail.com
; Modified.........:
; Comment(s).......:    This has not been thoroughly tested
; Example(s).......:    Global $goTab = _IEEx_TabCreate($goIE, "http://autoitscript.com/forum")
;
;================================================================================================================================

Func _IEEx_TabCreate(ByRef $oObj, $sURL, $iWait = Default, $iFlags = Default, $sTarget = Default, $sPostdata = Default, $sHeaders = Default)

	If Not IsObj($oObj) Then
		Return SetError($_IESTATUS_InvalidDataType, 1, 0)
	EndIf

	Local Const $inavOpenInNewTab = 0x0800
	Local Const $inavOpenNewForegroundTab = 0x10000

	$iWait = ($iWait = Default Or $iWait) ? 1 : 0
	$iFlags = (IsKeyword($iFlags) Or $iFlags < 1) ? $inavOpenInNewTab : $iFlags
	$iFlags = ($iFlags <> $inavOpenInNewTab And $iFlags <> _
		$inavOpenNewForegroundTab) ? $inavOpenInNewTab : $iFlags
	$sTarget = (IsKeyword($sTarget) Or Not StringLen($sTarget)) ? "" : $sTarget
	$sPostdata = (IsKeyword($sPostdata) Or Not StringLen($sPostdata)) ? "" : $sPostdata
	$sHeaders = (IsKeyword($sHeaders) Or Not StringLen($sHeaders)) ? "" : $sHeaders

	Local $oShell = ObjCreate("Shell.Application")
	Local $nCount = $oShell.windows.count()

	Local $iRet = $oObj.navigate2($sURL, $iFlags, $sTarget, $sPostdata, $sHeaders)
	If $iRet Then
		Return SetError($iRet, 2, 0)
	EndIf
	Local $oRet, $iTimer = TimerInit() ; set a 5 minute timeout
	Local $oWin

	While 1
		$oWin = $oShell.windows()
		If $oWin.count() <> $nCount Then
			$nCount = $oWin.count()
			$oRet = $oWin($nCount - 1)
			If $oRet.TopLevelContainer Then ExitLoop
		EndIf
		If (TimerDiff($iTimer) / 1000) >= 300 Then
			; timed out waiting, close IE instance
			Return SetError($_IESTATUS_LoadWaitTimeout, 3, 0)
		EndIf
		Sleep(10)
	WEnd

	If $iWait Then
		_IELoadWait($oRet)
		If @error Then
			Return SetError(@error, 4, $oRet)
		EndIf
	EndIf

	Return $oRet
EndFunc   ;==>_IEEx_TabCreate

;================================================================================================================================
;
; Function Name....:    _IEEx_TabGetInstance(ByRef $oObj)
; Description......:    Return the instance number of the browser object
; Parameter(s).....:
;                       $oObj:  The browser object we want the instance of
; Return Value(s)..:
;                       Success...: Instance number
;                       Failure...: 0
;                       Error.....: 0 = Success, error returns taken from IE.au3
;                                   1 = General Error, 2 = COM Error, 3 = Invalid Data Type
;                                   4 = Invalid Object Type, 5 = Invalid Value
;                                   6 = Load Wait Timeout, 7 = No Match, 8 = Access Denied
;                       Extended..: the number returned is for debugging only, there is data
;                                    returned for both success and failures, it marks the part
;                                    of the code for easier debugging
; Requirement(s)...:
; Author(s)........:    SmOke_N (Ron Nielsen) Ron.SMACKThatApp@gmail.com
; Modified.........:
; Comment(s).......:
; Example(s).......:
;
;================================================================================================================================

Func _IEEx_TabGetInstance(ByRef $oObj)

	If Not IsObj($oObj) Or Not _
		_IEEx_GetObjType($oObj) = "browser" Then
		Return SetError($_IESTATUS_InvalidDataType, 1, 0)
	EndIf

	Local $hWnd = HWnd($oObj.hwnd)

	Local $aOWin = _IEEx_WinGetBrowserObjArray($hWnd)
	If @error Then
		Return SetError(@error, @extended + 1, 0)
	EndIf

	For $i = 0 To UBound($aOWin) - 1
		If $aOWin[$i] = $oObj Then
			Return SetError($_IESTATUS_Success, 1, $i + 1)
		EndIf
	Next

	; we have to assume that the browser object was passed
	;  from InternetExplorer.Application
	; we have to treat this as a success if an array was sent back
	; will send back as 1
	; if it was sent as an _IEAttach() or Shell.Application object
	;  it will be #1 anyway

	Return SetError($_IESTATUS_Success, 2, 1)
EndFunc   ;==>_IEEx_TabGetInstance

; #FUNCTION# ====================================================================================================================
; Author ........: Dale Hohm
; Modified ......: Ron Nielsen
; ===============================================================================================================================

Func _IEEx_VersionInfo()
	Local Static $aVInfo = $__ga_IEExAU3VersionInfo
	Local Static $sVInfo = $aVInfo[0] & $aVInfo[1] & "." & $aVInfo[2] & "." & $aVInfo[3]
	Local Static $sDate = StringRegExpReplace($aVInfo[4], "(\d{4})(\d{2})(\d{2})", "$1-$2-$3")
	ConsoleWrite("_IEEx_VersionInfo:" & @CRLF & "Version: " & $sVInfo & @CRLF & _
			"Release Date: " & $sDate & @CRLF)
	Return SetError($_IESTATUS_Success, 1, $aVInfo)
EndFunc   ;==>_IEEx_VersionInfo

;================================================================================================================================
;
; Function Name....:    _IEEx_WhileIsObj(ByRef $oObj [, $iTimeoutSecs = Default [, $iSleepTime = Default]])
; Description......:    Wait for an object to be dereferenced
; Parameter(s).....:
;                       $oObj:          The object you want to wait on to be dereferenced
;                       $iTimeoutSecs:  [Optional: Default = 300 seconds]; Seconds before stop waiting and return timeout
;                       $iSleepTime:    [Optional: Default = 50 milliseconds]; Sleep(n) time within loop
; Return Value(s)..:
;                       Success...:  True
;                       Failure...:  False/Timed out
;                       Error.....: 0 = Success, error returns taken from IE.au3
;                                   1 = General Error, 2 = COM Error, 3 = Invalid Data Type
;                                   4 = Invalid Object Type, 5 = Invalid Value
;                                   6 = Load Wait Timeout, 7 = No Match, 8 = Access Denied
;                       Extended..: the number returned is for debugging only, there is data
;                                    returned for both success and failures, it marks the part
;                                    of the code for easier debugging
; Requirement(s)...:
; Author(s)........:    SmOke_N (Ron Nielsen) Ron.SMACKThatApp@gmail.com
; Modified.........:
; Comment(s).......:
; Example(s).......:
;
;================================================================================================================================
Func _IEEx_WhileIsObj(ByRef $oObj, $iTimeoutSecs = Default, $iSleepTime = Default)

	$iTimeoutSecs = ((IsKeyword($iTimeoutSecs) Or $iTimeoutSecs < 0) ? 300 : $iTimeoutSecs)

	$iSleepTime = ((IsKeyword($iSleepTime) Or $iSleepTime < 0) ? 50 : $iSleepTime)

	Local $nNotify = _IEErrorNotify()
	_IEErrorNotify(False)

	Local $iTimer = TimerInit()

	While IsObj($oObj)
		If $iTimeoutSecs Then
			If (TimerDiff($iTimer) / 1000 >= $iTimeoutSecs) Then
				_IEErrorNotify($nNotify)
				Return SetError($_IESTATUS_LoadWaitTimeout, 1, False)
			EndIf
		EndIf
		Sleep($iSleepTime)
	WEnd

	_IEErrorNotify($nNotify)
	Return SetError($_IESTATUS_Success, 1, True)
EndFunc

;================================================================================================================================
;
; Function Name....:    _IEEx_WhileNotIsObj(ByRef $oObj, $sQuery [, $sType = Default [, _
;                                           $nIndex = Default [, $iTimeoutSecs = Default [, $iSleepTime = Default]]]])
; Description......:    Wait for a query to become an object and return the object
; Parameter(s).....:
;                       $oObj:          The object you want to get the new object from
;                       $sQuery:        A query string
;                       $sType:         A string of the query type:
;                                        [Optional: Default = "queryselector"]
;                                        "class" or "classname"
;                                        "dot" or "dotnotaion"; "document.getElementById('id')"
;                                        "id"
;                                        "name"
;                                        "queryselector"; #id, .classname,[id=idstring],[class=classname],div[id="idname"], etc
;                       $nIndex:        [Optional: Default = 0]; index of all the objects found for query
;                       $iTimeoutSecs:  [Optional: Default = 300 seconds]; Seconds before stop waiting and return timeout
;                       $iSleepTime:    [Optional: Default = 50 milliseconds]; Sleep(n) time within loop
; Return Value(s)..:
;                       Success...: The object queried
;                       Failure...: 0
;                       Error.....: 0 = Success, error returns taken from IE.au3
;                                   1 = General Error, 2 = COM Error, 3 = Invalid Data Type
;                                   4 = Invalid Object Type, 5 = Invalid Value
;                                   6 = Load Wait Timeout, 7 = No Match, 8 = Access Denied
;                       Extended..: the number returned is for debugging only, there is data
;                                    returned for both success and failures, it marks the part
;                                    of the code for easier debugging
; Requirement(s)...:
; Author(s)........:    SmOke_N (Ron Nielsen) Ron.SMACKThatApp@gmail.com
; Modified.........:
; Comment(s).......:    For querySelector* read up on CSS selectors, also see below link
;                       http://www.w3schools.com/jsref/met_document_queryselector.asp
; Example(s).......:    Global $goIE = _IECreate("http://google.com", 0, 1, 0)
;                       Global $goObj = _IEEx_WhileNotIsObj($goIE, "#sb_ifc0"); #=id for queryselector*
;                       Global $gsReadyOrNot = ((IsObj($goObj)) ? "ok, object is available..." : "oops, failed to get object...")
;                       ConsoleWrite($gsReadyOrNot & @CRLF)
;                       _IELoadWait($goIE)
;                       ConsoleWrite("done.." & @CRLF)
;
;================================================================================================================================

Func _IEEx_WhileNotIsObj(ByRef $oObj, $sQuery, $sType = Default, _
		$nIndex = Default, $iTimeoutSecs = Default, $iSleepTime = Default)

	If Not IsObj($oObj) Then
		Return SetError($_IESTATUS_InvalidDataType, 1, 0)
	EndIf

	$sType = ((IsKeyword($sType) Or StringLen($sType) = 0) ? "queryselector" : $sType)

	$nIndex = ((IsKeyword($nIndex) Or $nIndex < 1) ? 0 : $nIndex)

	$iTimeoutSecs = ((IsKeyword($iTimeoutSecs) Or _
		$iTimeoutSecs < 0) ? 300 : $iTimeoutSecs)

	$iSleepTime = ((IsKeyword($iSleepTime) Or _
		$iSleepTime < 0) ? 10 : $iSleepTime)

	Local $oRet, $sExecuteStr
	Switch $sType
		Case "class", "classname"
			$sExecuteStr = "_IEEx_JSGetObjByClassName($oObj, $sQuery, Default, $nIndex)"
		Case "dot", "dotnotation"
			$sExecuteStr = "$oObj." & StringRegExpReplace($sQuery, "^\.", "")
		Case "id"
			$sExecuteStr = "_IEGetObjById($oObj, $sQuery)"
		Case "name"
			$sExecuteStr = "_IEGetObjByName($oObj, $sQuery, $nIndex)"
		Case "queryselector"
			$sExecuteStr = "_IEEx_JSObjQuerySelectorAll($oObj, $sQuery, Default, $nIndex)"
		Case Else
			Return SetError($_IESTATUS_NoMatch, 2, 0)
	EndSwitch

	Local $nNotify = _IEErrorNotify()
	_IEErrorNotify(False)

	Local $iTimer = TimerInit()

	While 1
		If Not IsObj($oObj) Then
			Return SetError($_IESTATUS_InvalidObjectType, 3, 0)
		EndIf
		$oRet = Execute($sExecuteStr)
		If IsObj($oRet) Then ExitLoop
		If $iTimeoutSecs Then
			If (TimerDiff($iTimer) / 1000 >= $iTimeoutSecs) Then
				_IEErrorNotify($nNotify)
				Return SetError($_IESTATUS_LoadWaitTimeout, 4, 0)
			EndIf
		EndIf
		Sleep(100)
	WEnd

	_IEErrorNotify($nNotify)
	Return SetError($_IESTATUS_Success, 1, $oRet)
EndFunc

;================================================================================================================================
;
; Function Name....:    _IEEx_WinGetBrowserObjArray([$vWnd = Default [, $sText = Default]])
; Description......:    Retrieve all the browser objects from either a window or another browser object
; Parameter(s).....:
;                       $vWnd:  (Optional: Default is active window; Handle or the title of the window to interact)
;                       $sText: (Optional: Default is empty string; String to find)
; Return Value(s)..:
;                       Success...: An array of browser objects (all the tabs) from 1 open browser session
;                       Failure...: 0
;                       Error.....: 0 = Success, error returns taken from IE.au3
;                                   1 = General Error, 2 = COM Error, 3 = Invalid Data Type
;                                   4 = Invalid Object Type, 5 = Invalid Value
;                                   6 = Load Wait Timeout, 7 = No Match, 8 = Access Denied
;                       Extended..: the number returned is for debugging only, there is data
;                                    returned for both success and failures, it marks the part
;                                    of the code for easier debugging
; Requirement(s)...:
; Author(s)........:    SmOke_N (Ron Nielsen) Ron.SMACKThatApp@gmail.com
; Modified.........:
; Comment(s).......:
; Example(s).......:
;
;================================================================================================================================

Func _IEEx_WinGetBrowserObjArray($vWnd = Default, $sText = Default)

	$vWnd = (IsKeyword($vWnd) Or Not StringLen($vWnd)) ? "[ACTIVE]" : $vWnd
	$sText = (IsKeyword($sText)) ? "" : $sText

	If Not IsHWnd($vWnd) Then
		$vWnd = WinGetHandle($vWnd, $sText)
		If Not IsHWnd($vWnd) Then
			Return SetError($_IESTATUS_NoMatch, 1, 0)
		EndIf
	EndIf

	Local $oShell = ObjCreate("Shell.Application")
	If Not IsObj($oShell) Then
		Return SetError($_IESTATUS_GeneralError, 2, 0)
	EndIf

	Local $oWins = $oShell.windows()
	Local $aORet[$oWins.count], $iEnum = 0
	Local $hWnd, $sType, $sTitle
	#forceref $sType, $sTitle

	For $oWin In $oWins

		$hWnd = HWnd($oWin.hWnd)
		; tabs will share the same hwnd as the main browser object
		If $vWnd <> $hWnd Then ContinueLoop

		; browser confirmation - start
		$sType = $oWin.type
		If @error Then ContinueLoop

		$sTitle = $oWin.document.title
		If @error Then ContinueLoop
		; browser confirmation - end

		$aORet[$iEnum] = $oWin
		$iEnum += 1
	Next

	If Not $iEnum Then
		Return SetError($_IESTATUS_NoMatch, 3, 0)
	EndIf

	ReDim $aORet[$iEnum]

	Return $aORet
EndFunc   ;==>_IEEx_WinGetBrowserObjArray

; #INTERNAL_USE_ONLY#============================================================================================================
Func __IEEx_CreateJScript($sAccessObjName, $sParams = "", $sJScript = "")

	If Not StringLen($sAccessObjName) Then
		Return SetError(1, 0, "")
	EndIf

	Local $sScriptOut = ""
	$sScriptOut &= "function IEExAut" & $sAccessObjName & "Func() {" & @CRLF
	$sScriptOut &= @TAB & "var autDIV = document.createElement('div');" & @CRLF
	$sScriptOut &= @TAB & "autDIV.setAttribute('id', 'IEExAut" & $sAccessObjName & "Id');" & @CRLF
	$sScriptOut &= @TAB & "document.body.appendChild(autDIV);" & @CRLF
	$sScriptOut &= @TAB & "var autVariable = document.getElementById('IEExAut" & $sAccessObjName & "Id');" & @CRLF
	$sScriptOut &= @TAB & "autVariable.IEExAut" & $sAccessObjName & " = function (" & $sParams & ") {" & @CRLF
	$sScriptOut &= @CRLF & @CRLF & $sJScript & @CRLF & @TAB & "};" & @CRLF & "}"

	Return $sScriptOut
EndFunc   ;==>__IEEx_CreateJScript

Func __IEEx_GetContainerObj(ByRef $oObj, $sContainer)

	If Not IsObj($oObj) Then
		Return SetError($_IESTATUS_InvalidDataType, 1, 0)
	EndIf

	; try to prevent multiple insertions into the body
	; this way we don't have to know exactly what object type was passed
	Local Const $aGetObj[] = [ _
		'$oObj.document.parentWindow.getElementById("IEExAut" & $sContainer & "Id")', _
		'$oObj.parentWindow.getElementById("IEExAut" & $sContainer & "Id")', _
		'$oObj.document.getElementById("IEExAut" & $sContainer & "Id")', _
		'$oObj.getElementById("IEExAut" & $sContainer & "Id")', _
		'$oObj.contentDocument.contentWindow.getElementById("IEExAut" & $sContainer & "Id")', _
		'$oObj.contentDocument.getElementById("IEExAut" & $sContainer & "Id")']

	;does our div id exist
	Local $oDPW = 0
	For $i = 0 To UBound($aGetObj) - 1
		$oDPW = Execute($aGetObj[$i])
		If IsObj($oDPW) Then ExitLoop
	Next
	If Not IsObj($oDPW) Then
		; insert script

		_IEEx_CallObjExecScript($oObj, __IEEx_GetInsertScript("IEExAut" & $sContainer))
		If @error Then
			Return SetError(@error, 3, False)
		EndIf

		$oDPW = _IEEx_GetObjParentWindow($oObj)
		If Not IsObj($oDPW) Then
			Return SetError($_IESTATUS_InvalidObjectType, 4, False)
		EndIf

		; call div create func
		_IEEx_CallObjExecScript($oDPW, "IEExAut" & $sContainer & "Func();")
		; let's try to make this succeed with two more conditions, even if the object
		;  passed is not correctly formatted this is essential fo run-on functions
		;  that we're using internally
		For $i = 0 To UBound($aGetObj) - 1
			$oDPW = Execute($aGetObj[$i])
			If IsObj($oDPW) Then ExitLoop
		Next
		If Not IsObj($oDPW) Then
			Return SetError($_IESTATUS_InvalidDataType, 5, False)
		EndIf
	EndIf

	Return $oDPW
EndFunc   ;==>__IEEx_GetContainerObj

Func __IEEx_GetInsertScript($sInsertType)

	Local $sScript = ""

	;"IEExAutClickObj", "IEExAutClickObjXY", "IEExAutEvalObj", "IEExAutClassGetCollection"
	;"IEExAutClickObjById", "IEExAutMouseEvent", "IEExAutDragEvent", "IEExAutTypeOf", "IEExAutGetObjPos"

	Switch $sInsertType
		Case "IEExAutQuerySelectorAll"
			$sScript &= "66756E6374696F6E2049454578417574517565727953656C6563746F72416C6C46756E632829207B"
			$sScript &= "0D0A2020202076617220617574444956203D20646F63756D656E742E637265617465456C656D656E"
			$sScript &= "74282764697627293B0D0A202020206175744449562E73657441747472696275746528276964272C"
			$sScript &= "202749454578417574517565727953656C6563746F72416C6C496427293B0D0A20202020646F6375"
			$sScript &= "6D656E742E626F64792E617070656E644368696C6428617574444956293B0D0A2020202076617220"
			$sScript &= "6175745661726961626C65203D20646F63756D656E742E676574456C656D656E7442794964282749"
			$sScript &= "454578417574517565727953656C6563746F72416C6C496427293B0D0A2020202061757456617269"
			$sScript &= "61626C652E49454578417574517565727953656C6563746F72416C6C203D2066756E6374696F6E20"
			$sScript &= "286F4F626A2C207351756572792C2062517569726B734D6F646529207B0D0A0D0A20202020202020"
			$sScript &= "2069662028747970656F66206F4F626A203D3D2027756E646566696E65642729207B72657475726E"
			$sScript &= "20313B7D0D0A202020202020202069662028747970656F6620735175657279203D3D2027756E6465"
			$sScript &= "66696E65642729207B72657475726E20323B7D0D0A0D0A20202020202020202F2F2076616C696461"
			$sScript &= "746520717569726B736D6F64650D0A202020202020202069662028747970656F662062517569726B"
			$sScript &= "734D6F6465203D3D2027756E646566696E656427297B0D0A20202020202020202020202062517569"
			$sScript &= "726B734D6F6465203D2028646F63756D656E742E636F6D7061744D6F6465203D3D20274353533143"
			$sScript &= "6F6D7061742729203F2030203A20313B0D0A20202020202020207D0D0A0D0A202020202020202069"
			$sScript &= "6620282862517569726B734D6F6465203D3D2030292026262028747970656F66206F4F626A2E7175"
			$sScript &= "65727953656C6563746F72416C6C20213D2027756E646566696E65642729297B0D0A202020202020"
			$sScript &= "20202020202072657475726E206F4F626A2E717565727953656C6563746F72416C6C287351756572"
			$sScript &= "79293B0D0A20202020202020207D0D0A20202020202020202F2F20617373756D6520717569726B73"
			$sScript &= "206D6F6465206F72206C6F776572206C6576656C20494520283C39290D0A20202020202020202F2F"
			$sScript &= "2049453720737570706F727420666F7220717565727953656C6563746F72416C6C2E20537570706F"
			$sScript &= "727473206D756C7469706C65202F2067726F757065640D0A20202020202020202F2F202073656C65"
			$sScript &= "63746F727320616E6420746865206174747269627574652073656C6563746F722077697468206120"
			$sScript &= "22666F7222206174747269627574652E0D0A20202020202020202F2F20205468616E6B732044616E"
			$sScript &= "3B20687474703A2F2F7777772E636F6465636F7563682E636F6D2F0D0A2020202020202020766172"
			$sScript &= "206F5374796C65203D20303B0D0A202020202020202069662028747970656F66206F4F626A2E6372"
			$sScript &= "656174655374796C65536865657420213D2027756E646566696E656427297B0D0A20202020202020"
			$sScript &= "20202020206F5374796C65203D206F4F626A2E6372656174655374796C65536865657428293B0D0A"
			$sScript &= "20202020202020207D0D0A2020202020202020656C73652069662028747970656F66206F5374796C"
			$sScript &= "65203D3D20276E756D6265722729207B0D0A20202020202020202020202069662028747970656F66"
			$sScript &= "206F4F626A2E646F63756D656E742E6372656174655374796C65536865657420213D2027756E6465"
			$sScript &= "66696E65642729207B0D0A202020202020202020202020202020206F5374796C65203D206F4F626A"
			$sScript &= "2E646F63756D656E742E6372656174655374796C65536865657428293B0D0A202020202020202020"
			$sScript &= "2020207D0D0A202020202020202020202020656C7365207B0D0A2020202020202020202020202020"
			$sScript &= "20206F5374796C65203D20646F63756D656E742E6372656174655374796C65536865657428293B0D"
			$sScript &= "0A2020202020202020202020207D0D0A20202020202020207D0D0A0D0A2020202020202020766172"
			$sScript &= "2062466F756E64203D20303B0D0A2020202020202020766172206F526574203D205B5D3B0D0A2020"
			$sScript &= "202020202020766172206F416C6C203D206F4F626A2E616C6C3B0D0A202020202020202076617220"
			$sScript &= "615175657279203D207351756572792E7265706C616365282F5C5B666F725C622F67692C20275B68"
			$sScript &= "746D6C466F7227292E73706C697428272C27293B0D0A202020202020202076617220692C6A3B0D0A"
			$sScript &= "2020202020202020666F72202869203D20303B2069203C206151756572792E6C656E6774683B2069"
			$sScript &= "2B2B29207B0D0A2020202020202020202020206F5374796C652E61646452756C6528615175657279"
			$sScript &= "5B695D2C20276B3A7627293B0D0A202020202020202020202020666F7220286A203D20303B206A20"
			$sScript &= "3C206F416C6C2E6C656E6774683B206A2B2B29207B0D0A2020202020202020202020202020202069"
			$sScript &= "6620286F416C6C5B6A5D2E63757272656E745374796C652E6B203D3D2027762729207B0D0A202020"
			$sScript &= "202020202020202020202020202020202062466F756E64203D20313B0D0A20202020202020202020"
			$sScript &= "202020202020202020206F5265742E70757368286F416C6C5B6A5D293B0D0A202020202020202020"
			$sScript &= "202020202020207D0D0A2020202020202020202020207D0D0A2020202020202020202020206F5374"
			$sScript &= "796C652E72656D6F766552756C652830293B0D0A20202020202020207D0D0A202020202020202069"
			$sScript &= "66202862466F756E6420213D203029207B72657475726E206F5265747D0D0A202020202020202072"
			$sScript &= "657475726E20343B0D0A202020207D3B0D0A7D"
		Case "IEExAutQuerySelector"
			$sScript &= "66756E6374696F6E2049454578417574517565727953656C6563746F7246756E632829207B0D0A20"
			$sScript &= "20202076617220617574444956203D20646F63756D656E742E637265617465456C656D656E742827"
			$sScript &= "64697627293B0D0A202020206175744449562E73657441747472696275746528276964272C202749"
			$sScript &= "454578417574517565727953656C6563746F72496427293B0D0A20202020646F63756D656E742E62"
			$sScript &= "6F64792E617070656E644368696C6428617574444956293B0D0A2020202076617220617574566172"
			$sScript &= "6961626C65203D20646F63756D656E742E676574456C656D656E7442794964282749454578417574"
			$sScript &= "517565727953656C6563746F72496427293B0D0A202020206175745661726961626C652E49454578"
			$sScript &= "417574517565727953656C6563746F72203D2066756E6374696F6E20286F4F626A2C207351756572"
			$sScript &= "792C2062517569726B734D6F646529207B0D0A0D0A202020202020202069662028747970656F6620"
			$sScript &= "6F4F626A203D3D2027756E646566696E65642729207B72657475726E20313B7D0D0A202020202020"
			$sScript &= "202069662028747970656F6620735175657279203D3D2027756E646566696E65642729207B726574"
			$sScript &= "75726E20323B7D0D0A0D0A20202020202020202F2F2076616C696461746520717569726B736D6F64"
			$sScript &= "650D0A202020202020202069662028747970656F662062517569726B734D6F6465203D3D2027756E"
			$sScript &= "646566696E656427297B0D0A20202020202020202020202062517569726B734D6F6465203D202864"
			$sScript &= "6F63756D656E742E636F6D7061744D6F6465203D3D202743535331436F6D7061742729203F203020"
			$sScript &= "3A20313B0D0A20202020202020207D0D0A0D0A2020202020202020696620282862517569726B734D"
			$sScript &= "6F6465203D3D2030292026262028747970656F66206F4F626A2E717565727953656C6563746F7220"
			$sScript &= "213D2027756E646566696E65642729297B0D0A20202020202020202020202072657475726E206F4F"
			$sScript &= "626A2E717565727953656C6563746F7228735175657279293B0D0A20202020202020207D0D0A2020"
			$sScript &= "2020202020202F2F20617373756D6520717569726B73206D6F6465206F72206C6F776572206C6576"
			$sScript &= "656C20494520283C39290D0A20202020202020202F2F2049453720737570706F727420666F722071"
			$sScript &= "7565727953656C6563746F72416C6C2E20537570706F727473206D756C7469706C65202F2067726F"
			$sScript &= "757065640D0A20202020202020202F2F202073656C6563746F727320616E64207468652061747472"
			$sScript &= "69627574652073656C6563746F72207769746820612022666F7222206174747269627574652E0D0A"
			$sScript &= "20202020202020202F2F20205468616E6B732044616E3B20687474703A2F2F7777772E636F646563"
			$sScript &= "6F7563682E636F6D2F0D0A2020202020202020766172206F5374796C65203D20303B0D0A20202020"
			$sScript &= "2020202069662028747970656F66206F4F626A2E6372656174655374796C65536865657420213D20"
			$sScript &= "27756E646566696E656427297B0D0A2020202020202020202020206F5374796C65203D206F4F626A"
			$sScript &= "2E6372656174655374796C65536865657428293B0D0A20202020202020207D0D0A20202020202020"
			$sScript &= "20656C73652069662028747970656F66206F5374796C65203D3D20276E756D6265722729207B0D0A"
			$sScript &= "20202020202020202020202069662028747970656F66206F4F626A2E646F63756D656E742E637265"
			$sScript &= "6174655374796C65536865657420213D2027756E646566696E65642729207B0D0A20202020202020"
			$sScript &= "2020202020202020206F5374796C65203D206F4F626A2E646F63756D656E742E6372656174655374"
			$sScript &= "796C65536865657428293B0D0A2020202020202020202020207D0D0A202020202020202020202020"
			$sScript &= "656C7365207B0D0A202020202020202020202020202020206F5374796C65203D20646F63756D656E"
			$sScript &= "742E6372656174655374796C65536865657428293B0D0A2020202020202020202020207D0D0A2020"
			$sScript &= "2020202020207D0D0A0D0A2020202020202020766172206F416C6C203D206F4F626A2E616C6C3B0D"
			$sScript &= "0A202020202020202076617220615175657279203D207351756572792E7265706C616365282F5C5B"
			$sScript &= "666F725C622F67692C20275B68746D6C466F7227292E73706C697428272C27293B0D0A2020202020"
			$sScript &= "20202076617220692C6A3B0D0A2020202020202020666F72202869203D20303B2069203C20615175"
			$sScript &= "6572792E6C656E6774683B20692B2B29207B0D0A2020202020202020202020206F5374796C652E61"
			$sScript &= "646452756C65286151756572795B695D2C20276B3A7627293B0D0A20202020202020202020202066"
			$sScript &= "6F7220286A203D20303B206A203C206F416C6C2E6C656E6774683B206A2B2B29207B0D0A20202020"
			$sScript &= "202020202020202020202020696620286F416C6C5B6A5D2E63757272656E745374796C652E6B203D"
			$sScript &= "3D2027762729207B0D0A20202020202020202020202020202020202020206F5374796C652E72656D"
			$sScript &= "6F766552756C652830293B0D0A202020202020202020202020202020202020202072657475726E20"
			$sScript &= "6F416C6C5B6A5D3B0D0A202020202020202020202020202020207D0D0A2020202020202020202020"
			$sScript &= "207D0D0A2020202020202020202020206F5374796C652E72656D6F766552756C652830293B0D0A20"
			$sScript &= "202020202020207D0D0A202020202020202072657475726E20343B0D0A202020207D3B0D0A7D"
		Case "IEExAutGetObjPos"
			$sScript &= "66756E6374696F6E20494545784175744765744F626A506F7346756E632829207B0D0A2020202076"
			$sScript &= "617220617574444956203D20646F63756D656E742E637265617465456C656D656E74282764697627"
			$sScript &= "293B0D0A202020206175744449562E73657441747472696275746528276964272C20274945457841"
			$sScript &= "75744765744F626A506F73496427293B0D0A20202020646F63756D656E742E626F64792E61707065"
			$sScript &= "6E644368696C6428617574444956293B0D0A20202020766172206175745661726961626C65203D20"
			$sScript &= "646F63756D656E742E676574456C656D656E74427949642822494545784175744765744F626A506F"
			$sScript &= "73496422293B0D0A202020206175745661726961626C652E494545784175744765744F626A506F73"
			$sScript &= "203D2066756E6374696F6E20286F4F626A29207B0D0A090D0A2020202020202020766172206E5820"
			$sScript &= "3D20303B0D0A2020202020202020766172206E59203D20303B0D0A0909766172206F546D70203D20"
			$sScript &= "6F4F626A3B0D0A09097768696C65286F546D70202626202169734E614E286F546D702E6F66667365"
			$sScript &= "744C65667429202626202169734E614E286F546D702E6F6666736574546F702929207B0D0A090909"
			$sScript &= "6E58202B3D206F546D702E6F66667365744C656674202D206F546D702E7363726F6C6C4C6566743B"
			$sScript &= "0D0A0909096E59202B3D206F546D702E6F6666736574546F70202D206F546D702E7363726F6C6C54"
			$sScript &= "6F703B0D0A0909096F546D70203D206F546D702E6F6666736574506172656E743B0D0A09097D0D0A"
			$sScript &= "09090D0A2020202020202020766172206F52656374203D206F4F626A2E676574426F756E64696E67"
			$sScript &= "436C69656E745265637428293B0D0A0909766172206E5769647468203D206F526563742E72696768"
			$sScript &= "74202D206F526563742E6C6566743B0D0A2020202020202020766172206E486569676874203D206F"
			$sScript &= "526563742E626F74746F6D202D206F526563742E746F703B0D0A09090D0A20202020202020207265"
			$sScript &= "7475726E207B6C6566743A206E582C20746F703A206E592C2077696474683A206E57696474682C20"
			$sScript &= "6865696768743A206E4865696768747D3B0D0A202020207D3B0D0A7D"
		Case "IEExAutTypeOf"
			$sScript &= "66756E6374696F6E2049454578417574547970654F6646756E632829207B0D0A2020202076617220"
			$sScript &= "617574444956203D20646F63756D656E742E637265617465456C656D656E74282764697627293B0D"
			$sScript &= "0A202020206175744449562E73657441747472696275746528276964272C20274945457841757454"
			$sScript &= "7970654F66496427293B0D0A20202020646F63756D656E742E626F64792E617070656E644368696C"
			$sScript &= "6428617574444956293B0D0A2020202076617220617574547970654F66203D20646F63756D656E74"
			$sScript &= "2E676574456C656D656E7442794964282749454578417574547970654F66496427293B0D0A202020"
			$sScript &= "20617574547970654F662E49454578417574547970654F66203D2066756E6374696F6E2028764F62"
			$sScript &= "6A29207B0D0A202020202020202072657475726E2028747970656F6620764F626A293B0D0A202020"
			$sScript &= "207D3B0D0A7D"
		Case "IEExAutMouseEvent"
			$sScript &= "2F2A20206D6F757365206576656E742066756E63207374617274202A2F0D0A66756E6374696F6E20"
			$sScript &= "49454578417574547269676765724D6F7573654576656E7446756E63286175744E6F64652C206175"
			$sScript &= "744576656E74547970652C206175744576656E744E616D6529207B0D0A0969662028747970656F66"
			$sScript &= "206175744576656E744E616D65203D3D2027756E646566696E65642729207B0D0A09096175744576"
			$sScript &= "656E744E616D65203D20274D6F7573654576656E7473273B0D0A097D0D0A20202020766172206175"
			$sScript &= "744D6F7573654576656E74203D20646F63756D656E742E6372656174654576656E74286175744576"
			$sScript &= "656E744E616D65293B0D0A202020206175744D6F7573654576656E742E696E69744576656E742861"
			$sScript &= "75744576656E74547970652C20747275652C2074727565293B0D0A2020202069662028747970656F"
			$sScript &= "66206175744E6F64652E64697370617463684576656E74203D3D2027756E646566696E6564272920"
			$sScript &= "7B72657475726E20317D3B0D0A202020206175744E6F64652E64697370617463684576656E742861"
			$sScript &= "75744D6F7573654576656E74293B0D0A202020202F2A2073756363657373202A2F0D0A2020202072"
			$sScript &= "657475726E20303B0D0A7D0D0A0D0A66756E6374696F6E20494545784175744D6F7573654576656E"
			$sScript &= "7446756E632829207B0D0A2020202076617220617574444956203D20646F63756D656E742E637265"
			$sScript &= "617465456C656D656E74282764697627293B0D0A202020206175744449562E736574417474726962"
			$sScript &= "75746528276964272C2027494545784175744D6F7573654576656E74496427293B0D0A2020202064"
			$sScript &= "6F63756D656E742E626F64792E617070656E644368696C6428617574444956293B0D0A2020202076"
			$sScript &= "6172206175744D6F757365203D20646F63756D656E742E676574456C656D656E7442794964282749"
			$sScript &= "4545784175744D6F7573654576656E74496427293B0D0A202020206175744D6F7573652E49454578"
			$sScript &= "4175744D6F7573654576656E74203D2066756E6374696F6E286F4F626A2C2073416374696F6E2C20"
			$sScript &= "6E582C206E5929207B0D0A0D0A202020202020202069662028747970656F66206F4F626A203D3D20"
			$sScript &= "27756E646566696E65642729207B72657475726E20313B7D0D0A2020202020202020696620287479"
			$sScript &= "70656F662073416374696F6E203D3D2027756E646566696E65642729207B73416374696F6E203D20"
			$sScript &= "27636C69636B273B7D0D0A202020202020202069662028747970656F66206E58203D3D2027756E64"
			$sScript &= "6566696E65642729207B6E58203D20303B7D0D0A202020202020202069662028747970656F66206E"
			$sScript &= "59203D3D2027756E646566696E65642729207B6E59203D20303B7D0D0A0D0A202020202020202076"
			$sScript &= "6172206F526563743B0D0A0D0A202020202020202076617220734C6F776572203D2073416374696F"
			$sScript &= "6E2E746F4C6F7765724361736528293B0D0A202020202020202073776974636828734C6F77657229"
			$sScript &= "207B0D0A202020202020202020202020636173652027636C69636B273A0D0A202020202020202020"
			$sScript &= "202020202020206966202849454578417574547269676765724D6F7573654576656E7446756E6328"
			$sScript &= "6F4F626A2C2027636C69636B272929207B72657475726E20333B7D0D0A2020202020202020202020"
			$sScript &= "2020202020627265616B3B0D0A202020202020202020202020636173652027636C69636B706F696E"
			$sScript &= "74273A0D0A202020202020202020202020202020206F52656374203D206F4F626A2E676574426F75"
			$sScript &= "6E64696E67436C69656E745265637428293B0D0A202020202020202020202020202020202F2A2066"
			$sScript &= "696E6420636C69636B20636F6F7264696E61746573202A2F0D0A2020202020202020202020202020"
			$sScript &= "20206E58203D20286E58203D3D3D203029203F206F526563742E6C656674202B204D6174682E726F"
			$sScript &= "756E642828286F526563742E7269676874202D206F526563742E6C65667429202F20322929203A20"
			$sScript &= "6E58202B206F526563742E6C6566743B0D0A202020202020202020202020202020206E59203D2028"
			$sScript &= "6E59203D3D3D203029203F206F526563742E746F70202B204D6174682E726F756E642828286F5265"
			$sScript &= "63742E626F74746F6D202D206F526563742E746F7029202F20322929203A206E59202B206F526563"
			$sScript &= "742E746F703B0D0A2020202020202020202020202020202069662028494545784175745472696767"
			$sScript &= "65724D6F7573654576656E7446756E63286F4F626A2E646F63756D656E742E656C656D656E744672"
			$sScript &= "6F6D506F696E74286E582C206E59292C2027636C69636B272929207B72657475726E20333B7D0D0A"
			$sScript &= "20202020202020202020202020202020627265616B3B0D0A20202020202020202020202063617365"
			$sScript &= "2027636F6E746578746D656E75273A0D0A2020202020202020202020202020202069662028494545"
			$sScript &= "78417574547269676765724D6F7573654576656E7446756E63286F4F626A2C2027636F6E74657874"
			$sScript &= "6D656E75272929207B72657475726E20333B7D0D0A20202020202020202020202020202020627265"
			$sScript &= "616B3B0D0A202020202020202020202020636173652027636F6E746578746D656E75706F696E7427"
			$sScript &= "3A0D0A202020202020202020202020202020206F52656374203D206F4F626A2E676574426F756E64"
			$sScript &= "696E67436C69656E745265637428293B0D0A202020202020202020202020202020202F2A2066696E"
			$sScript &= "6420636C69636B20636F6F7264696E61746573202A2F0D0A20202020202020202020202020202020"
			$sScript &= "6E58203D20286E58203D3D3D203029203F206F526563742E6C656674202B204D6174682E726F756E"
			$sScript &= "642828286F526563742E7269676874202D206F526563742E6C65667429202F20322929203A206E58"
			$sScript &= "202B206F526563742E6C6566743B0D0A202020202020202020202020202020206E59203D20286E59"
			$sScript &= "203D3D3D203029203F206F526563742E746F70202B204D6174682E726F756E642828286F52656374"
			$sScript &= "2E626F74746F6D202D206F526563742E746F7029202F20322929203A206E59202B206F526563742E"
			$sScript &= "746F703B0D0A20202020202020202020202020202020696620284945457841757454726967676572"
			$sScript &= "4D6F7573654576656E7446756E63286F4F626A2E646F63756D656E742E656C656D656E7446726F6D"
			$sScript &= "506F696E74286E582C206E59292C2027636F6E746578746D656E75272929207B72657475726E2033"
			$sScript &= "3B7D0D0A20202020202020202020202020202020627265616B3B0D0A202020202020202020202020"
			$sScript &= "63617365202764626C636C69636B273A0D0A20202020202020202020202020202020696620284945"
			$sScript &= "4578417574547269676765724D6F7573654576656E7446756E63286F4F626A2C202764626C636C69"
			$sScript &= "636B272929207B72657475726E20333B7D0D0A20202020202020202020202020202020627265616B"
			$sScript &= "3B0D0A20202020202020202020202063617365202764626C636C69636B706F696E74273A0D0A2020"
			$sScript &= "20202020202020202020202020206F52656374203D206F4F626A2E676574426F756E64696E67436C"
			$sScript &= "69656E745265637428293B0D0A202020202020202020202020202020202F2A2066696E6420636C69"
			$sScript &= "636B20636F6F7264696E61746573202A2F0D0A202020202020202020202020202020206E58203D20"
			$sScript &= "286E58203D3D3D203029203F206F526563742E6C656674202B204D6174682E726F756E642828286F"
			$sScript &= "526563742E7269676874202D206F526563742E6C65667429202F20322929203A206E58202B206F52"
			$sScript &= "6563742E6C6566743B0D0A202020202020202020202020202020206E59203D20286E59203D3D3D20"
			$sScript &= "3029203F206F526563742E746F70202B204D6174682E726F756E642828286F526563742E626F7474"
			$sScript &= "6F6D202D206F526563742E746F7029202F20322929203A206E59202B206F526563742E746F703B0D"
			$sScript &= "0A202020202020202020202020202020206966202849454578417574547269676765724D6F757365"
			$sScript &= "4576656E7446756E63286F4F626A2E646F63756D656E742E656C656D656E7446726F6D506F696E74"
			$sScript &= "286E582C206E59292C202764626C636C69636B272929207B72657475726E20333B7D0D0A20202020"
			$sScript &= "202020202020202020202020627265616B3B0D0A2020202020202020202020206361736520276D6F"
			$sScript &= "757365636C69636B273A0D0A20202020202020202020202020202020696620284945457841757454"
			$sScript &= "7269676765724D6F7573654576656E7446756E63286F4F626A2C20276D6F7573656F766572272929"
			$sScript &= "207B72657475726E20333B7D0D0A2020202020202020202020202020202069662028494545784175"
			$sScript &= "74547269676765724D6F7573654576656E7446756E63286F4F626A2C20276D6F757365646F776E27"
			$sScript &= "2929207B72657475726E20343B7D0D0A202020202020202020202020202020206966202849454578"
			$sScript &= "417574547269676765724D6F7573654576656E7446756E63286F4F626A2C20276D6F757365757027"
			$sScript &= "2929207B72657475726E20353B7D0D0A202020202020202020202020202020206966202849454578"
			$sScript &= "417574547269676765724D6F7573654576656E7446756E63286F4F626A2C2027636C69636B272929"
			$sScript &= "207B72657475726E20363B7D0D0A20202020202020202020202020202020627265616B3B0D0A2020"
			$sScript &= "202020202020202020206361736520276D6F757365636C69636B706F696E74273A0D0A2020202020"
			$sScript &= "20202020202020202020206F52656374203D206F4F626A2E676574426F756E64696E67436C69656E"
			$sScript &= "745265637428293B0D0A202020202020202020202020202020202F2A2066696E6420636C69636B20"
			$sScript &= "636F6F7264696E61746573202A2F0D0A202020202020202020202020202020206E58203D20286E58"
			$sScript &= "203D3D3D203029203F206F526563742E6C656674202B204D6174682E726F756E642828286F526563"
			$sScript &= "742E7269676874202D206F526563742E6C65667429202F20322929203A206E58202B206F52656374"
			$sScript &= "2E6C6566743B0D0A202020202020202020202020202020206E59203D20286E59203D3D3D20302920"
			$sScript &= "3F206F526563742E746F70202B204D6174682E726F756E642828286F526563742E626F74746F6D20"
			$sScript &= "2D206F526563742E746F7029202F20322929203A206E59202B206F526563742E746F703B0D0A2020"
			$sScript &= "20202020202020202020202020206966202849454578417574547269676765724D6F757365457665"
			$sScript &= "6E7446756E63286F4F626A2E646F63756D656E742E656C656D656E7446726F6D506F696E74286E58"
			$sScript &= "2C206E59292C20276D6F7573656F766572272929207B72657475726E20333B7D0D0A202020202020"
			$sScript &= "202020202020202020206966202849454578417574547269676765724D6F7573654576656E744675"
			$sScript &= "6E63286F4F626A2E646F63756D656E742E656C656D656E7446726F6D506F696E74286E582C206E59"
			$sScript &= "292C20276D6F757365646F776E272929207B72657475726E20343B7D0D0A20202020202020202020"
			$sScript &= "2020202020206966202849454578417574547269676765724D6F7573654576656E7446756E63286F"
			$sScript &= "4F626A2E646F63756D656E742E656C656D656E7446726F6D506F696E74286E582C206E59292C2027"
			$sScript &= "6D6F7573657570272929207B72657475726E20353B7D0D0A20202020202020202020202020202020"
			$sScript &= "6966202849454578417574547269676765724D6F7573654576656E7446756E63286F4F626A2E646F"
			$sScript &= "63756D656E742E656C656D656E7446726F6D506F696E74286E582C206E59292C2027636C69636B27"
			$sScript &= "2929207B72657475726E20363B7D0D0A20202020202020202020202020202020627265616B3B0D0A"
			$sScript &= "2020202020202020202020206361736520276D6F75736564626C636C69636B273A0D0A2020202020"
			$sScript &= "20202020202020202020206966202849454578417574547269676765724D6F7573654576656E7446"
			$sScript &= "756E63286F4F626A2C20276D6F7573656F766572272929207B72657475726E20333B7D0D0A202020"
			$sScript &= "202020202020202020202020206966202849454578417574547269676765724D6F7573654576656E"
			$sScript &= "7446756E63286F4F626A2C20276D6F757365646F776E272929207B72657475726E20343B7D0D0A20"
			$sScript &= "2020202020202020202020202020206966202849454578417574547269676765724D6F7573654576"
			$sScript &= "656E7446756E63286F4F626A2C20276D6F7573657570272929207B72657475726E20353B7D0D0A20"
			$sScript &= "2020202020202020202020202020206966202849454578417574547269676765724D6F7573654576"
			$sScript &= "656E7446756E63286F4F626A2C20276D6F757365646F776E272929207B72657475726E20363B7D0D"
			$sScript &= "0A202020202020202020202020202020206966202849454578417574547269676765724D6F757365"
			$sScript &= "4576656E7446756E63286F4F626A2C20276D6F7573657570272929207B72657475726E20373B7D0D"
			$sScript &= "0A202020202020202020202020202020206966202849454578417574547269676765724D6F757365"
			$sScript &= "4576656E7446756E63286F4F626A2C202764626C636C69636B272929207B72657475726E20383B7D"
			$sScript &= "0D0A20202020202020202020202020202020627265616B3B0D0A2020202020202020202020206361"
			$sScript &= "736520276D6F75736564626C636C69636B706F696E74273A0D0A2020202020202020202020202020"
			$sScript &= "20206F52656374203D206F4F626A2E676574426F756E64696E67436C69656E745265637428293B0D"
			$sScript &= "0A202020202020202020202020202020202F2A2066696E6420636C69636B20636F6F7264696E6174"
			$sScript &= "6573202A2F0D0A202020202020202020202020202020206E58203D20286E58203D3D3D203029203F"
			$sScript &= "206F526563742E6C656674202B204D6174682E726F756E642828286F526563742E7269676874202D"
			$sScript &= "206F526563742E6C65667429202F20322929203A206E58202B206F526563742E6C6566743B0D0A20"
			$sScript &= "2020202020202020202020202020206E59203D20286E59203D3D3D203029203F206F526563742E74"
			$sScript &= "6F70202B204D6174682E726F756E642828286F526563742E626F74746F6D202D206F526563742E74"
			$sScript &= "6F7029202F20322929203A206E59202B206F526563742E746F703B0D0A2020202020202020202020"
			$sScript &= "20202020206966202849454578417574547269676765724D6F7573654576656E7446756E63286F4F"
			$sScript &= "626A2E646F63756D656E742E656C656D656E7446726F6D506F696E74286E582C206E59292C20276D"
			$sScript &= "6F7573656F766572272929207B72657475726E20333B7D0D0A202020202020202020202020202020"
			$sScript &= "206966202849454578417574547269676765724D6F7573654576656E7446756E63286F4F626A2E64"
			$sScript &= "6F63756D656E742E656C656D656E7446726F6D506F696E74286E582C206E59292C20276D6F757365"
			$sScript &= "646F776E272929207B72657475726E20343B7D0D0A20202020202020202020202020202020696620"
			$sScript &= "2849454578417574547269676765724D6F7573654576656E7446756E63286F4F626A2E646F63756D"
			$sScript &= "656E742E656C656D656E7446726F6D506F696E74286E582C206E59292C20276D6F75736575702729"
			$sScript &= "29207B72657475726E20353B7D0D0A20202020202020202020202020202020696620284945457841"
			$sScript &= "7574547269676765724D6F7573654576656E7446756E63286F4F626A2E646F63756D656E742E656C"
			$sScript &= "656D656E7446726F6D506F696E74286E582C206E59292C20276D6F757365646F776E272929207B72"
			$sScript &= "657475726E20363B7D0D0A2020202020202020202020202020202069662028494545784175745472"
			$sScript &= "69676765724D6F7573654576656E7446756E63286F4F626A2E646F63756D656E742E656C656D656E"
			$sScript &= "7446726F6D506F696E74286E582C206E59292C20276D6F7573657570272929207B72657475726E20"
			$sScript &= "373B7D0D0A202020202020202020202020202020206966202849454578417574547269676765724D"
			$sScript &= "6F7573654576656E7446756E63286F4F626A2E646F63756D656E742E656C656D656E7446726F6D50"
			$sScript &= "6F696E74286E582C206E59292C202764626C636C69636B272929207B72657475726E20383B7D0D0A"
			$sScript &= "20202020202020202020202020202020627265616B3B0D0A20202020202020202020202063617365"
			$sScript &= "20276D6F757365646F776E273A0D0A20202020202020202020202020202020696620284945457841"
			$sScript &= "7574547269676765724D6F7573654576656E7446756E63286F4F626A2C20276D6F757365646F776E"
			$sScript &= "272929207B72657475726E20333B7D0D0A20202020202020202020202020202020627265616B3B0D"
			$sScript &= "0A2020202020202020202020206361736520276D6F757365656E746572273A0D0A20202020202020"
			$sScript &= "2020202020202020206966202849454578417574547269676765724D6F7573654576656E7446756E"
			$sScript &= "63286F4F626A2C20276D6F757365656E746572272929207B72657475726E20333B7D0D0A20202020"
			$sScript &= "202020202020202020202020627265616B3B0D0A2020202020202020202020206361736520276D6F"
			$sScript &= "7573656C65617665273A0D0A20202020202020202020202020202020696620284945457841757454"
			$sScript &= "7269676765724D6F7573654576656E7446756E63286F4F626A2C20276D6F7573656C656176652729"
			$sScript &= "29207B72657475726E20333B7D0D0A20202020202020202020202020202020627265616B3B0D0A20"
			$sScript &= "20202020202020202020206361736520276D6F7573656D6F7665273A0D0A20202020202020202020"
			$sScript &= "2020202020206966202849454578417574547269676765724D6F7573654576656E7446756E63286F"
			$sScript &= "4F626A2C20276D6F7573656D6F7665272929207B72657475726E20333B7D0D0A2020202020202020"
			$sScript &= "2020202020202020627265616B3B0D0A2020202020202020202020206361736520276D6F7573656D"
			$sScript &= "6F7665746F706F696E74273A0D0A202020202020202020202020202020206F52656374203D206F4F"
			$sScript &= "626A2E676574426F756E64696E67436C69656E745265637428293B0D0A2020202020202020202020"
			$sScript &= "20202020202F2A2066696E6420636C69636B20636F6F7264696E61746573202A2F0D0A2020202020"
			$sScript &= "20202020202020202020206E58203D20286E58203D3D3D203029203F206F526563742E6C65667420"
			$sScript &= "2B204D6174682E726F756E642828286F526563742E7269676874202D206F526563742E6C65667429"
			$sScript &= "202F20322929203A206E58202B206F526563742E6C6566743B0D0A20202020202020202020202020"
			$sScript &= "2020206E59203D20286E59203D3D3D203029203F206F526563742E746F70202B204D6174682E726F"
			$sScript &= "756E642828286F526563742E626F74746F6D202D206F526563742E746F7029202F20322929203A20"
			$sScript &= "6E59202B206F526563742E746F703B0D0A2020202020202020202020202020202069662028494545"
			$sScript &= "78417574547269676765724D6F7573654576656E7446756E63286F4F626A2E646F63756D656E742E"
			$sScript &= "656C656D656E7446726F6D506F696E74286E582C206E59292C20276D6F7573656D6F766527292920"
			$sScript &= "7B72657475726E20333B7D0D0A20202020202020202020202020202020627265616B3B0D0A202020"
			$sScript &= "2020202020202020206361736520276D6F7573656F7574273A0D0A20202020202020202020202020"
			$sScript &= "2020206966202849454578417574547269676765724D6F7573654576656E7446756E63286F4F626A"
			$sScript &= "2C20276D6F7573656F7574272929207B72657475726E20333B7D0D0A202020202020202020202020"
			$sScript &= "20202020627265616B3B0D0A2020202020202020202020206361736520276D6F7573656F76657227"
			$sScript &= "3A0D0A202020202020202020202020202020206966202849454578417574547269676765724D6F75"
			$sScript &= "73654576656E7446756E63286F4F626A2C20276D6F7573656F766572272929207B72657475726E20"
			$sScript &= "333B7D0D0A20202020202020202020202020202020627265616B3B0D0A2020202020202020202020"
			$sScript &= "206361736520276D6F7573657570273A0D0A20202020202020202020202020202020696620284945"
			$sScript &= "4578417574547269676765724D6F7573654576656E7446756E63286F4F626A2C20276D6F75736575"
			$sScript &= "70272929207B72657475726E20333B7D0D0A20202020202020202020202020202020627265616B3B"
			$sScript &= "0D0A20202020202020202020202064656661756C743A0D0A20202020202020202020202020202020"
			$sScript &= "72657475726E20323B0D0A20202020202020207D0D0A20202020202020202F2A2073756363657373"
			$sScript &= "202A2F0D0A202020202020202072657475726E20303B0D0A202020207D3B0D0A7D0D0A2F2A206D6F"
			$sScript &= "757365206576656E742066756E6320656E64202A2F"
		Case "IEExAutDragEvent"
			$sScript &= "66756E6374696F6E204945457841757454726967676572447261674576656E7446756E6328617574"
			$sScript &= "4E6F64652C206175744576656E745479706529207B0D0A2020202076617220617574447261674576"
			$sScript &= "656E74203D20646F63756D656E742E6372656174654576656E742827447261674576656E7427293B"
			$sScript &= "0D0A20202020617574447261674576656E742E696E69744576656E74286175744576656E74547970"
			$sScript &= "652C20747275652C2074727565293B0D0A2020202069662028747970656F66206175744E6F64652E"
			$sScript &= "64697370617463684576656E74203D3D2027756E646566696E65642729207B72657475726E20317D"
			$sScript &= "3B0D0A202020206175744E6F64652E64697370617463684576656E7428617574447261674576656E"
			$sScript &= "74293B0D0A202020202F2A2073756363657373202A2F0D0A2020202072657475726E20303B0D0A7D"
			$sScript &= "0D0A0D0A66756E6374696F6E2049454578417574447261674576656E7446756E632829207B0D0A20"
			$sScript &= "20202076617220617574444956203D20646F63756D656E742E637265617465456C656D656E742827"
			$sScript &= "64697627293B0D0A202020206175744449562E73657441747472696275746528276964272C202749"
			$sScript &= "454578417574447261674576656E74496427293B0D0A20202020646F63756D656E742E626F64792E"
			$sScript &= "617070656E644368696C6428617574444956293B0D0A202020207661722061757444726167203D20"
			$sScript &= "646F63756D656E742E676574456C656D656E7442794964282749454578417574447261674576656E"
			$sScript &= "74496427293B0D0A20202020617574447261672E49454578417574447261674576656E74203D2066"
			$sScript &= "756E6374696F6E286F4F626A2C2073416374696F6E2C206E582C206E5929207B0D0A0D0A20202020"
			$sScript &= "2020202069662028747970656F66206F4F626A203D3D2027756E646566696E65642729207B726574"
			$sScript &= "75726E20313B7D0D0A202020202020202069662028747970656F662073416374696F6E203D3D2027"
			$sScript &= "756E646566696E65642729207B73416374696F6E203D2027636C69636B273B7D0D0A202020202020"
			$sScript &= "202069662028747970656F66206E58203D3D2027756E646566696E65642729207B6E58203D20303B"
			$sScript &= "7D0D0A202020202020202069662028747970656F66206E59203D3D2027756E646566696E65642729"
			$sScript &= "207B6E59203D20303B7D0D0A0D0A2020202020202020766172206F526563743B0D0A0D0A20202020"
			$sScript &= "2020202076617220734C6F776572203D2073416374696F6E2E746F4C6F7765724361736528293B0D"
			$sScript &= "0A202020202020202073776974636828734C6F77657229207B0D0A20202020202020202020202063"
			$sScript &= "617365202764726167273A0D0A202020202020202020202020202020206966202849454578417574"
			$sScript &= "54726967676572447261674576656E7446756E63286F4F626A2C202764726167272929207B726574"
			$sScript &= "75726E20333B7D0D0A20202020202020202020202020202020627265616B3B0D0A20202020202020"
			$sScript &= "202020202063617365202764726167656E64273A0D0A202020202020202020202020202020206966"
			$sScript &= "20284945457841757454726967676572447261674576656E7446756E63286F4F626A2C2027647261"
			$sScript &= "67656E64272929207B72657475726E20333B7D0D0A20202020202020202020202020202020627265"
			$sScript &= "616B3B0D0A20202020202020202020202063617365202764726167656E746572273A0D0A20202020"
			$sScript &= "202020202020202020202020696620284945457841757454726967676572447261674576656E7446"
			$sScript &= "756E63286F4F626A2C202764726167656E746572272929207B72657475726E20333B7D0D0A202020"
			$sScript &= "20202020202020202020202020627265616B3B0D0A20202020202020202020202063617365202764"
			$sScript &= "7261676C65617665273A0D0A20202020202020202020202020202020696620284945457841757454"
			$sScript &= "726967676572447261674576656E7446756E63286F4F626A2C2027647261676C6561766527292920"
			$sScript &= "7B72657475726E20333B7D0D0A20202020202020202020202020202020627265616B3B0D0A202020"
			$sScript &= "202020202020202020636173652027647261676F766572273A0D0A20202020202020202020202020"
			$sScript &= "202020696620284945457841757454726967676572447261674576656E7446756E63286F4F626A2C"
			$sScript &= "2027647261676F766572272929207B72657475726E20333B7D0D0A20202020202020202020202020"
			$sScript &= "202020627265616B3B0D0A202020202020202020202020636173652027647261677374617274273A"
			$sScript &= "0D0A2020202020202020202020202020202069662028494545784175745472696767657244726167"
			$sScript &= "4576656E7446756E63286F4F626A2C2027647261677374617274272929207B72657475726E20333B"
			$sScript &= "7D0D0A20202020202020202020202020202020627265616B3B0D0A20202020202020202020202063"
			$sScript &= "617365202764726F70273A0D0A202020202020202020202020202020206966202849454578417574"
			$sScript &= "54726967676572447261674576656E7446756E63286F4F626A2C202764726F70272929207B726574"
			$sScript &= "75726E20333B7D0D0A20202020202020202020202020202020627265616B3B0D0A20202020202020"
			$sScript &= "202020202064656661756C743A0D0A2020202020202020202020202020202072657475726E20323B"
			$sScript &= "0D0A20202020202020207D0D0A20202020202020202F2A2073756363657373202A2F0D0A20202020"
			$sScript &= "2020202072657475726E20303B0D0A202020207D3B0D0A7D"
		Case "IEExAutClickObjById"
			$sScript &= "66756E6374696F6E2049454578417574436C69636B4F626A4279496446756E632829207B0D0A2020"
			$sScript &= "202076617220617574444956203D20646F63756D656E742E637265617465456C656D656E74282764"
			$sScript &= "697627293B0D0A202020206175744449562E73657441747472696275746528276964272C20274945"
			$sScript &= "4578417574436C69636B4F626A42794964496427293B0D0A20202020646F63756D656E742E626F64"
			$sScript &= "792E617070656E644368696C6428617574444956293B0D0A2020202076617220617574436C69636B"
			$sScript &= "203D20646F63756D656E742E676574456C656D656E7442794964282249454578417574436C69636B"
			$sScript &= "4F626A42794964496422293B0D0A20202020617574436C69636B2E49454578417574436C69636B4F"
			$sScript &= "626A42794964203D2066756E6374696F6E28764F626A29207B0D0A20202020202020207661722073"
			$sScript &= "54797065203D20747970656F6620764F626A3B0D0A0D0A2020202020202020696620287354797065"
			$sScript &= "203D3D2027756E646566696E65642729207B72657475726E20313B7D0D0A0D0A2020202020202020"
			$sScript &= "6966202873547970652E746F4C6F776572436173652829203D3D20276F626A6563742729207B0D0A"
			$sScript &= "20202020202020202020202072657475726E20764F626A2E636C69636B28293B0D0A202020202020"
			$sScript &= "20207D0D0A0D0A20202020202020206966202873547970652E746F4C6F776572436173652829203D"
			$sScript &= "3D2027737472696E672729207B0D0A20202020202020202020202072657475726E2028646F63756D"
			$sScript &= "656E742E676574456C656D656E744279496428764F626A292E636C69636B2829293B0D0A20202020"
			$sScript &= "202020207D0D0A0D0A20202020202020202F2A20766F626A20697320756E6B6E6F776E202A2F0D0A"
			$sScript &= "202020202020202072657475726E20323B0D0A202020207D3B0D0A7D"
		Case "IEExAutClickObj"
			$sScript &= "66756E6374696F6E2049454578417574436C69636B4F626A46756E632829207B0D0A202076617220"
			$sScript &= "617574444956203D20646F63756D656E742E637265617465456C656D656E74282764697627293B0D"
			$sScript &= "0A20206175744449562E73657441747472696275746528276964272C202749454578417574436C69"
			$sScript &= "636B4F626A496427293B0D0A2020646F63756D656E742E626F64792E617070656E644368696C6428"
			$sScript &= "617574444956293B0D0A202076617220617574436C69636B203D20646F63756D656E742E67657445"
			$sScript &= "6C656D656E7442794964282249454578417574436C69636B4F626A496422293B0D0A202061757443"
			$sScript &= "6C69636B2E49454578417574436C69636B4F626A203D2066756E6374696F6E286F4F626A29207B0D"
			$sScript &= "0A0969662028747970656F66206F4F626A203D3D2027756E646566696E65642729207B7265747572"
			$sScript &= "6E20313B7D0D0A0972657475726E20286F4F626A2E646F63756D656E742E636C69636B2829293B0D"
			$sScript &= "0A20207D3B0D0A7D"
		Case "IEExAutClickObjXY"
			$sScript &= "66756E6374696F6E2049454578417574436C69636B4F626A585946756E632829207B0D0A20207661"
			$sScript &= "7220617574444956203D20646F63756D656E742E637265617465456C656D656E7428276469762729"
			$sScript &= "3B0D0A20206175744449562E73657441747472696275746528276964272C20274945457841757443"
			$sScript &= "6C69636B4F626A5859496427293B0D0A2020646F63756D656E742E626F64792E617070656E644368"
			$sScript &= "696C6428617574444956293B0D0A202076617220617574436C69636B203D20646F63756D656E742E"
			$sScript &= "676574456C656D656E7442794964282249454578417574436C69636B4F626A5859496422293B0D0A"
			$sScript &= "2020617574436C69636B2E49454578417574436C69636B4F626A5859203D2066756E6374696F6E28"
			$sScript &= "6F4F626A2C206E582C206E5929207B0D0A0D0A0969662028747970656F66206F4F626A203D3D2027"
			$sScript &= "756E646566696E65642729207B72657475726E20313B7D0D0A0969662028747970656F66206E5820"
			$sScript &= "3D3D2027756E646566696E65642729207B6E58203D20303B7D0D0A0969662028747970656F66206E"
			$sScript &= "59203D3D2027756E646566696E65642729207B6E59203D20303B7D0D0A090D0A09766172206F5265"
			$sScript &= "6374203D206F4F626A2E676574426F756E64696E67436C69656E745265637428293B0D0A090D0A09"
			$sScript &= "2F2A2066696E6420636C69636B20636F6F7264696E61746573202A2F0D0A096E58203D20286E5820"
			$sScript &= "3D3D3D203029203F206F526563742E6C656674202B204D6174682E726F756E642828286F52656374"
			$sScript &= "2E7269676874202D206F526563742E6C65667429202F20322929203A206E58202B206F526563742E"
			$sScript &= "6C6566743B0D0A096E59203D20286E59203D3D3D203029203F206F526563742E746F70202B204D61"
			$sScript &= "74682E726F756E642828286F526563742E626F74746F6D202D206F526563742E746F7029202F2032"
			$sScript &= "2929203A206E59202B206F526563742E746F703B0D0A0D0A092F2A20696E20612070657266656374"
			$sScript &= "20776F726C642C20796F75276C6C20736D696C652068657265202A2F0D0A0972657475726E20286F"
			$sScript &= "4F626A2E646F63756D656E742E656C656D656E7446726F6D506F696E74286E582C206E59292E636C"
			$sScript &= "69636B2829293B0D0A20207D3B0D0A7D"
		Case "IEExAutEvalObj"
			$sScript &= "2F2A0D0A094261736564206F6E206F7A6D696B65277320696D706C696D656E746174696F6E20666F"
			$sScript &= "72204A534F4E20646576656C6F706D656E7420666F72204175746F49740D0A09687474703A2F2F77"
			$sScript &= "77772E6175746F69747363726970742E636F6D2F666F72756D2F746F7069632F3135363739342D6E"
			$sScript &= "61746976652D77696E646F77732D6A736F6E2D666F722D6175746F2D69742D706C75732D6F6F2F0D"
			$sScript &= "0A2A2F090D0A66756E6374696F6E20494545784175744576616C4F626A46756E632829207B0D0A20"
			$sScript &= "2076617220617574444956203D20646F63756D656E742E637265617465456C656D656E7428276469"
			$sScript &= "7627293B0D0A20206175744449562E73657441747472696275746528276964272C20274945457841"
			$sScript &= "75744576616C4F626A496427293B0D0A2020646F63756D656E742E626F64792E617070656E644368"
			$sScript &= "696C6428617574444956293B0D0A2020766172206175744576616C203D20646F63756D656E742E67"
			$sScript &= "6574456C656D656E74427949642822494545784175744576616C4F626A496422293B0D0A20206175"
			$sScript &= "744576616C2E494545784175744576616C4F626A203D2066756E6374696F6E287673637269707429"
			$sScript &= "207B0D0A2020202072657475726E2028646F63756D656E742E706172656E7457696E646F772E6576"
			$sScript &= "616C287673637269707429290D0A20207D3B0D0A7D3B"
		Case "IEExAutClassGetCollection"
			$sScript &= "66756E6374696F6E2049454578417574436C617373476574436F6C6C656374696F6E46756E632829"
			$sScript &= "207B0D0A2020202076617220617574444956203D20646F63756D656E742E637265617465456C656D"
			$sScript &= "656E74282764697627293B0D0A202020206175744449562E73657441747472696275746528276964"
			$sScript &= "272C202749454578417574436C617373476574436F6C6C656374696F6E496427293B0D0A20202020"
			$sScript &= "646F63756D656E742E626F64792E617070656E644368696C6428617574444956293B0D0A20202020"
			$sScript &= "766172206175745661726961626C65203D20646F63756D656E742E676574456C656D656E74427949"
			$sScript &= "64282249454578417574436C617373476574436F6C6C656374696F6E496422293B0D0A2020202061"
			$sScript &= "75745661726961626C652E49454578417574436C617373476574436F6C6C656374696F6E203D2066"
			$sScript &= "756E6374696F6E20286F456C6D2C2073436C61737329207B0D0A09090D0A20202020202020206966"
			$sScript &= "2028747970656F662073436C617373203D3D2027756E646566696E65642729207B72657475726E20"
			$sScript &= "313B7D0D0A20202020202020206F456C6D203D2028747970656F66206F456C6D203D3D2027756E64"
			$sScript &= "6566696E65642729203F20646F63756D656E74203A206F456C6D3B0D0A09090D0A20202020202020"
			$sScript &= "2069662028646F63756D656E742E676574456C656D656E74734279436C6173734E616D6529207B0D"
			$sScript &= "0A20202020202020202020202072657475726E20286F456C6D2E676574456C656D656E7473427943"
			$sScript &= "6C6173734E616D652873436C61737329293B0D0A20202020202020207D0D0A202020202020202065"
			$sScript &= "6C7365207B0D0A202020202020202020202020676574456C656D656E74734279436C6173734E616D"
			$sScript &= "65203D2066756E6374696F6E2873436C6173732C206F456C6D29207B0D0A20202020202020202020"
			$sScript &= "2020202020207661722061436C6173736573203D2073436C6173732E73706C697428222022292C20"
			$sScript &= "61436C6173736573436865636B203D205B5D3B0D0A20202020202020202020202020202020766172"
			$sScript &= "206F456C656D656E7473203D206F456C6D2E616C6C2C206F43757272656E743B0D0A202020202020"
			$sScript &= "20202020202020202020766172206F526574203D205B5D2C20624D617463683B0D0A0D0A20202020"
			$sScript &= "202020202020202020202020666F722876617220693D20302C20696C3D61436C61737365732E6C65"
			$sScript &= "6E6774683B20693C696C3B20692B3D3129207B0D0A20202020202020202020202020202020202020"
			$sScript &= "2061436C6173736573436865636B2E70757368286E6577205265674578702822285E7C5C5C732922"
			$sScript &= "202B2061436C61737365735B695D202B2022285C5C737C24292229293B0D0A202020202020202020"
			$sScript &= "202020202020207D0D0A20202020202020202020202020202020666F7228766172206A3D20302C20"
			$sScript &= "6A6C3D6F456C656D656E74732E6C656E6774683B206A3C6A6C3B206A2B3D3129207B0D0A20202020"
			$sScript &= "202020202020202020202020202020206F43757272656E74203D206F456C656D656E74735B6A5D3B"
			$sScript &= "0D0A2020202020202020202020202020202020202020624D61746368203D2066616C73653B0D0A20"
			$sScript &= "20202020202020202020202020202020202020666F722028693D302C20696C3D61436C6173736573"
			$sScript &= "436865636B2E6C656E6774683B20693C696C3B20692B3D3129207B0D0A2020202020202020202020"
			$sScript &= "20202020202020202020202020624D61746368203D2061436C6173736573436865636B5B695D2E74"
			$sScript &= "657374286F43757272656E742E636C6173734E616D65293B0D0A2020202020202020202020202020"
			$sScript &= "202020202020202020206966202821624D6174636829207B0D0A2020202020202020202020202020"
			$sScript &= "2020202020202020202020202020627265616B3B0D0A202020202020202020202020202020202020"
			$sScript &= "2020202020207D0D0A20202020202020202020202020202020202020207D0D0A2020202020202020"
			$sScript &= "20202020202020202020202069662028624D6174636829207B0D0A20202020202020202020202020"
			$sScript &= "202020202020202020202072657475726E20286F5265742E70757368286F43757272656E7429293B"
			$sScript &= "0D0A20202020202020202020202020202020202020207D0D0A202020202020202020202020202020"
			$sScript &= "207D0D0A2020202020202020202020207D0D0A20202020202020207D0D0A20202020202020207265"
			$sScript &= "7475726E20323B0D0A202020207D3B0D0A7D"
		Case Else
			Return ""
	EndSwitch

	Return BinaryToString("0x" & $sScript)
EndFunc   ;==>__IEEx_GetInsertScript

Func __IEEx_MouseGetButtonDown($vButton)

	Local Const $MK_CONTROL  = 0x0008
	Local Const $MK_LBUTTON  = 0x0001
	Local Const $MK_MBUTTON  = 0x0010
	Local Const $MK_RBUTTON  = 0x0002
	Local Const $MK_SHIFT    = 0x0004
	Local Const $MK_XBUTTON1 = 0x0020
	Local Const $MK_XBUTTON2 = 0x0040

	Switch $vButton
		Case "ctrl", "control", $MK_CONTROL
			Return $MK_CONTROL
		Case "left", $MK_LBUTTON
			Return $MK_LBUTTON
		Case "middle", $MK_MBUTTON
			Return $MK_MBUTTON
		Case "right", $MK_RBUTTON
			Return $MK_RBUTTON
		Case "shift", $MK_SHIFT
			Return $MK_SHIFT
		Case "x1", $MK_XBUTTON1
			Return $MK_XBUTTON1
		Case "x2", $MK_XBUTTON2
			Return $MK_XBUTTON2
	EndSwitch

	Return 0
EndFunc   ;==>__IEEx_MouseGetButtonDown

Func __IEEx_JSDragEventObjBy(ByRef $oObj, $oEventObj, $sEvent, $nX = Default, $nY = Default)

	If Not IsObj($oObj) Then
		Return SetError($_IESTATUS_InvalidDataType, 1, False)
	EndIf

	If Not IsObj($oEventObj) Then
		Return SetError($_IESTATUS_InvalidDataType, 2, False)
	EndIf

	$sEvent = StringLower($sEvent)

	Switch $sEvent
		Case "drag", "dragend", "dragenter"
		Case "dragleave", "dragover"
		Case "dragstart", "drop"
		Case Else
			; wrong event type sent
			Return SetError($_IESTATUS_NoMatch, 3, False)
	EndSwitch

	If IsKeyword($nX) Then $nX = 0
	If IsKeyword($nY) Then $nY = 0

	Local $oDPW = __IEEx_GetContainerObj($oObj, "DragEvent")
	If @error Then
		Return SetError(@error, @extended, False)
	EndIf

	; we have our click object
	Local $iRet = Int($oDPW.IEExAutDragEvent($oEventObj, $sEvent, $nX, $nY))

	If $iRet <> 0 Then
		; extended 6 = invalid sid
		; extended 7 = event creation failed
		; extended 8 = invalid event type
		Return SetError($_IESTATUS_GeneralError, 5 + $iRet, False)
	EndIf
	Return SetError($_IESTATUS_Success, 1, True)
EndFunc   ;==>__IEEx_JSDragEventObjBy

Func __IEEx_JSMouseEventObjBy(ByRef $oObj, $oEventObj, $sEvent, $nX = Default, $nY = Default)

	If Not IsObj($oObj) Then
		Return SetError($_IESTATUS_InvalidDataType, 1, False)
	EndIf

	If Not IsObj($oEventObj) Then
		Return SetError($_IESTATUS_InvalidDataType, 2, False)
	EndIf

	$sEvent = StringLower($sEvent)

	Switch $sEvent
		Case "click", "clickpoint", "contextmenu", "contextmenupoint"
		Case "dblclick", "dblclickpoint", "mouseclick"
		Case "mouseclickpoint", "mousedblclick"
		Case "mousedblclickpoint", "mousedown", "mouseenter"
		Case "mouseleave", "mousemove", "mousemovetopoint"
		Case "mouseout", "mouseover", "mouseup"
		Case Else
			; wrong event type sent
			Return SetError($_IESTATUS_NoMatch, 3, False)
	EndSwitch

	If IsKeyword($nX) Then $nX = 0
	If IsKeyword($nY) Then $nY = 0

	Local $oDPW = __IEEx_GetContainerObj($oObj, "MouseEvent")
	If @error Then
		Return SetError(@error, @extended, False)
	EndIf

	; we have our click object
	Local $iRet = Int($oDPW.IEExAutMouseEvent($oEventObj, $sEvent, $nX, $nY))

	If $iRet <> 0 Then
		; extended 6 = invalid sid
		; extended 7 = event creation failed
		; extended 8 = invalid event type
		Return SetError($_IESTATUS_GeneralError, 5 + $iRet, False)
	EndIf

	Return SetError($_IESTATUS_Success, 1, True)
EndFunc   ;==>__IEEx_JSMouseEventObjBy

Func __IEEx_ScriptToBinary($sScript)

	Local $sBinary = Hex(StringToBinary($sScript))
	Local $sOut = ""
	Local $aRegEx = StringRegExp($sBinary, ".{1,80}", 3)
	For $i = 0 To UBound($aRegEx) - 1
		$sOut &= '			$sScript &= "' & $aRegEx[$i] & '"' & @CRLF
	Next

	Return StringTrimRight($sOut, 2)
EndFunc   ;==>__IEEx_ScriptToBinary
; ===============================================================================================================================

; #Deprecated#===================================================================================================================
; ===============================================================================================================================