#include "IEEx.au3"

Global $goIE = _IECreate("about:blank")

_ExampleQuerySelectorClick($goIE)

_IEQuit($goIE)

Func _ExampleQuerySelectorClick(ByRef $oObj)

    If Not IsObj($oObj) Then
        Return SetError(1, 0, 0)
    EndIf

    _IENavigate($oObj, "http://google.com")
    _IELoadWait($oObj)

    Local $oInput = _IEEx_JSObjQuerySelector($oObj, 'input.gbqfif') ; find input object with class of gbqfif
    If Not IsObj($oInput) Then
        Return SetError(2, 0, 0)
    EndIf

    $oInput.value = "AutoIt"

    _IEEx_JSClickObjById($oObj, "gbqfsa")
    If @error Then
        Return SetError(3, 0, 0)
    EndIf

    _IELoadWait($oObj)
    Sleep(10000)
EndFunc