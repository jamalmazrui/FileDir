#include "IEEx.au3"

Global $goIE = _IECreate("about:blank")

_ExampleClassNameCollection($goIE)

_IEQuit($goIE)

Func _ExampleClassNameCollection(ByRef $oObj)

    If Not IsObj($oObj) Then
        Return SetError(1, 0, 0)
    EndIf

    _IENavigate($oObj, "http://autoitscript.com/forum")
    _IELoadWait($oObj)

    ; get an array of the class objects
    Local $oClasses = _IEEx_JSClassNameGetCollection($oObj, "hide")
    If @error Then
        Return SetError(2, 0, 0)
    EndIf

    MsgBox(64 + 262144, "Info", "There were " & $oClasses.length & " class objects of ""hide"" found.")

    For $oClass In $oClasses
        ConsoleWrite("Tag: " & $oClass.tagName & @CRLF)
    Next
EndFunc