#include "IEEx.au3"

; disregard _IEAttach console error if instance doesn't exist yet
Global $goIE = _IECreate("http://www.javascripttoolbox.com/lib/contextmenu/", 1)

_ExampleContextMenu($goIE)
ConsoleWrite(@error & ":" & @extended & @CRLF)

;_IEQuit($goIE)

Func _ExampleContextMenu(ByRef $oObj)

    If Not IsObj($oObj) Then
        Return SetError(1, 0, 0)
    EndIf

    Local $oDivContainer = _IEEx_JSObjQuerySelector($oObj, 'div[class="context-menu ' & _
        'context-menu-theme-vista context-menu-example-trigger menu-vista"]')
    If Not IsObj($oDivContainer) Then
        Return SetError(2, 0, 0)
    EndIf

    Local $oDivOuter = _IEEx_JSGetObjByClassName($oDivContainer, "context-menu-item", "div")
    If @error Then
        Return SetError(3, 0, 0)
    EndIf

    $oDivOuter.scrollIntoView()

    ; point with no coordinates is defaulted to center
    ;  however, some context events check the mouse position instead of the
    ;  object position, in order to determine where to put the contextMenu popup
    Local $iRet = _IEEx_JSMouseEventObj($oObj, $oDivOuter, "contextMenuPoint")
    IF @error Then
        Return SetError(@error, @extended, $iRet)
    EndIf

    Return 1
EndFunc