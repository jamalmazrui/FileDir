#include "IEEx.au3"

Global $goIE = _IECreate("about:blank")

_ExampleClassNameArray($goIE)

_IEQuit($goIE)

Func _ExampleClassNameArray(ByRef $oObj)

    If Not IsObj($oObj) Then
        Return SetError(1, 0, 0)
    EndIf

    _IENavigate($oObj, "http://autoitscript.com/forum")
    _IELoadWait($oObj)

    ; get an array of the class objects
    Local $aOClass = _IEEx_JSClassNameGetArray($oObj, "hide")
    If @error Then
        Return SetError(2, 0, 0)
    EndIf

    MsgBox(64 + 262144, "Info", "There were " & UBound($aOClass) & " class objects of ""hide"" found.")
EndFunc