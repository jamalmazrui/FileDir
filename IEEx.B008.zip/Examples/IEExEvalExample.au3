#include "IEEx.au3"

Global $goIE = _IECreate("about:blank")

_ExampleEval($goIE)

_IEQuit($goIE)

Func _ExampleEval(ByRef $oObj)

    If Not IsObj($oObj) Then
        Return SetError(1, 0, 0)
    EndIf

    Local $oEval = _IEEx_GetObjEval($oObj)
    If @error Then
        Return SetError(2, 0, 0)
    EndIf

    ; show an alert box from ie, script will
    ;  pause just like a normal msgbox call
    $oEval("alert('This was launched from IE');")

    ; do a little math
    MsgBox(64 + 262144, "Info", "4 + 4 = " & $oEval("4 + 4"))
EndFunc