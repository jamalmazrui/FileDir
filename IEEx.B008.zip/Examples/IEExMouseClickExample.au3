#include "IEEx.au3"

Global $goIE = _IECreate("about:blank")

_ExampleMouseClick($goIE)

_IEQuit($goIE)

Func _ExampleMouseClick(ByRef $oObj)

    If Not IsObj($oObj) Then
        Return SetError(1, 0, 0)
    EndIf

    _IENavigate($oObj, "https://translate.google.com/#auto/en/Hello")
    _IELoadWait($oObj)

    Local $oRes = _IEGetObjById($oObj, "gt-res-listen")

    ; an action that probably won't work
    _IEAction($oRes, "click")
    MsgBox(4 + 32 + 262144, "Question", "Did you hear anything?")
    Sleep(1000)

    ; now an action that will probably work
    _IEEx_JSMouseEventObj($oObj, $oRes, "mouseclick")
    If @error Then
        Return SetError(2, 0, 0)
    EndIf

    Sleep(1000)
    MsgBox(4 + 32 + 262144, "Question", "Did you hear anything now?")
EndFunc