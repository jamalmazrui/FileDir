#include "IEEx.au3"

Global $goIE = _IECreate("about:blank")


_ExampleMClickGetPosGetScroll($goIE)
ConsoleWrite(@error & ":" & @extended & @CRLF)

;~ _IEQuit($goIE)

Func _ExampleMClickGetPosGetScroll(ByRef $oObj)

    If Not IsObj($oObj) Then
        Return SetError(1, 0, 0)
    EndIf

	; get handle to client area of body
	Local $hBody = ControlGetHandle(HWnd($oObj.hwnd), "", _
		"[CLASS:Internet Explorer_Server; INSTANCE:1]")
	If Not IsHWnd($hBody) Then
		Return SetError(2, 0, 0)
	EndIf

    _IENavigate($oObj, "http://www.javascripttoolbox.com/lib/contextmenu/")
    _IELoadWait($oObj)

	Local $oDiv = _IEEx_JSObjQuerySelector($oObj, 'div.context-menu-item')
	If Not IsObj($oDiv) Then
		Return SetError(3, 0, 0)
	EndIf

	$oDiv.scrollIntoView()

	; obj position relative to body, not viewable position
	Local $aPos = _IEEx_GetObjPos($oDiv)
	If @error Then
		Return SetError(4, 0, 0)
	EndIf

	; get scroll point so we can adjust x and y of object
	Local $aScroll = _IEEx_GetScrollPoint($oObj)
	If @error Then
		Return SetError(5, 0, 0)
	EndIf

	; adjust x and y positions
	$aPos[0] -= $aScroll[0]
	$aPos[1] -= $aScroll[1]

	; make x and y middle object
	$aPos[0] += Int($aPos[2] / 2)
	$aPos[1] += Int($aPos[3] / 2)

	If Not _IEEx_MouseEventExec($hBody, "rightClick", $aPos[0], $aPos[1]) Then
		Return SetError(6, 0, 0)
	EndIf

	Return 1
EndFunc