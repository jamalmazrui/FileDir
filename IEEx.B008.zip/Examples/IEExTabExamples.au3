#include "IEEx.au3"

_Example()

Func _Example()

	Local $oIE = _IECreate("http://google.com")
	If Not IsObj($oIE) Then
		Return SetError(1, 0, 0)
	EndIf

	_IELoadWait($oIE)

	; really a browser instance count for same browser window hwnd
	Local $nTabCount = _IEEx_TabCount($oIE)
	; since the original browser object is a tab, it will count as 1
	; the result should be one
	ConsoleWrite("Currently there is """ & $nTabCount & """ tab(s) open." & @CRLF)

	Local $oTab = _IEEx_TabCreate($oIE, "http://autoitscript.com")
	If Not IsObj($oTab) Then
		Return SetError(2, 0, 0)
	EndIf

	_IELoadWait($oTab)

	$nTabCount = _IEEx_TabCount($oIE)
	; the result should be two (original browser tab and new tab just created)
	ConsoleWrite("Currently there are """ & $nTabCount & """ tabs open." & @CRLF)

	; we already have our $oTab instance object from the tab create
	; however, let's say we didn't manage it well

	; an InStrURL approach (not looking for an exact match in case it changed)
	Local $oTabInStrURL = _IEEx_TabAttach($oIE, "autoitscript.com", "InStrURL", Default); first instance is fine
	If Not IsObj($oTabInStrURL) Then
		Return SetError(3, 0, 0)
	EndIf
	ConsoleWrite("We have our url instance." & @CRLF)

	; lets navigate away as if we didn't manage anything well
	_IENavigate($oTabInStrURL, "http://msdn.microsoft.com")
	_IELoadWait($oTabInStrURL)

	; now the url is changed, but we know it was the last tab created so let's do an instance approach
	Local $oTabInstance = _IEEx_TabAttach($oIE, "", "Instance", $nTabCount) ; last instance
	If Not IsObj($oTabInstance) Then
		Return SetError(4, 0, 0)
	EndIf
	ConsoleWrite("We have our last tab instance." & @CRLF)

	; now we'll sleep for a few seconds and close the tab
	Sleep(3000)
	ConsoleWrite("Closing tab instance: " & _IEEx_TabGetInstance($oTabInstance) & @CRLF)
	_IEQuit($oTabInstance)

	; sleep for a few more seconds and close main browser
	Sleep(3000)
	ConsoleWrite("Closing tab instance: " & _IEEx_TabGetInstance($oIE) & @CRLF)
	ConsoleWrite("Thanks for playing." & @CRLF)
	_IEQuit($oIE)

	Return 1
EndFunc