@echo off
rem ====================================================================
rem BuildFileDir.cmd - 64-bit build for FileDir.exe (5.0 beta).
rem
rem Compiles FileDir.cs to FileDir.exe with csc.exe, /platform:anycpu so
rem it runs as a 64-bit process on 64-bit Windows. No MSBuild/NuGet.
rem
rem This pass keeps the EXISTING reference DLLs (lbc/LbcVB/LbcJS,
rem Tektosyne, SharpZipLib, FileAssociation) unchanged from compile.bat,
rem and folds in the first Homer helper as source: Web.cs (Homer.Web),
rem used by the rewritten Elevate Version command. Remaining Homer files
rem are adopted in later passes. Mirrors the EdSharp/DbDo build model.
rem ====================================================================
setlocal enableextensions enabledelayedexpansion
pushd "%~dp0"

set "log=BuildFileDir.log"
echo FileDir build log > "!log!"
echo Started %DATE% %TIME% >> "!log!"

if not exist "FileDir.cs" echo ERROR: FileDir.cs not found.& popd & exit /b 1
if not exist "Web.cs" echo ERROR: Web.cs ^(Homer^) not found.& popd & exit /b 1

rem ---- required reference DLLs (must sit beside FileDir.cs) ----
for %%d in (FileAssociation.dll LbcJS.dll Tektosyne.dll ICSharpCode.SharpZipLib.dll lbc.dll LbcVB.dll) do (
  if not exist "%%d" echo ERROR: reference assembly %%d not found.& popd & exit /b 1
)

rem ---- locate csc.exe: prefer Roslyn (latest C#), fall back to Framework64 ----
set "csc="
for %%p in (
  "C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\MSBuild\Current\Bin\Roslyn\csc.exe"
  "C:\Program Files\Microsoft Visual Studio\2022\BuildTools\MSBuild\Current\Bin\Roslyn\csc.exe"
  "C:\Program Files (x86)\Microsoft Visual Studio\2022\Community\MSBuild\Current\Bin\Roslyn\csc.exe"
  "C:\Program Files\Microsoft Visual Studio\2022\Community\MSBuild\Current\Bin\Roslyn\csc.exe"
  "C:\Program Files (x86)\Microsoft Visual Studio\2022\Professional\MSBuild\Current\Bin\Roslyn\csc.exe"
  "C:\Program Files (x86)\Microsoft Visual Studio\2022\Enterprise\MSBuild\Current\Bin\Roslyn\csc.exe"
  "C:\Program Files (x86)\Microsoft Visual Studio\2019\BuildTools\MSBuild\Current\Bin\Roslyn\csc.exe"
  "%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
  "%SystemRoot%\Microsoft.NET\Framework\v4.0.30319\csc.exe"
) do (if not defined csc if exist %%p set "csc=%%~p")
if not defined csc echo ERROR: No csc.exe found. Install VS Build Tools or repair .NET Framework.& popd & exit /b 1
echo C# compiler: !csc! >> "!log!"

rem ---- optional manifest and icon (used only if present) ----
set "manifest="
if exist "FileDir.manifest" set "manifest=/win32manifest:FileDir.manifest"
if defined manifest (echo Manifest: FileDir.manifest >> "!log!") else (echo Manifest: none ^(optional^) >> "!log!")
set "icon="
if exist "FileDir.ico" set "icon=/win32icon:FileDir.ico"
if defined icon (echo Icon: FileDir.ico >> "!log!") else (echo Icon: none ^(optional^) >> "!log!")

rem ---- compile FileDir.cs -> FileDir.exe (64-bit on 64-bit Windows) ----
echo Compiling FileDir.cs -^> FileDir.exe ...
if exist FileDir.exe del /f /q FileDir.exe
"!csc!" /nologo /target:winexe /platform:anycpu /optimize+ %manifest% %icon% /reference:FileAssociation.dll /reference:Microsoft.JScript.dll /reference:LbcJS.dll /reference:Tektosyne.dll /reference:ICSharpCode.SharpZipLib.dll /reference:lbc.dll /reference:LbcVB.dll /reference:Microsoft.VisualBasic.dll /out:FileDir.exe FileDir.cs Web.cs >> "!log!" 2>&1
if errorlevel 1 goto failed

echo.
echo Build complete:
echo   FileDir.exe  -- the application (64-bit on 64-bit Windows)
echo. >> "!log!"
echo BUILD COMPLETE: FileDir.exe built successfully. >> "!log!"
echo Finished %DATE% %TIME% >> "!log!"
popd & endlocal & exit /b 0

:failed
echo. >> "!log!"
echo BUILD FAILED - compile errors are listed above in this log. >> "!log!"
echo.
echo BUILD FAILED. Errors from %log%:
type "!log!" | findstr /C:": error" /C:"error CS"
popd & endlocal & exit /b 1
