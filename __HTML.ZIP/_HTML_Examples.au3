﻿#Region Includes
#include <Array.au3>
#include <_HTML.au3>
#EndRegion Includes

$_HTML_SEARCHMODE = 1

Main()

Func Main()

    Local $HTML = _HTML_GetSource("https://autoit.de/")

    MsgBox(0, "_HTML_GetURLVar", _HTML_GetURLVar($HTML, "page", "Mitglieder", "title") & @CRLF)
    MsgBox(0, "_HTML_GetText", _HTML_GetText($HTML, "div", "cont.*erCont", "class", 5) & @CRLF)
    MsgBox(0, "_HTML_GetImageSrc", _HTML_GetImageSrc($HTML, "controllcenterImage") & @CRLF)
    MsgBox(0, "_HTML_GetLink", _HTML_GetLink($HTML, "loginButton") & @CRLF)

    Local $a = _HTML_GetAllLinks($HTML)
    _ArrayDisplay($a,'_HTML_GetAllLinks - 1')

    $a = _HTML_GetAllLinks($HTML, '\.com')
    _ArrayDisplay($a,'_HTML_GetAllLinks - 2')

    $a = _HTML_GetAllImageSrc($HTML, 'wcf/images/')
    _ArrayDisplay($a,'_HTML_GetAllImageSrc')

	$a = _HTML_GetTable($HTML)
    _ArrayDisplay($a,'_HTML_GetTable')

EndFunc   ;==>Main
